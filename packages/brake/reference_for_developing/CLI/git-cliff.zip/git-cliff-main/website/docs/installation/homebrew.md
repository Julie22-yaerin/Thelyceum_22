---
sidebar_position: 7
---
# Homebrew

On macOS, **git-cliff** can be installed via [Homebrew](https://formulae.brew.sh/formula/git-cliff):

```bash
brew install git-cliff
```
