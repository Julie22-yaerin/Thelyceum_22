use uv_configuration::{BuildOptions, IndexStrategy};
use uv_pypi_types::SupportedEnvironments;
use uv_torch::TorchStrategy;

use crate::fork_strategy::ForkStrategy;
use crate::{DependencyMode, ExcludeNewer, Prerelease, ResolutionMode};

/// Options for resolving a manifest.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct Options {
    pub resolution_mode: ResolutionMode,
    pub prerelease: Prerelease,
    pub dependency_mode: DependencyMode,
    pub fork_strategy: ForkStrategy,
    pub exclude_newer: ExcludeNewer,
    pub index_strategy: IndexStrategy,
    pub artifact_environments: SupportedEnvironments,
    pub flexibility: Flexibility,
    pub build_options: BuildOptions,
    pub torch_backend: Option<TorchStrategy>,
}

/// Builder for [`Options`].
#[derive(Debug, Default, Clone)]
pub struct OptionsBuilder {
    resolution_mode: ResolutionMode,
    prerelease: Prerelease,
    dependency_mode: DependencyMode,
    fork_strategy: ForkStrategy,
    exclude_newer: ExcludeNewer,
    index_strategy: IndexStrategy,
    artifact_environments: SupportedEnvironments,
    flexibility: Flexibility,
    build_options: BuildOptions,
    torch_backend: Option<TorchStrategy>,
}

impl OptionsBuilder {
    /// Creates a new builder.
    pub fn new() -> Self {
        Self::default()
    }

    /// Sets the [`ResolutionMode`].
    #[must_use]
    pub fn resolution_mode(mut self, resolution_mode: ResolutionMode) -> Self {
        self.resolution_mode = resolution_mode;
        self
    }

    /// Sets the [`Prerelease`] policy.
    #[must_use]
    pub fn prerelease(mut self, prerelease: Prerelease) -> Self {
        self.prerelease = prerelease;
        self
    }

    /// Sets the dependency mode.
    #[must_use]
    pub fn dependency_mode(mut self, dependency_mode: DependencyMode) -> Self {
        self.dependency_mode = dependency_mode;
        self
    }

    /// Sets the multi-version mode.
    #[must_use]
    pub fn fork_strategy(mut self, fork_strategy: ForkStrategy) -> Self {
        self.fork_strategy = fork_strategy;
        self
    }

    /// Sets the exclusion date.
    #[must_use]
    pub fn exclude_newer(mut self, exclude_newer: ExcludeNewer) -> Self {
        self.exclude_newer = exclude_newer;
        self
    }

    /// Sets the index strategy.
    #[must_use]
    pub fn index_strategy(mut self, index_strategy: IndexStrategy) -> Self {
        self.index_strategy = index_strategy;
        self
    }

    /// Sets the environments that require artifact coverage.
    #[must_use]
    pub fn artifact_environments(mut self, artifact_environments: SupportedEnvironments) -> Self {
        self.artifact_environments = artifact_environments;
        self
    }

    /// Sets the [`Flexibility`].
    #[must_use]
    pub fn flexibility(mut self, flexibility: Flexibility) -> Self {
        self.flexibility = flexibility;
        self
    }

    /// Sets the [`BuildOptions`].
    #[must_use]
    pub fn build_options(mut self, build_options: BuildOptions) -> Self {
        self.build_options = build_options;
        self
    }

    /// Sets the [`TorchStrategy`].
    #[must_use]
    pub fn torch_backend(mut self, torch_backend: Option<TorchStrategy>) -> Self {
        self.torch_backend = torch_backend;
        self
    }

    /// Builds the options.
    pub fn build(self) -> Options {
        Options {
            resolution_mode: self.resolution_mode,
            prerelease: self.prerelease,
            dependency_mode: self.dependency_mode,
            fork_strategy: self.fork_strategy,
            exclude_newer: self.exclude_newer,
            index_strategy: self.index_strategy,
            artifact_environments: self.artifact_environments,
            flexibility: self.flexibility,
            build_options: self.build_options,
            torch_backend: self.torch_backend,
        }
    }
}

/// Whether the [`Options`] are configurable or fixed.
///
/// Applies to the [`ResolutionMode`], [`Prerelease`], and [`DependencyMode`] fields.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum Flexibility {
    /// The setting is configurable.
    #[default]
    Configurable,
    /// The setting is fixed.
    Fixed,
}
