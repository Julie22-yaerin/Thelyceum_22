/*
 * Zed Attack Proxy (ZAP) and its related class files.
 *
 * ZAP is an HTTP/HTTPS proxy for assessing web application security.
 *
 * Copyright 2022 The ZAP Development Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.zaproxy.zap.control;

/**
 * An {@code UninstallationProgressCallback} that does nothing.
 *
 * <p>A "{@code null}" object, for use when no callback is needed during the uninstallation process.
 */
class NullUninstallationProgressCallBack implements AddOnUninstallationProgressCallback {

    private static final NullUninstallationProgressCallBack SINGLETON =
            new NullUninstallationProgressCallBack();

    private NullUninstallationProgressCallBack() {}

    /**
     * Gets the singleton.
     *
     * @return the {@code NullUninstallationProgressCallBack}.
     */
    public static NullUninstallationProgressCallBack getSingleton() {
        return SINGLETON;
    }

    @Override
    public void uninstallingAddOn(AddOn addOn, boolean updating) {}

    @Override
    public void activeScanRulesWillBeRemoved(int numberOfRules) {}

    @Override
    public void activeScanRuleRemoved(String name) {}

    @Override
    public void passiveScanRulesWillBeRemoved(int numberOfRules) {}

    @Override
    public void passiveScanRuleRemoved(String name) {}

    @Override
    public void filesWillBeRemoved(int numberOfFiles) {}

    @Override
    public void fileRemoved() {}

    @Override
    public void extensionsWillBeRemoved(int numberOfExtensions) {}

    @Override
    public void extensionRemoved(String name) {}

    @Override
    public void addOnUninstalled(boolean uninstalled) {}
}
