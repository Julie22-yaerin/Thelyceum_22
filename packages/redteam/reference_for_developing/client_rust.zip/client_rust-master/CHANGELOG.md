# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.25.0]

### Added

- Added native histogram support, including native-only histograms and
  histograms with both classic and native buckets.

- Added an off-by-default `protobuf-protox` feature to build protobuf support
  without requiring an external `protoc` binary.

### Changed

- Updated `prost`, `prost-build`, and `prost-types` dependencies to `v0.14`.
- The `prometheus_protobuf` feature generates and encodes Prometheus
  `io.prometheus.client` protobuf messages from `metrics.proto` rather than the
  OpenMetrics protobuf data model.
  See [Issue](https://github.com/prometheus/OpenMetrics/issues/296) for more context.
  The `protobuf` and `openmetrics_protobuf` features retain the old, deprecated, OpenMetrics protobuf support which will
  be removed in a future release.

## [0.24.1]

### Added

- `EncodeGaugeValue` is implemented for `usize` and `isize`, and
  `EncodeCounterValue` is implemented for `usize`. See [PR 282].

### Fixed

- `EncodeGaugeValue`, `EncodeCounterValue` and `EncodeExemplarValue` now use
  fewer `as` casts in their implementation. This caught an issue where
  `EncodeGaugeValue` would not error when encoding some `u64`s that don't fit
  in a `i64`. See [PR 281].
- Filter out empty metric families, to match the go client. See [PR 279].
- `Histogram` now exposes `count()` and `sum()` methods when the `test-util`
  feature is enabled. See [PR 242].
- `Family` now exposes a `contains()` method when the `test-util` feature
  is enabled. See [PR 245].
- `Family` now exposes `len()` and `is_empty()` methods when the
  `test-util` feature is enabled. See [PR 246].

[PR 279]: https://github.com/prometheus/client_rust/pull/279
[PR 281]: https://github.com/prometheus/client_rust/pull/281
[PR 242]: https://github.com/prometheus/client_rust/pull/242
[PR 245]: https://github.com/prometheus/client_rust/pull/245
[PR 246]: https://github.com/prometheus/client_rust/pull/246
[PR 281]: https://github.com/prometheus/client_rust/pull/281
[PR 282]: https://github.com/prometheus/client_rust/pull/282

## [0.24.0]

### Added

- `EncodeLabelSet` is now implemented for tuples `(A: EncodeLabelSet, B: EncodeLabelSet)`.
   See [PR 257].

- `Family::get_or_create_owned` can access a metric in a labeled family. This
   method avoids the risk of runtime deadlocks at the expense of creating an
   owned type. See [PR 244].

- `impl<T: Collector> Collector for std::sync::Arc<T>`.
   See [PR 273].

[PR 244]: https://github.com/prometheus/client_rust/pull/244
[PR 257]: https://github.com/prometheus/client_rust/pull/257
[PR 273]: https://github.com/prometheus/client_rust/pull/273

### Changed

- `EncodeLabelSet::encode()` now accepts a mutable reference to its encoder parameter.
- Exemplar timestamps can now be passed, which are required for `convert_classic_histograms_to_nhcb: true`
  in Prometheus scraping. See [PR 276].

[PR 276]: https://github.com/prometheus/client_rust/pull/276

## [0.23.1]

### Changed

- `Histogram::new` now accepts an `IntoIterator` argument, rather than an `Iterator`.
  See [PR 243].

[PR 243]: https://github.com/prometheus/client_rust/pull/243

## [0.23.0]

### Changed

- `ConstCounter::new` now requires specifying the type of literal arguments, like this: `ConstCounter::new(42u64);`.
  See [PR 173].

- Update `prost` dependencies to `v0.12`.
  See [PR 198].

- Implement `Atomic<u64>` for `AtomicU64` for gauges.
  See [PR 226].

- Implement `EnableLabelValue` for `bool`.
  See [PR 237]

[PR 173]: https://github.com/prometheus/client_rust/pull/173
[PR 198]: https://github.com/prometheus/client_rust/pull/198
[PR 226]: https://github.com/prometheus/client_rust/pull/226
[PR 237]: https://github.com/prometheus/client_rust/pull/237

### Added

- Support `i32`/`f32` for `Gauge` and `u32`/`f32` for `Counter`/`CounterWithExemplar`.
  See [PR 173] and [PR 216].

- Supoort `Arc<String>` for `EncodeLabelValue`.
  See [PR 217].

- Add `histogram::exponential_buckets_range`.
  See [PR 233].

- Added `get` method to `Family`.
  See [PR 234].

[PR 173]: https://github.com/prometheus/client_rust/pull/173
[PR 216]: https://github.com/prometheus/client_rust/pull/216
[PR 217]: https://github.com/prometheus/client_rust/pull/217
[PR 233]: https://github.com/prometheus/client_rust/pull/233
[PR 234]: https://github.com/prometheus/client_rust/pull/234

### Fixed

- Don't prepend `,` when encoding empty family label set.
  See [PR 175].

[PR 175]: https://github.com/prometheus/client_rust/pull/175

## [0.22.3]

### Added

- Added `encode_registry` and `encode_eof` functions to `text` module.
  See [PR 205].

  [PR 205]: https://github.com/prometheus/client_rust/pull/205

- Support all platforms with 32 bit atomics lacking 64 bit atomics.
  See [PR 203].

[PR 203]: https://github.com/prometheus/client_rust/pull/203

## [0.22.2]

### Added

- Added `Gauge<u32, AtomicU32>` implementation.
  See [PR 191].

[PR 191]: https://github.com/prometheus/client_rust/pull/191

## [0.22.1]

### Added

- Added `EncodeLabelValue` and `EncodeLabelKey` implementations for `Arc`,
  `Rc`, and `Box`.
  See [PR 188].

[PR 188]: https://github.com/prometheus/client_rust/pull/188

## [0.22.0]

### Changed

- Simplify `Collector` `trait` by enabling `Collector::collect` to encode metrics directly with a `DescriptorEncoder`.
  See [PR 149] for details.

[PR 149]: https://github.com/prometheus/client_rust/pull/149

## [0.21.2]

### Added

- Added `sub_registry_with_labels` method to `Registry`.
  See [PR 145].
- Added `with_labels` and `with_prefix_and_labels` constructors to `Registry`.
  See [PR 147].

[PR 145]: https://github.com/prometheus/client_rust/pull/145
[PR 147]: https://github.com/prometheus/client_rust/pull/147

## [0.21.1]

### Added

- Implement `EncodeLabelValue` for `Option<T>`.
  See [PR 137].

[PR 137]: https://github.com/prometheus/client_rust/pull/137

## [0.21.0]

### Changed

- Replace `impl EncodeMetric for RefCell<T>` with a new type `ConstFamily` implementing `EncodeMetric`.

## [0.20.0]

### Added

- Introduce `Collector` abstraction allowing users to provide additional metrics
  and their description on each scrape. See [PR 82].

- Introduce a `#[prometheus(flatten)]` attribute which can be used when deriving `EncodeLabelSet`, allowing
  a nested struct to be flattened during encoding. See [PR 118].

  For example:

  ```rust
  #[derive(EncodeLabelSet, Hash, Clone, Eq, PartialEq, Debug)]
  struct CommonLabels {
      a: u64,
      b: u64,
  }
  #[derive(EncodeLabelSet, Hash, Clone, Eq, PartialEq, Debug)]
  struct Labels {
      unique: u64,
      #[prometheus(flatten)]
      common: CommonLabels,
  }
  ```

  Would be encoded as:

  ```
  my_metric{a="42",b="42",unique="42"} 42
  ```

### Fixed

- Fix label encoding in protobuf feature. See [PR 123].

[PR 82]: https://github.com/prometheus/client_rust/pull/82
[PR 118]: https://github.com/prometheus/client_rust/pull/118
[PR 123]: https://github.com/prometheus/client_rust/pull/123

## [0.19.0]

This is a large release including multiple breaking changes. Major user-facing
improvement of this release is support for the OpenMetrics Protobuf format.

### Upgrade guide:

- Don't box before registering.

  ```diff
    registry.register(
        "my_metric",
        "This is my metric",
  -      Box::new(my_metric.clone()),
  +      my_metric.clone(),
    );
  ```

- Gauge uses `i64` instead of `u64`.

  ```diff
    my_gauge
  -     .set(42u64);
  +     .set(42i64);
  ```

- Derive `EncodeLabelSet` for `struct` and `EncodeLabelValue` for `enum` instead of just `Encode` for all and require `Debug`.

  ```diff
  - #[derive(Clone, Hash, PartialEq, Eq, Encode)]
  + #[derive(Clone, Hash, PartialEq, Eq, EncodeLabelSet, Debug)]
    struct Labels {
        path: String,
        method: Method,
        some_number: u64,
    }

  - #[derive(Clone, Hash, PartialEq, Eq, Encode)]
  + #[derive(Clone, Hash, PartialEq, Eq, EncodeLabelValue, Debug)]
    enum Method {
        Get,
        #[allow(dead_code)]
        Put,
    }
  ```

- Encode as utf-8 and not as `[u8]`.

  ```diff
  - let mut buffer = vec![];
  + let mut buffer = String::new();
    encode(&mut buffer, &registry).unwrap();
  ```

For details on each of these, see changelog entries below.

### Added

- Added support for the OpenMetrics protobuf format. See [PR 83].
- Added a `remove` method to `Family` to allow the removal of a specified label
  set from a family. See [PR 85].
- Added a `clear` method to `Family` to allow the removal of all label sets
  from a family. See [PR 85].
- Impl `TypedMetric` for `CounterWithExemplar` and `HistogramWithExemplar`, so that they can be used with `Family`. See [PR 96].

### Changed

- Always use dynamic dispatch on `Registry`, i.e. remove generic type parameter `M` from `Registry`. See [PR 105].
- Refactor encoding. See [PR 105].
  - Introducing separate traits to encode
    - value (e.g. `EncodeCounterValue`)
    - label set (`EncodeLabelSet`), derivable for structs via `prometheus-client-derive-encode`
    - label (`EncodeLabel`)
    - label key (`EncodeLabelKey`)
    - label value (`EncodeLabelValue`), derivable for enums via `prometheus-client-derive-encode`
  - Encode as UTF-8 strings, not bytes. I.e. use `std::fmt::Write` instead of `std::io::Write`.
- Use signed integers for `Gauge` for compliance with OpenMetrics protobuf
  format. See [PR 105].

[PR 83]: https://github.com/prometheus/client_rust/pull/83
[PR 85]: https://github.com/prometheus/client_rust/pull/85
[PR 96]: https://github.com/prometheus/client_rust/pull/96
[PR 105]: https://github.com/prometheus/client_rust/pull/105

## [0.18.1]

### Fixed

- Fix race condition in `Family::get_or_create`. See [PR 102].

[PR 102]: https://github.com/prometheus/client_rust/pull/102

## [0.18.0]

### Changed

- Use `parking_lot` instead of `std::sync::*`.

  Before `proemtheus-client` would use the `owning_ref` crate to map the target
  of a `std::sync::RwLockReadGuard`. `owning_ref` has multiple unsoundness
  issues, see https://rustsec.org/advisories/RUSTSEC-2022-0040.html. Instead of
  replacing `owning_ref` with a similar crate, we switch to locking via
  `parking_lot` which supports the above mapping natively.

  See [PR 78] and [issue 77].

[PR 78]: https://github.com/prometheus/client_rust/pull/78
[issue 77]: https://github.com/prometheus/client_rust/issues/77

## [0.17.0]

### Changed
- Updates to Rust 2021 Edition. See [PR 65].

### Added
- Added a `with_prefix` method to `Registry` to allow initializing a registry with a prefix. See [PR 70].
- Added `Debug` implementations on most public types that were missing them. See [PR 71].
- Added example for actix-web framework. See [PR 76].

### Removed
- Remove `Add` trait implementation for a private type which lead to compile time conflicts with existing `Add` implementations e.g. on `String`. See [PR 69].

[PR 65]: https://github.com/prometheus/client_rust/pull/65
[PR 69]: https://github.com/prometheus/client_rust/pull/69
[PR 70]: https://github.com/prometheus/client_rust/pull/70
[PR 71]: https://github.com/prometheus/client_rust/pull/71
[PR 76]: https://github.com/prometheus/client_rust/pull/76

## [0.16.0]

### Changed

- Require `Registry` default generic type `SendEncodeMetric` to be `Sync`. See [PR 58].

[PR 58]: https://github.com/prometheus/client_rust/pull/58

## [0.15.1] - 2022-02-04

### Added

- Expose `Encoder` methods. See [PR 41].

### Changed

- Use `AtomicU32` on platforms that don't support `AtomicU64`. See [PR 42].

[PR 41]: https://github.com/prometheus/client_rust/pull/41
[PR 42]: https://github.com/prometheus/client_rust/pull/42

## [0.15.0] - 2022-01-16

### Changed

- Release as `prometheus-client` and `prometheus-client-derive-text-encode`.

## [0.14.0] - 2021-12-29

### Changed

- Update to `itoa` `v1`. See [PR 28].
- Update to `dtoa` `v1`. See [PR 27].

### Added

- Implement `Gauge::dec` and `Gauge::dec_by`. See [PR 30].

[PR 28]: https://github.com/prometheus/client_rust/pull/28
[PR 27]: https://github.com/prometheus/client_rust/pull/27
[PR 30]: https://github.com/prometheus/client_rust/pull/30

## [0.13.0] - 2021-11-21

_Note: This was initially released as `v0.12.1` but later on yanked due to it
including a breaking change. See [PR 24] for details._

### Added

- Allow family to use constructors that do not coerce to function pointers. See [PR 21].

[PR 21]: https://github.com/prometheus/client_rust/pull/21
[PR 24]: https://github.com/prometheus/client_rust/pull/24

## [0.12.0] - 2021-08-07

### Added

- Add `Registry::sub_registry_with_label`. See [PR 20].

### Changed

- Rename `Registry::sub_registry` to `Registry::sub_registry_with_prefix`. See
  [PR 20].

[PR 20]: https://github.com/prometheus/client_rust/pull/20

## [0.11.2] - 2021-06-09
### Fixed
- Do not separate labels with spaces.

## [0.11.1] - 2021-06-08
### Fixed
- Encode Info metric labels.

## [0.11.0] - 2021-06-08
### Added
- Add support for OpenMetrics Info metrics (see [PR 18]).

[PR 18]: https://github.com/prometheus/client_rust/pull/18

## [0.10.1] - 2021-05-31
### Added
- Implement `Encode` for `u32`.

### Fixed
- Update to prometheus-client-derive-text-encode v0.1.1 which handles keyword
  identifiers aka raw identifiers

  https://github.com/prometheus/client_rust/pull/16

## [0.10.0] - 2021-04-29
### Added
- Added `metrics::histogram::linear_buckets`.
  https://github.com/prometheus/client_rust/issues/13

### Changed
- Renamed `metrics::histogram::exponential_series` to
  `metrics::histogram::exponential_buckets`.
  https://github.com/prometheus/client_rust/issues/13
