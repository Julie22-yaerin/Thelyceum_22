use std::env;
use std::time::Duration;

/// Default Zipkin collector endpoint
const DEFAULT_COLLECTOR_ENDPOINT: &str = "http://127.0.0.1:9411/api/v2/spans";

/// HTTP endpoint for Zipkin collector.
/// e.g. "http://localhost:9411/api/v2/spans"
pub(crate) const ENV_ENDPOINT: &str = "OTEL_EXPORTER_ZIPKIN_ENDPOINT";

/// Maximum time the Zipkin exporter will wait for each batch export
const ENV_TIMEOUT: &str = "OTEL_EXPORTER_ZIPKIN_TIMEOUT";

/// Default Zipkin timeout in milliseconds
const DEFAULT_COLLECTOR_TIMEOUT: Duration = Duration::from_millis(10_000);

// This is for clippy to work with only the reqwest-rustls feature enabled
#[allow(unused)]
pub(crate) fn get_timeout() -> Duration {
    match env::var(ENV_TIMEOUT).ok().filter(|var| !var.is_empty()) {
        Some(timeout) => match timeout.parse() {
            Ok(timeout) => Duration::from_millis(timeout),
            Err(e) => {
                eprintln!("{ENV_TIMEOUT} malformed defaulting to 10000: {e}");
                DEFAULT_COLLECTOR_TIMEOUT
            }
        },
        None => DEFAULT_COLLECTOR_TIMEOUT,
    }
}

pub(crate) fn get_endpoint() -> String {
    match env::var(ENV_ENDPOINT).ok().filter(|var| !var.is_empty()) {
        Some(endpoint) => endpoint,
        None => DEFAULT_COLLECTOR_ENDPOINT.to_string(),
    }
}

#[test]
fn test_collector_defaults() {
    // Ensure the variables are undefined.
    assert_eq!(DEFAULT_COLLECTOR_TIMEOUT, get_timeout());
    assert_eq!(DEFAULT_COLLECTOR_ENDPOINT, get_endpoint());

    // Bad Timeout Value
    temp_env::with_var(ENV_TIMEOUT, Some("a"), || {
        assert_eq!(DEFAULT_COLLECTOR_TIMEOUT, get_timeout());
    });

    // Good Timeout Value
    temp_env::with_var(ENV_TIMEOUT, Some("777"), || {
        assert_eq!(Duration::from_millis(777), get_timeout());
    });

    // Custom Endpoint
    let custom_endpoint = "https://example.com/api/v2/spans";
    temp_env::with_var(ENV_ENDPOINT, Some(custom_endpoint), || {
        assert_eq!(custom_endpoint, get_endpoint());
    });
}
