#![cfg(not(windows))]

use clap::error::ErrorKind;
use clap::Parser;
use std::ffi::OsString;
use std::os::unix::ffi::OsStringExt;

#[derive(Parser, Debug, PartialEq, Eq)]
struct Positional {
    arg: String,
}

#[derive(Parser, Debug, PartialEq, Eq)]
struct Named {
    #[arg(short, long)]
    arg: String,
}

#[test]
fn invalid_utf8_strict_positional() {
    let m = Positional::try_parse_from(vec![OsString::from(""), OsString::from_vec(vec![0xe9])]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[test]
fn invalid_utf8_strict_option_short_space() {
    let m = Named::try_parse_from(vec![
        OsString::from(""),
        OsString::from("-a"),
        OsString::from_vec(vec![0xe9]),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[test]
fn invalid_utf8_strict_option_short_equals() {
    let m = Named::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0x2d, 0x61, 0x3d, 0xe9]),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[test]
fn invalid_utf8_strict_option_short_no_space() {
    let m = Named::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0x2d, 0x61, 0xe9]),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[test]
fn invalid_utf8_strict_option_long_space() {
    let m = Named::try_parse_from(vec![
        OsString::from(""),
        OsString::from("--arg"),
        OsString::from_vec(vec![0xe9]),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[test]
fn invalid_utf8_strict_option_long_equals() {
    let m = Named::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0x2d, 0x2d, 0x61, 0x72, 0x67, 0x3d, 0xe9]),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[derive(Parser, Debug, PartialEq, Eq)]
struct PositionalOs {
    arg: OsString,
}

#[derive(Parser, Debug, PartialEq, Eq)]
struct NamedOs {
    #[arg(short, long)]
    arg: OsString,
}

#[test]
fn invalid_utf8_positional() {
    let r = PositionalOs::try_parse_from(vec![OsString::from(""), OsString::from_vec(vec![0xe9])]);
    assert_eq!(
        r.unwrap(),
        PositionalOs {
            arg: OsString::from_vec(vec![0xe9])
        }
    );
}

#[test]
fn invalid_utf8_option_short_space() {
    let r = NamedOs::try_parse_from(vec![
        OsString::from(""),
        OsString::from("-a"),
        OsString::from_vec(vec![0xe9]),
    ]);
    assert_eq!(
        r.unwrap(),
        NamedOs {
            arg: OsString::from_vec(vec![0xe9])
        }
    );
}

#[test]
fn invalid_utf8_option_short_equals() {
    let r = NamedOs::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0x2d, 0x61, 0x3d, 0xe9]),
    ]);
    assert_eq!(
        r.unwrap(),
        NamedOs {
            arg: OsString::from_vec(vec![0xe9])
        }
    );
}

#[test]
fn invalid_utf8_option_short_no_space() {
    let r = NamedOs::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0x2d, 0x61, 0xe9]),
    ]);
    assert_eq!(
        r.unwrap(),
        NamedOs {
            arg: OsString::from_vec(vec![0xe9])
        }
    );
}

#[test]
fn invalid_utf8_option_long_space() {
    let r = NamedOs::try_parse_from(vec![
        OsString::from(""),
        OsString::from("--arg"),
        OsString::from_vec(vec![0xe9]),
    ]);
    assert_eq!(
        r.unwrap(),
        NamedOs {
            arg: OsString::from_vec(vec![0xe9])
        }
    );
}

#[test]
fn invalid_utf8_option_long_equals() {
    let r = NamedOs::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0x2d, 0x2d, 0x61, 0x72, 0x67, 0x3d, 0xe9]),
    ]);
    assert_eq!(
        r.unwrap(),
        NamedOs {
            arg: OsString::from_vec(vec![0xe9])
        }
    );
}

#[derive(Debug, PartialEq, Parser)]
enum External {
    #[command(external_subcommand)]
    Other(Vec<String>),
}

#[test]
fn refuse_invalid_utf8_subcommand_with_allow_external_subcommands() {
    let m = External::try_parse_from(vec![
        OsString::from(""),
        OsString::from_vec(vec![0xe9]),
        OsString::from("normal"),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[test]
fn refuse_invalid_utf8_subcommand_args_with_allow_external_subcommands() {
    let m = External::try_parse_from(vec![
        OsString::from(""),
        OsString::from("subcommand"),
        OsString::from("normal"),
        OsString::from_vec(vec![0xe9]),
        OsString::from("--another_normal"),
    ]);
    assert!(m.is_err());
    assert_eq!(m.unwrap_err().kind(), ErrorKind::InvalidUtf8);
}

#[derive(Debug, PartialEq, Parser)]
enum ExternalOs {
    #[command(external_subcommand)]
    Other(Vec<OsString>),
}

#[test]
fn allow_invalid_utf8_subcommand_args_with_allow_external_subcommands() {
    let m = ExternalOs::try_parse_from(vec![
        OsString::from(""),
        OsString::from("subcommand"),
        OsString::from("normal"),
        OsString::from_vec(vec![0xe9]),
        OsString::from("--another_normal"),
    ]);
    assert_eq!(
        m.unwrap(),
        ExternalOs::Other(vec![
            OsString::from("subcommand"),
            OsString::from("normal"),
            OsString::from_vec(vec![0xe9]),
            OsString::from("--another_normal"),
        ])
    );
}
