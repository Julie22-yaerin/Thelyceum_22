pub mod metadata;
pub mod schema;
pub mod transforms;

use crate::filesystem::config::{IcebergCatalog, IcebergPartitioning, IcebergSink};
use crate::filesystem::sink::FinishedFile;
use crate::filesystem::sink::iceberg::metadata::build_datafile_from_meta;
use crate::filesystem::sink::iceberg::schema::add_parquet_field_ids;
use anyhow::anyhow;
use arrow::datatypes::Schema;
use arroyo_rpc::connector_err;
use arroyo_rpc::errors::{DataflowError, DataflowResult, ErrorDomain, RetryHint};
use arroyo_storage::StorageProvider;
use arroyo_types::TaskInfo;
use iceberg::spec::ManifestFile;
use iceberg::table::Table;
use iceberg::transaction::{ApplyTransactionAction, Transaction};
use iceberg::{Catalog, ErrorKind, TableCreation, TableIdent};
use iceberg_catalog_rest::{RestCatalog, RestCatalogConfig};
use itertools::Itertools;
use regex::Regex;
use reqwest::Client;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::error::Error;
use std::future::Future;
use std::iter::once;
use std::sync::Arc;
use std::time::Duration;
use tracing::{debug, info};
use uuid::Uuid;

const CONFIG_MAPPINGS: [(&str, &str); 4] = [
    ("s3.region", "aws_region"),
    ("s3.endpoint", "aws_endpoint"),
    ("s3.access-key-id", "aws_access_key_id"),
    ("s3.secret-access-key", "aws_secret_access_key"),
];

const ARROYO_COMMIT_ID: &str = "arroyo.commit-id";
const ICEBERG_COMMIT_TIMEOUT: Duration = Duration::from_secs(5 * 60);

#[derive(Debug)]
pub struct IcebergTable {
    pub task_info: Option<Arc<TaskInfo>>,
    pub catalog: RestCatalog,
    pub storage_options: HashMap<String, String>,
    pub table_ident: TableIdent,
    pub location_path: Option<String>,
    pub table: Option<Table>,
    pub manifest_files: Vec<ManifestFile>,
    pub partitioning: IcebergPartitioning,
}

pub fn to_hex(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for &b in bytes {
        out.push(HEX[(b >> 4) as usize] as char);
        out.push(HEX[(b & 0xf) as usize] as char);
    }
    out
}

/// Unique transaction ID per epoch so we can always determine if we've already committed for
/// this epoch without needing to scan files
fn transaction_id(task_info: &TaskInfo, epoch: u32, table_uuid: Uuid) -> String {
    let mut h = Sha256::new();
    h.update("arroyo-txid-v1");
    h.update([0]);
    h.update(&task_info.job_id);
    h.update([0]);
    h.update(&task_info.operator_id);
    h.update([0]);
    h.update(epoch.to_be_bytes());
    h.update([0]);
    h.update(table_uuid.as_bytes());

    let digest = h.finalize();
    let short = &digest[..16]; // 16 bytes is enough

    format!("tx-{}", to_hex(short))
}

fn extract_catalog_status(display: &str) -> Option<u16> {
    let re = Regex::new(r"status: (\d{3})").unwrap();
    re.captures(display).and_then(|c| c[1].parse().ok())
}

fn extract_catalog_message(display: &str) -> Option<String> {
    // Capture the full JSON string value, such as `NoSuchBucket`
    let re = Regex::new(r#""message"\s*:\s*"((?:[^"\\]|\\.)*)""#).unwrap();
    re.captures(display).map(|c| c[1].to_string())
}

fn map_iceberg_error(error: iceberg::Error) -> DataflowError {
    debug!(error = ?error, "iceberg catalog error");

    let (domain, msg) = match error.kind() {
        ErrorKind::PreconditionFailed => (ErrorDomain::Internal, error.to_string()),
        ErrorKind::DataInvalid | ErrorKind::NamespaceNotFound | ErrorKind::TableNotFound => {
            (ErrorDomain::User, error.to_string())
        }
        ErrorKind::Unexpected => {
            // For Unexpected errors from iceberg-catalog-rest, the HTTP status and response
            // body are embedded in the error's Display output as context fields. Extract the
            // status to determine the domain, and try to pull out a clean error message.
            let display = error.to_string();
            let status = extract_catalog_status(&display);

            let domain = match status {
                Some(400..=499) => ErrorDomain::User,
                Some(_) => ErrorDomain::External,
                // No status found — could be a transport error or something else
                None => {
                    if let Some(source) = error.source() {
                        if let Some(err) = source.downcast_ref::<reqwest::Error>() {
                            if err.status().map(|c| c.is_client_error()).unwrap_or(false) {
                                ErrorDomain::User
                            } else {
                                ErrorDomain::External
                            }
                        } else {
                            ErrorDomain::External
                        }
                    } else {
                        ErrorDomain::External
                    }
                }
            };

            let msg = if let Some(catalog_msg) = extract_catalog_message(&display) {
                format!("Iceberg catalog error: {catalog_msg}")
            } else {
                format!("Iceberg catalog error: {error}")
            };

            (domain, msg)
        }
        _ => (ErrorDomain::External, error.to_string()),
    };

    DataflowError::ConnectorError {
        domain,
        retry: if matches!(domain, ErrorDomain::User) {
            RetryHint::NoRetry
        } else {
            RetryHint::WithBackoff
        },
        error: msg,
        source: error.source().map(|e| anyhow!("{}", e)),
    }
}

async fn run_with_iceberg_timeout<T>(
    timeout: Duration,
    operation: &'static str,
    future: impl Future<Output = iceberg::Result<T>>,
) -> DataflowResult<T> {
    tokio::time::timeout(timeout, future)
        .await
        .map_err(|_| {
            connector_err!(
                External,
                WithBackoff,
                "timed out after {:?} while {}",
                timeout,
                operation
            )
        })?
        .map_err(map_iceberg_error)
}

impl IcebergTable {
    pub fn new(catalog: &IcebergCatalog, sink: &IcebergSink) -> anyhow::Result<Self> {
        match catalog {
            IcebergCatalog::Rest(rest) => {
                let mut props = HashMap::new();
                if let Some(token) = &rest.token {
                    props.insert("token".to_string(), token.sub_env_vars()?);
                }

                for (k, v) in &sink.storage_options {
                    if let Some((mapped, _)) = CONFIG_MAPPINGS.iter().find(|(_, n)| n == k) {
                        props.insert(mapped.to_string(), v.to_string());
                    }
                }

                let config = RestCatalogConfig::builder()
                    .uri(rest.url.clone())
                    .warehouse_opt(rest.warehouse.clone())
                    .props(props)
                    .client(Some(
                        Client::builder().timeout(ICEBERG_COMMIT_TIMEOUT).build()?,
                    ))
                    .build();

                let catalog = RestCatalog::new(config);

                let table_ident = TableIdent::from_strs(
                    sink.namespace
                        .as_str()
                        .split(".")
                        .chain(once(sink.table_name.as_str())),
                )?;

                Ok(Self {
                    task_info: None,
                    catalog,
                    location_path: sink.location_path.clone(),
                    storage_options: sink.storage_options.clone(),
                    table_ident,
                    table: None,
                    manifest_files: vec![],
                    partitioning: sink.partitioning.clone(),
                })
            }
        }
    }

    pub async fn load_or_create(
        &mut self,
        task_info: Arc<TaskInfo>,
        schema: &Schema,
    ) -> Result<&Table, DataflowError> {
        if let Some(ref table) = self.table {
            return Ok(table);
        }

        self.task_info = Some(task_info);

        if !self
            .catalog
            .namespace_exists(self.table_ident.namespace())
            .await
            .map_err(map_iceberg_error)?
            && let Err(e) = self
                .catalog
                .create_namespace(self.table_ident.namespace(), HashMap::new())
                .await
            && e.kind() != iceberg::ErrorKind::NamespaceAlreadyExists
        {
            return Err(map_iceberg_error(e));
        }

        let table = if !self
            .catalog
            .table_exists(&self.table_ident)
            .await
            .map_err(map_iceberg_error)?
        {
            let schema_with_ids = add_parquet_field_ids(schema);
            let iceberg_schema = iceberg::arrow::arrow_schema_to_schema(&schema_with_ids)
                .map_err(map_iceberg_error)?;

            let partition_spec = self
                .partitioning
                .as_partition_spec(Arc::new(iceberg_schema.clone()))
                .map_err(map_iceberg_error)?;

            match self
                .catalog
                .create_table(
                    self.table_ident.namespace(),
                    TableCreation::builder()
                        .location_opt(self.location_path.clone())
                        .schema(iceberg_schema)
                        .partition_spec(partition_spec)
                        .name(self.table_ident.name.clone())
                        .build(),
                )
                .await
            {
                Ok(table) => table,
                Err(e) if e.kind() == iceberg::ErrorKind::TableAlreadyExists => self
                    .catalog
                    .load_table(&self.table_ident)
                    .await
                    .map_err(map_iceberg_error)?,
                Err(e) => {
                    return Err(map_iceberg_error(e));
                }
            }
        } else {
            self.catalog
                .load_table(&self.table_ident)
                .await
                .map_err(map_iceberg_error)?
        };

        self.table = Some(table);

        Ok(self.table.as_ref().unwrap())
    }

    pub async fn get_storage_provider(
        &mut self,
        task_info: Arc<TaskInfo>,
        schema: &Schema,
    ) -> Result<StorageProvider, DataflowError> {
        let storage_options = self.storage_options.clone();
        let table = self.load_or_create(task_info, schema).await?;
        let (_, mut config) = table.file_io().clone().into_builder().into_parts();

        let mut our_config = HashMap::new();
        for (from, to) in CONFIG_MAPPINGS {
            if let Some(v) = config.remove(from) {
                our_config.insert(to.to_string(), v);
            }
        }

        if let Some(path_style) = our_config.remove("s3.path-style-access") {
            let path_style = path_style.to_lowercase();
            let enabled = path_style == "true" || path_style == "t" || path_style == "1";
            our_config.insert(
                "virtual_hosted_style_request".to_string(),
                (!enabled).to_string(),
            );
        }

        storage_options.into_iter().for_each(|(k, v)| {
            our_config.insert(k, v);
        });

        let mut location = table.metadata().location().to_string();
        if !location.ends_with('/') {
            location.push('/');
        }
        location.push_str("data/");

        StorageProvider::for_url_with_options(&location, our_config).await.map_err(|e| {
            connector_err!(User, NoRetry, source: e.into(), "failed to construct storage provider")
        })
    }

    async fn refresh_table(&mut self, operation: &'static str) -> DataflowResult<()> {
        self.table = Some(
            run_with_iceberg_timeout(
                ICEBERG_COMMIT_TIMEOUT,
                operation,
                self.catalog.load_table(&self.table_ident),
            )
            .await?,
        );
        Ok(())
    }

    pub async fn commit(
        &mut self,
        epoch: u32,
        finished_files: &[FinishedFile],
    ) -> DataflowResult<()> {
        if finished_files.is_empty() {
            debug!("no new files, skipping commit");
            return Ok(());
        }

        self.refresh_table("loading latest Iceberg table metadata before commit")
            .await?;
        let table = self.table.as_ref().expect("table must have been loaded");

        let tx_id = transaction_id(
            self.task_info.as_ref().unwrap(),
            epoch,
            table.metadata().uuid(),
        );

        if let Some(current_snapshot) = table.metadata().current_snapshot()
            && let Some(existing_tx_id) = current_snapshot
                .summary()
                .additional_properties
                .get(ARROYO_COMMIT_ID)
            && *existing_tx_id == tx_id
        {
            // we've already committed this epoch (but crashed before it could be records), so we're good
            info!("epoch {epoch} already committed to iceberg, skipping");
            return Ok(());
        }

        let partition_spec_id = table.metadata().default_partition_spec_id();
        let files: Vec<_> = finished_files
            .iter()
            .map(|f| {
                build_datafile_from_meta(
                    table.metadata().current_schema(),
                    f.metadata
                        .as_ref()
                        .expect("metadata not set for Iceberg write"),
                    &self.partitioning,
                    format!(
                        "{}/data/{}",
                        table.metadata().location(),
                        f.filename.clone()
                    ),
                    f.size as u64,
                    partition_spec_id,
                )
            })
            .try_collect()?;

        // Workaround for iceberg-rust 0.6.0 bug: SnapshotProducer drains added_data_files
        // before computing the summary, producing all-zero added-* stats. We inject the
        // correct values via set_snapshot_properties so they appear in the snapshot summary.
        // Fixed upstream in 0.8.0 (https://github.com/apache/iceberg-rust/pull/1767);
        // this workaround can be removed when iceberg-rust is upgraded.
        let added_data_files = files.len().to_string();
        let added_records: u64 = files.iter().map(|f| f.record_count()).sum();
        let added_files_size: u64 = files.iter().map(|f| f.file_size_in_bytes()).sum();

        // commit the transaction in the rest catalog
        debug!(
            message = "starting iceberg commit",
            files = files.len(),
            manifest_files = self.manifest_files.len()
        );
        let tx = Transaction::new(table);
        let tx = tx
            .fast_append()
            .set_snapshot_properties(
                [
                    (ARROYO_COMMIT_ID.to_string(), tx_id),
                    ("added-data-files".to_string(), added_data_files),
                    ("added-records".to_string(), added_records.to_string()),
                    ("added-files-size".to_string(), added_files_size.to_string()),
                ]
                .into_iter()
                .collect(),
            )
            .add_data_files(files)
            .with_check_duplicate(false)
            .apply(tx)
            .map_err(map_iceberg_error)?;

        run_with_iceberg_timeout(
            ICEBERG_COMMIT_TIMEOUT,
            "committing to the Iceberg catalog",
            tx.commit(&self.catalog),
        )
        .await?;
        debug!("finished iceberg catalog commit");
        // the tx.commit call returns the table but the FileIO somehow ends up misconfigured in such
        // a way that breaks future IO operations
        debug!("reloading iceberg table after commit");
        self.refresh_table("reloading Iceberg table metadata after commit")
            .await?;
        debug!("finished iceberg commit");

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_map_iceberg_error_catalog_424() {
        let error = iceberg::Error::new(
            ErrorKind::Unexpected,
            "Received response with unexpected status code",
        )
        .with_context("status", "424 Failed Dependency")
        .with_context("headers", r#"{"date": "Tue, 24 Feb 2026 17:27:50 GMT"}"#)
        .with_context(
            "json",
            r#"{"error":{"message":"Failed to list files in location. Please check the storage credentials.","type":"List","code":424}}"#,
        );

        match map_iceberg_error(error) {
            DataflowError::ConnectorError {
                domain, error: msg, ..
            } => {
                assert_eq!(domain, ErrorDomain::User);
                assert_eq!(
                    msg,
                    "Iceberg catalog error: Failed to list files in location. Please check the storage credentials."
                );
            }
            other => panic!("expected ConnectorError, got: {other:?}"),
        }
    }

    #[test]
    fn test_map_iceberg_error_catalog_403_bare_body() {
        // Simulates a 403 from the catalog with a bare string body (no JSON structure)
        let error = iceberg::Error::new(
            ErrorKind::Unexpected,
            "Received response with unexpected status code",
        )
        .with_context("status", "403 Forbidden")
        .with_context("headers", r#"{"date": "Wed, 25 Feb 2026 16:16:50 GMT"}"#)
        .with_context("json", "Unauthenticated");

        match map_iceberg_error(error) {
            DataflowError::ConnectorError {
                domain, error: msg, ..
            } => {
                assert_eq!(domain, ErrorDomain::User);
                // Falls back to error.message() since no JSON "message" field
                assert!(
                    msg.contains("Received response with unexpected status code"),
                    "{msg}"
                );
            }
            other => panic!("expected ConnectorError, got: {other:?}"),
        }
    }

    #[test]
    fn test_map_iceberg_error_catalog_500() {
        let error = iceberg::Error::new(
            ErrorKind::Unexpected,
            "Received response with unexpected status code",
        )
        .with_context("status", "500 Internal Server Error")
        .with_context(
            "json",
            r#"{"error":{"message":"Internal server error","type":"ServerError","code":500}}"#,
        );

        match map_iceberg_error(error) {
            DataflowError::ConnectorError { domain, .. } => {
                assert_eq!(domain, ErrorDomain::External);
            }
            other => panic!("expected ConnectorError, got: {other:?}"),
        }
    }

    #[test]
    fn test_map_iceberg_error_no_status_falls_back() {
        let error = iceberg::Error::new(ErrorKind::Unexpected, "some opaque error");

        match map_iceberg_error(error) {
            DataflowError::ConnectorError { domain, .. } => {
                assert_eq!(domain, ErrorDomain::External);
            }
            other => panic!("expected ConnectorError, got: {other:?}"),
        }
    }
}
