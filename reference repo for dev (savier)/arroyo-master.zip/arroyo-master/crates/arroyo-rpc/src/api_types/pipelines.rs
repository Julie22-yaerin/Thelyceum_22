use crate::api_types::udfs::Udf;
use crate::errors::ErrorDomain;
use crate::grpc as grpc_proto;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct ValidateQueryPost {
    pub query: String,
    pub udfs: Option<Vec<Udf>>, // needed for query validation but are not themselves validated
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct QueryValidationResult {
    pub graph: Option<PipelineGraph>,
    pub errors: Vec<SqlDiagnostic>,
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq, ToSchema)]
pub struct SqlLocation {
    pub line: u64,
    pub column: u64,
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq, ToSchema)]
pub struct SqlSpan {
    pub start: SqlLocation,
    pub end: SqlLocation,
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq, ToSchema)]
pub struct SqlDiagnostic {
    pub message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub span: Option<SqlSpan>,
}
impl SqlDiagnostic {
    pub fn message(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
            span: None,
        }
    }
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PipelinePost {
    pub name: String,
    pub query: String,
    pub udfs: Option<Vec<Udf>>,
    pub parallelism: u64,
    pub checkpoint_interval_micros: Option<u64>,
    pub state_url: Option<String>,
    pub tags: Option<HashMap<String, String>>,
    /// Per-job environment variables forwarded to workers.
    pub env_vars: Option<HashMap<String, String>>,
    /// Per-job scheduler configuration overlay. The shape mirrors the
    /// controller's global scheduler config (e.g. the
    /// `kubernetes-scheduler.*` block) and is merged on top of it at
    /// scheduling time. An omitted field, `null`, or an empty object
    /// all mean "use the controller's global scheduler config
    /// unchanged".
    pub scheduler_config: Option<serde_json::Value>,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PreviewPost {
    pub query: String,
    pub udfs: Option<Vec<Udf>>,
    #[serde(default)]
    pub enable_sinks: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PipelinePatch {
    pub parallelism: Option<u64>,
    pub checkpoint_interval_micros: Option<u64>,
    pub stop: Option<StopType>,
    /// Per-job environment variables forwarded to workers.
    pub env_vars: Option<HashMap<String, String>>,
    /// Per-job scheduler configuration overlay. The shape mirrors the
    /// controller's global scheduler config (e.g. the
    /// `kubernetes-scheduler.*` block) and is merged on top of it at
    /// scheduling time. An omitted field, `null`, or an empty object
    /// all mean "use the controller's global scheduler config
    /// unchanged".
    pub scheduler_config: Option<serde_json::Value>,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PipelineRestart {
    pub force: Option<bool>,
    pub ignore_state: Option<bool>,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct Pipeline {
    pub id: String,
    pub name: String,
    pub query: String,
    pub udfs: Vec<Udf>,
    pub checkpoint_interval_micros: u64,
    pub stop: StopType,
    pub created_at: u64,
    pub action: Option<StopType>,
    pub action_text: String,
    pub action_in_progress: bool,
    pub graph: PipelineGraph,
    pub preview: bool,
    /// Optional URL pointing to the state the pipeline was started from.
    pub state_url: Option<String>,
    /// User-defined key/value tags associated with the pipeline.
    pub tags: HashMap<String, String>,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PipelineGraph {
    pub nodes: Vec<PipelineNode>,
    pub edges: Vec<PipelineEdge>,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PipelineNode {
    pub node_id: u32,
    pub operator: String,
    pub description: String,
    pub parallelism: u32,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct PipelineEdge {
    pub src_id: u32,
    pub dest_id: u32,
    pub key_type: String,
    pub value_type: String,
    pub edge_type: String,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum StopType {
    None,
    Checkpoint,
    Graceful,
    Immediate,
    Force,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct FailureReason {
    pub error: String,
    pub domain: ErrorDomain,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct Job {
    pub id: String,
    /// The `pub_id` of the pipeline this job belongs to.
    pub pipeline_id: String,
    pub running_desired: bool,
    pub state: String,
    pub run_id: u64,
    pub start_time: Option<u64>,
    pub finish_time: Option<u64>,
    pub tasks: Option<u64>,
    pub failure_reason: Option<FailureReason>,
    pub created_at: u64,
    /// Per-job scheduler configuration overlay (see `PipelinePost`).
    /// An empty object means "no overrides, use the controller's
    /// global scheduler config unchanged".
    pub scheduler_config: serde_json::Value,
    /// Per-job environment variables forwarded to workers.
    pub env_vars: serde_json::Value,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum JobLogLevel {
    Info,
    Warn,
    Error,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct JobLogMessage {
    pub id: String,
    pub created_at: u64,
    pub operator_id: Option<String>,
    pub task_index: Option<u64>,
    pub level: JobLogLevel,
    pub message: String,
    pub details: String,
    pub error_domain: Option<ErrorDomain>,
}

#[derive(Serialize, Deserialize, Clone, Debug, ToSchema)]
#[serde(rename_all = "snake_case")]
pub struct OutputData {
    pub operator_id: String,
    pub subtask_idx: u32,
    pub timestamps: Vec<u64>,
    pub start_id: u64,
    pub batch: String,
}

impl From<grpc_proto::rpc::OutputData> for OutputData {
    fn from(value: grpc_proto::rpc::OutputData) -> Self {
        OutputData {
            operator_id: value.operator_id,
            subtask_idx: value.subtask_idx,
            timestamps: value.timestamps,
            start_id: value.start_id,
            batch: value.batch,
        }
    }
}
