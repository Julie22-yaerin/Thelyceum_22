//! Pure types and decision logic for Arroyo's object-store checkpoint protocol.
//!
//! Object-store I/O is kept at the edge: storage code reads protocol objects,
//! passes the observed facts into pure decision functions, and then executes the
//! returned decision.

pub mod gc;
pub mod resolve;
pub mod state;
pub mod store;
pub mod types;
pub mod workflow;

use crate::types::{CheckpointRef, Epoch, Generation};
use arroyo_types::{JobId, PipelineId};

/// Builds canonical object-store paths for one pipeline/job checkpoint namespace.
///
/// All paths are relative to the configured checkpoint storage URI. Callers
/// should use this rather than formatting protocol paths by hand so that all
/// readers and writers agree on object names.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProtocolPaths {
    pipeline_id: PipelineId,
    job_id: JobId,
}

impl ProtocolPaths {
    /// Creates path helpers for a pipeline/job pair.
    pub fn new(pipeline_id: PipelineId, job_id: JobId) -> Self {
        Self {
            pipeline_id,
            job_id,
        }
    }

    /// Returns the pipeline id this path builder is scoped to.
    pub fn pipeline_id(&self) -> &PipelineId {
        &self.pipeline_id
    }

    /// Returns the job id this path builder is scoped to.
    pub fn job_id(&self) -> &JobId {
        &self.job_id
    }

    /// Path to the controller-written current generation fence.
    pub fn current_generation(&self) -> CheckpointRef {
        self.path("current-generation.json")
    }

    /// Path to a generation manifest.
    pub fn generation_manifest(&self, generation: Generation) -> CheckpointRef {
        self.path(format!("generations/{generation}/generation-manifest.json"))
    }

    /// Prefix containing all artifacts for one checkpoint.
    pub fn checkpoint_dir(&self, generation: Generation, epoch: Epoch) -> CheckpointRef {
        self.path(format!(
            "generations/{generation}/checkpoints/checkpoint-{epoch:07}"
        ))
    }

    /// Path to the immutable protobuf checkpoint manifest.
    pub fn checkpoint_manifest(&self, generation: Generation, epoch: Epoch) -> CheckpointRef {
        self.path(format!(
            "generations/{generation}/checkpoints/checkpoint-{epoch:07}/checkpoint-manifest.pb"
        ))
    }

    /// Path to the commit-completion marker for a checkpoint.
    pub fn committed_marker(&self, generation: Generation, epoch: Epoch) -> CheckpointRef {
        self.path(format!(
            "generations/{generation}/checkpoints/checkpoint-{epoch:07}/committed.json"
        ))
    }

    /// Path to the canonical epoch record for an epoch.
    pub fn epoch_record(&self, epoch: Epoch) -> CheckpointRef {
        self.path(format!("epochs/epoch-{epoch:07}.record"))
    }

    fn path(&self, suffix: impl AsRef<str>) -> CheckpointRef {
        CheckpointRef::from_validated(format!(
            "{}/{}/{}",
            self.pipeline_id,
            self.job_id,
            suffix.as_ref()
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gc::cleanup_leader_checkpoints;
    use crate::resolve::{
        EpochClaimOutcome, ParentCheckpointStatus, ResolveDecision, ResolveFailure,
        resolve_candidate,
    };
    use crate::state::{CheckpointState, derive_checkpoint_state};
    use crate::store::tests::MemoryProtocolStore;
    use crate::store::{
        CreateResult, ProtocolStore, StoreError, create_json_if_not_exist, put_json, put_protobuf,
        read_json, read_protobuf,
    };
    use crate::types::{
        CommittedMarker, CurrentGeneration, EpochRecord, GenerationManifest, ProtocolError,
    };
    use crate::workflow::{
        CheckpointPublication, ClaimEpochRecordRequest, CommitAuthorization, CommitPermit,
        CommittedMarkerOutcome, GenerationInitialization, GenerationRecovery, GenerationResolution,
        InitializeGenerationRequest, PublishCheckpointRequest, claim_epoch_record, complete_commit,
        initialize_generation, mark_committed, prepare_commit, publish_checkpoint,
        resolve_generation_manifest,
    };
    use arroyo_rpc::grpc::rpc::{
        CheckpointManifest, ExpiringKeyedTimeTableCheckpointMetadata,
        GlobalKeyedTableTaskCheckpointMetadata, OperatorCheckpointMetadata, OperatorMetadata,
        ParquetTimeFile, TableCheckpointMetadata, TableEnum,
    };
    use arroyo_types::{JobId, PipelineId, from_micros};
    use prost::Message;
    use std::time::SystemTime;

    fn checkpoint_ref(path: &str) -> CheckpointRef {
        CheckpointRef::new(path).unwrap()
    }

    fn checkpoint(
        epoch: u64,
        parent_checkpoint_ref: Option<CheckpointRef>,
        needs_commit: bool,
    ) -> CheckpointManifest {
        checkpoint_for_generation(Generation(1), epoch, parent_checkpoint_ref, needs_commit)
    }

    fn checkpoint_for_generation(
        generation: Generation,
        epoch: u64,
        parent_checkpoint_ref: Option<CheckpointRef>,
        needs_commit: bool,
    ) -> CheckpointManifest {
        CheckpointManifest {
            pipeline_id: "P".to_string(),
            job_id: "J".to_string(),
            generation: generation.0,
            epoch,
            min_epoch: epoch,
            start_time: 0,
            finish_time: 0,
            needs_commit,
            operators: vec![],
            parent_checkpoint_ref: parent_checkpoint_ref
                .map(|checkpoint_ref| checkpoint_ref.to_string()),
        }
    }

    fn epoch_record(checkpoint_ref: CheckpointRef, checkpoint: &CheckpointManifest) -> EpochRecord {
        EpochRecord::for_checkpoint(
            PipelineId::new("P"),
            Generation(checkpoint.generation),
            checkpoint_ref,
            checkpoint,
            SystemTime::UNIX_EPOCH,
        )
        .unwrap()
    }

    fn commit_permit(
        checkpoint_ref: CheckpointRef,
        checkpoint: &CheckpointManifest,
    ) -> CommitPermit {
        CommitPermit::new(
            checkpoint_ref.clone(),
            checkpoint,
            epoch_record(checkpoint_ref, checkpoint),
        )
        .unwrap()
    }

    fn committed_marker(checkpoint_ref: CheckpointRef, epoch: u64) -> CommittedMarker {
        CommittedMarker::new(
            PipelineId::new("P"),
            JobId::new("J"),
            Epoch(epoch),
            Generation(1),
            Generation(2),
            checkpoint_ref,
        )
    }

    fn generation_manifest(
        base_checkpoint_ref: Option<CheckpointRef>,
        latest_checkpoint_ref: Option<CheckpointRef>,
    ) -> GenerationManifest {
        generation_manifest_for_generation(
            Generation(1),
            base_checkpoint_ref,
            latest_checkpoint_ref,
        )
    }

    fn generation_manifest_for_generation(
        generation: Generation,
        base_checkpoint_ref: Option<CheckpointRef>,
        latest_checkpoint_ref: Option<CheckpointRef>,
    ) -> GenerationManifest {
        let mut manifest = GenerationManifest::new(
            PipelineId::new("P"),
            JobId::new("J"),
            generation,
            base_checkpoint_ref,
            0,
        );
        manifest.latest_checkpoint_ref = latest_checkpoint_ref;
        manifest
    }

    async fn write_current_generation(
        store: &MemoryProtocolStore,
        paths: &ProtocolPaths,
        generation: Generation,
    ) {
        let current_generation = CurrentGeneration::new(
            PipelineId::new("P"),
            JobId::new("J"),
            generation,
            from_micros(0),
        );

        put_json(store, &paths.current_generation(), &current_generation)
            .await
            .unwrap();
    }

    async fn write_canonical_checkpoint(
        store: &MemoryProtocolStore,
        paths: &ProtocolPaths,
        checkpoint_ref: &CheckpointRef,
        checkpoint: &CheckpointManifest,
    ) {
        put_protobuf(store, checkpoint_ref, checkpoint)
            .await
            .unwrap();
        put_json(
            store,
            &paths.epoch_record(Epoch(checkpoint.epoch)),
            &epoch_record(checkpoint_ref.clone(), checkpoint),
        )
        .await
        .unwrap();
    }

    fn data_ref(paths: &ProtocolPaths, epoch: u64) -> CheckpointRef {
        checkpoint_ref(&format!(
            "{}/operator-op/table-table-000",
            paths.checkpoint_dir(Generation(1), Epoch(epoch))
        ))
    }

    fn global_operator(files: Vec<CheckpointRef>) -> OperatorCheckpointMetadata {
        OperatorCheckpointMetadata {
            operator_metadata: Some(OperatorMetadata {
                job_id: "J".to_string(),
                operator_id: "op".to_string(),
                epoch: 0,
                min_watermark: None,
                max_watermark: None,
                parallelism: 1,
            }),
            start_time: 0,
            finish_time: 0,
            table_checkpoint_metadata: [(
                "table".to_string(),
                TableCheckpointMetadata {
                    table_type: TableEnum::GlobalKeyValue.into(),
                    data: GlobalKeyedTableTaskCheckpointMetadata {
                        files: files.into_iter().map(|file| file.to_string()).collect(),
                        commit_data_by_subtask: Default::default(),
                    }
                    .encode_to_vec(),
                },
            )]
            .into(),
            table_configs: Default::default(),
        }
    }

    fn expiring_operator(
        operator_id: &str,
        files: Vec<CheckpointRef>,
    ) -> OperatorCheckpointMetadata {
        OperatorCheckpointMetadata {
            operator_metadata: Some(OperatorMetadata {
                job_id: "J".to_string(),
                operator_id: operator_id.to_string(),
                epoch: 0,
                min_watermark: None,
                max_watermark: None,
                parallelism: 1,
            }),
            start_time: 0,
            finish_time: 0,
            table_checkpoint_metadata: [(
                "expiring-table".to_string(),
                TableCheckpointMetadata {
                    table_type: TableEnum::ExpiringKeyedTimeTable.into(),
                    data: ExpiringKeyedTimeTableCheckpointMetadata {
                        files: files
                            .into_iter()
                            .map(|file| ParquetTimeFile {
                                file: file.to_string(),
                                ..Default::default()
                            })
                            .collect(),
                    }
                    .encode_to_vec(),
                },
            )]
            .into(),
            table_configs: Default::default(),
        }
    }

    async fn write_gc_checkpoint(
        store: &MemoryProtocolStore,
        paths: &ProtocolPaths,
        epoch: u64,
        parent_epoch: Option<u64>,
        operators: Vec<OperatorCheckpointMetadata>,
    ) {
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(epoch));
        let parent_checkpoint_ref =
            parent_epoch.map(|epoch| paths.checkpoint_manifest(Generation(1), Epoch(epoch)));
        let mut checkpoint =
            checkpoint_for_generation(Generation(1), epoch, parent_checkpoint_ref, false);
        checkpoint.operators = operators;
        write_canonical_checkpoint(store, paths, &checkpoint_ref, &checkpoint).await;
        put_json(
            store,
            &paths.committed_marker(Generation(1), Epoch(epoch)),
            &committed_marker(checkpoint_ref, epoch),
        )
        .await
        .unwrap();
    }

    async fn exists(store: &MemoryProtocolStore, path: &CheckpointRef) -> bool {
        store.read_bytes(path).await.unwrap().is_some()
    }

    #[tokio::test]
    async fn cleanup_deletes_only_checkpoints_below_new_min_epoch() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let file1 = data_ref(&paths, 1);
        let file2 = data_ref(&paths, 2);
        let file3 = data_ref(&paths, 3);
        let checkpoint1_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint2_ref = paths.checkpoint_manifest(Generation(1), Epoch(2));
        let checkpoint3_ref = paths.checkpoint_manifest(Generation(1), Epoch(3));

        store.put_bytes(&file1, b"1".to_vec()).await.unwrap();
        store.put_bytes(&file2, b"2".to_vec()).await.unwrap();
        store.put_bytes(&file3, b"3".to_vec()).await.unwrap();
        write_gc_checkpoint(
            &store,
            &paths,
            1,
            None,
            vec![global_operator(vec![file1.clone()])],
        )
        .await;
        write_gc_checkpoint(
            &store,
            &paths,
            2,
            Some(1),
            vec![global_operator(vec![file2.clone()])],
        )
        .await;
        write_gc_checkpoint(
            &store,
            &paths,
            3,
            Some(2),
            vec![global_operator(vec![file3.clone()])],
        )
        .await;

        cleanup_leader_checkpoints(&store, &paths, checkpoint3_ref.clone(), Epoch(2))
            .await
            .unwrap();

        assert!(!exists(&store, &file1).await);
        assert!(!exists(&store, &paths.epoch_record(Epoch(1))).await);
        assert!(!exists(&store, &paths.committed_marker(Generation(1), Epoch(1))).await);
        assert!(
            read_protobuf::<_, CheckpointManifest>(&store, &checkpoint1_ref)
                .await
                .unwrap()
                .is_none()
        );

        assert!(exists(&store, &file2).await);
        assert!(exists(&store, &file3).await);
        assert!(
            read_protobuf::<_, CheckpointManifest>(&store, &checkpoint2_ref)
                .await
                .unwrap()
                .is_some()
        );
        assert!(
            read_protobuf::<_, CheckpointManifest>(&store, &checkpoint3_ref)
                .await
                .unwrap()
                .is_some()
        );
    }

    #[tokio::test]
    async fn cleanup_preserves_expiring_files_referenced_by_retained_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let shared_file = checkpoint_ref(&format!(
            "{}/operator-expiring-op/table-expiring-shared",
            paths.checkpoint_dir(Generation(1), Epoch(1))
        ));
        let expired_file = checkpoint_ref(&format!(
            "{}/operator-expiring-op/table-expiring-expired",
            paths.checkpoint_dir(Generation(1), Epoch(1))
        ));
        let checkpoint2_ref = paths.checkpoint_manifest(Generation(1), Epoch(2));

        store
            .put_bytes(&shared_file, b"shared".to_vec())
            .await
            .unwrap();
        store
            .put_bytes(&expired_file, b"expired".to_vec())
            .await
            .unwrap();
        write_gc_checkpoint(
            &store,
            &paths,
            1,
            None,
            vec![expiring_operator(
                "expiring-op",
                vec![shared_file.clone(), expired_file.clone()],
            )],
        )
        .await;
        write_gc_checkpoint(
            &store,
            &paths,
            2,
            Some(1),
            vec![expiring_operator("expiring-op", vec![shared_file.clone()])],
        )
        .await;

        cleanup_leader_checkpoints(&store, &paths, checkpoint2_ref.clone(), Epoch(2))
            .await
            .unwrap();

        assert!(exists(&store, &shared_file).await);
        assert!(!exists(&store, &expired_file).await);

        let deleted_count = store.deleted_objects().len();
        cleanup_leader_checkpoints(&store, &paths, checkpoint2_ref, Epoch(2))
            .await
            .unwrap();
        assert_eq!(deleted_count, store.deleted_objects().len());
        assert!(exists(&store, &shared_file).await);
    }

    #[tokio::test]
    async fn cleanup_retries_checkpoint_directory_when_carried_file_expires() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint1_dir = paths.checkpoint_dir(Generation(1), Epoch(1));
        let carried_file = checkpoint_ref(&format!(
            "{checkpoint1_dir}/operator-expiring-op/table-expiring-carried"
        ));

        store
            .put_bytes(&carried_file, b"carried".to_vec())
            .await
            .unwrap();
        write_gc_checkpoint(
            &store,
            &paths,
            1,
            None,
            vec![expiring_operator("expiring-op", vec![carried_file.clone()])],
        )
        .await;
        write_gc_checkpoint(
            &store,
            &paths,
            2,
            Some(1),
            vec![expiring_operator("expiring-op", vec![carried_file.clone()])],
        )
        .await;

        cleanup_leader_checkpoints(
            &store,
            &paths,
            paths.checkpoint_manifest(Generation(1), Epoch(2)),
            Epoch(2),
        )
        .await
        .unwrap();

        assert!(exists(&store, &carried_file).await);
        assert_eq!(
            1,
            store
                .deleted_directories()
                .iter()
                .filter(|directory| *directory == checkpoint1_dir.as_str())
                .count()
        );

        write_gc_checkpoint(
            &store,
            &paths,
            3,
            Some(2),
            vec![expiring_operator("expiring-op", vec![])],
        )
        .await;
        cleanup_leader_checkpoints(
            &store,
            &paths,
            paths.checkpoint_manifest(Generation(1), Epoch(3)),
            Epoch(3),
        )
        .await
        .unwrap();

        assert!(!exists(&store, &carried_file).await);
        assert_eq!(
            2,
            store
                .deleted_directories()
                .iter()
                .filter(|directory| *directory == checkpoint1_dir.as_str())
                .count(),
            "the old checkpoint directory should be retried when its carried file expires"
        );
    }

    #[tokio::test]
    async fn cleanup_classifies_mixed_global_and_expiring_metadata() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let global_old = checkpoint_ref(&format!(
            "{}/operator-op/table-global-old",
            paths.checkpoint_dir(Generation(1), Epoch(1))
        ));
        let global_retained = data_ref(&paths, 2);
        let expiring_old = checkpoint_ref(&format!(
            "{}/operator-expiring-op/table-expiring-old",
            paths.checkpoint_dir(Generation(1), Epoch(1))
        ));
        let expiring_shared = checkpoint_ref(&format!(
            "{}/operator-expiring-op/table-expiring-shared",
            paths.checkpoint_dir(Generation(1), Epoch(1))
        ));

        for file in [
            &global_old,
            &global_retained,
            &expiring_old,
            &expiring_shared,
        ] {
            store.put_bytes(file, b"data".to_vec()).await.unwrap();
        }
        write_gc_checkpoint(
            &store,
            &paths,
            1,
            None,
            vec![
                global_operator(vec![global_old.clone()]),
                expiring_operator(
                    "expiring-op",
                    vec![expiring_old.clone(), expiring_shared.clone()],
                ),
            ],
        )
        .await;
        write_gc_checkpoint(
            &store,
            &paths,
            2,
            Some(1),
            vec![
                global_operator(vec![global_retained.clone()]),
                expiring_operator("expiring-op", vec![expiring_shared.clone()]),
            ],
        )
        .await;

        cleanup_leader_checkpoints(
            &store,
            &paths,
            paths.checkpoint_manifest(Generation(1), Epoch(2)),
            Epoch(2),
        )
        .await
        .unwrap();

        assert!(!exists(&store, &global_old).await);
        assert!(!exists(&store, &expiring_old).await);
        assert!(exists(&store, &global_retained).await);
        assert!(exists(&store, &expiring_shared).await);
    }

    #[tokio::test]
    async fn cleanup_malformed_expiring_metadata_is_fail_closed() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let old_file = data_ref(&paths, 2);
        let mut malformed_operator = expiring_operator("expiring-op", vec![]);
        malformed_operator
            .table_checkpoint_metadata
            .get_mut("expiring-table")
            .unwrap()
            .data = vec![0x0a];

        store.put_bytes(&old_file, b"old".to_vec()).await.unwrap();
        write_gc_checkpoint(&store, &paths, 1, None, vec![malformed_operator]).await;
        write_gc_checkpoint(
            &store,
            &paths,
            2,
            Some(1),
            vec![global_operator(vec![old_file.clone()])],
        )
        .await;
        write_gc_checkpoint(&store, &paths, 3, Some(2), vec![global_operator(vec![])]).await;

        let err = cleanup_leader_checkpoints(
            &store,
            &paths,
            paths.checkpoint_manifest(Generation(1), Epoch(3)),
            Epoch(3),
        )
        .await
        .unwrap_err();

        assert!(matches!(err, StoreError::DecodeProtobuf { .. }));
        assert!(store.deleted_objects().is_empty());
        assert!(exists(&store, &old_file).await);
    }

    #[tokio::test]
    async fn cleanup_deletes_checkpoint_manifests_oldest_first() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_gc_checkpoint(&store, &paths, 1, None, vec![global_operator(vec![])]).await;
        write_gc_checkpoint(&store, &paths, 2, Some(1), vec![global_operator(vec![])]).await;
        write_gc_checkpoint(&store, &paths, 3, Some(2), vec![global_operator(vec![])]).await;

        cleanup_leader_checkpoints(
            &store,
            &paths,
            paths.checkpoint_manifest(Generation(1), Epoch(3)),
            Epoch(3),
        )
        .await
        .unwrap();

        let deleted = store.deleted_objects();
        let manifest1 = paths
            .checkpoint_manifest(Generation(1), Epoch(1))
            .to_string();
        let manifest2 = paths
            .checkpoint_manifest(Generation(1), Epoch(2))
            .to_string();
        let manifest3 = paths
            .checkpoint_manifest(Generation(1), Epoch(3))
            .to_string();
        let manifest1_pos = deleted
            .iter()
            .position(|path| path == &manifest1)
            .expect("epoch 1 manifest should be deleted");
        let manifest2_pos = deleted
            .iter()
            .position(|path| path == &manifest2)
            .expect("epoch 2 manifest should be deleted");

        assert!(manifest1_pos < manifest2_pos);
        assert!(!deleted.contains(&manifest3));
    }

    #[tokio::test]
    async fn cleanup_detects_checkpoint_parent_cycles() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_gc_checkpoint(&store, &paths, 1, Some(2), vec![global_operator(vec![])]).await;
        write_gc_checkpoint(&store, &paths, 2, Some(1), vec![global_operator(vec![])]).await;

        let err = cleanup_leader_checkpoints(
            &store,
            &paths,
            paths.checkpoint_manifest(Generation(1), Epoch(2)),
            Epoch(2),
        )
        .await
        .unwrap_err();

        assert!(matches!(
            err,
            StoreError::Protocol(ProtocolError::CheckpointCycle {
                generation: Generation(1),
                epoch: Epoch(2)
            })
        ));
        assert!(store.deleted_objects().is_empty());
    }

    #[tokio::test]
    async fn cleanup_rejects_min_epoch_newer_than_head() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let head = paths.checkpoint_manifest(Generation(1), Epoch(2));
        write_gc_checkpoint(&store, &paths, 2, None, vec![global_operator(vec![])]).await;

        let err = cleanup_leader_checkpoints(&store, &paths, head, Epoch(3))
            .await
            .unwrap_err();

        assert!(matches!(
            err,
            StoreError::Protocol(ProtocolError::CheckpointGcMinEpochBeyondHead {
                head_epoch: Epoch(2),
                new_min_epoch: Epoch(3),
            })
        ));
        assert!(store.deleted_objects().is_empty());
    }

    #[tokio::test]
    async fn initialize_generation_without_prior_checkpoint_writes_empty_manifest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(1),
                updated_at: from_micros(123),
            },
            false,
        )
        .await
        .unwrap();

        let expected_manifest = GenerationManifest::new(
            PipelineId::new("P"),
            JobId::new("J"),
            Generation(1),
            None,
            123,
        );
        assert_eq!(
            initialization,
            GenerationInitialization::Initialized {
                generation_manifest: expected_manifest.clone(),
                recovery: GenerationRecovery::NoCheckpoint
            }
        );

        let written_manifest: GenerationManifest =
            read_json(&store, &paths.generation_manifest(Generation(1)))
                .await
                .unwrap()
                .expect("new generation manifest should be written");
        assert_eq!(written_manifest, expected_manifest);
    }

    #[tokio::test]
    async fn initialize_generation_restores_previous_ready_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(2)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint_for_generation(Generation(1), 1, None, false);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;
        let previous_manifest =
            generation_manifest_for_generation(Generation(1), None, Some(checkpoint_ref.clone()));
        put_json(
            &store,
            &paths.generation_manifest(Generation(1)),
            &previous_manifest,
        )
        .await
        .unwrap();

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(2),
                updated_at: from_micros(456),
            },
            false,
        )
        .await
        .unwrap();

        let expected_manifest = GenerationManifest::new(
            PipelineId::new("P"),
            JobId::new("J"),
            Generation(2),
            Some(checkpoint_ref.clone()),
            456,
        );
        assert_eq!(
            initialization,
            GenerationInitialization::Initialized {
                generation_manifest: expected_manifest.clone(),
                recovery: GenerationRecovery::Ready {
                    checkpoint_ref: checkpoint_ref.clone()
                }
            }
        );

        let written_manifest: GenerationManifest =
            read_json(&store, &paths.generation_manifest(Generation(2)))
                .await
                .unwrap()
                .expect("new generation manifest should be written");
        assert_eq!(written_manifest, expected_manifest);
    }

    #[tokio::test]
    async fn initialize_generation_restores_previous_checkpoint_requiring_commit_replay() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(2)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint_for_generation(Generation(1), 1, None, true);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;
        let previous_manifest =
            generation_manifest_for_generation(Generation(1), None, Some(checkpoint_ref.clone()));
        put_json(
            &store,
            &paths.generation_manifest(Generation(1)),
            &previous_manifest,
        )
        .await
        .unwrap();

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(2),
                updated_at: from_micros(456),
            },
            false,
        )
        .await
        .unwrap();

        assert_eq!(
            initialization,
            GenerationInitialization::Initialized {
                generation_manifest: GenerationManifest::new(
                    PipelineId::new("P"),
                    JobId::new("J"),
                    Generation(2),
                    Some(checkpoint_ref.clone()),
                    456,
                ),
                recovery: GenerationRecovery::ReplayCommit {
                    checkpoint_ref: checkpoint_ref.clone(),
                    commit_permit: commit_permit(checkpoint_ref, &checkpoint),
                }
            }
        );
    }

    #[tokio::test]
    async fn initialize_generation_skips_missing_previous_manifest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(3)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint_for_generation(Generation(1), 1, None, false);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;
        put_json(
            &store,
            &paths.generation_manifest(Generation(1)),
            &generation_manifest_for_generation(Generation(1), None, Some(checkpoint_ref.clone())),
        )
        .await
        .unwrap();

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(3),
                updated_at: from_micros(789),
            },
            false,
        )
        .await
        .unwrap();

        assert!(matches!(
            initialization,
            GenerationInitialization::Initialized {
                recovery: GenerationRecovery::Ready { .. },
                ..
            }
        ));
        let written_manifest: GenerationManifest =
            read_json(&store, &paths.generation_manifest(Generation(3)))
                .await
                .unwrap()
                .expect("new generation manifest should be written");
        assert_eq!(written_manifest.base_checkpoint_ref, Some(checkpoint_ref));
    }

    #[tokio::test]
    async fn initialize_generation_claims_unclaimed_previous_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(2)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint_for_generation(Generation(1), 1, None, false);
        put_protobuf(&store, &checkpoint_ref, &checkpoint)
            .await
            .unwrap();
        put_json(
            &store,
            &paths.generation_manifest(Generation(1)),
            &generation_manifest_for_generation(Generation(1), None, Some(checkpoint_ref.clone())),
        )
        .await
        .unwrap();

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(2),
                updated_at: from_micros(456),
            },
            false,
        )
        .await
        .unwrap();

        assert!(matches!(
            initialization,
            GenerationInitialization::Initialized {
                recovery: GenerationRecovery::Ready { .. },
                ..
            }
        ));
        let record: EpochRecord = read_json(&store, &paths.epoch_record(Epoch(1)))
            .await
            .unwrap()
            .expect("unclaimed checkpoint should be claimed during initialization");
        assert_eq!(record.checkpoint_ref, checkpoint_ref);
        assert_eq!(record.generation, Generation(1));
    }

    #[tokio::test]
    async fn initialize_generation_recovers_canonical_checkpoint_from_orphaned_previous_manifest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(3)).await;

        let winner_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let winner_checkpoint = checkpoint_for_generation(Generation(1), 1, None, false);
        let loser_checkpoint = checkpoint_for_generation(Generation(2), 1, None, false);
        put_protobuf(&store, &winner_ref, &winner_checkpoint)
            .await
            .unwrap();
        put_protobuf(&store, &loser_ref, &loser_checkpoint)
            .await
            .unwrap();
        let epoch_record = epoch_record(winner_ref.clone(), &winner_checkpoint);
        put_json(&store, &paths.epoch_record(Epoch(1)), &epoch_record)
            .await
            .unwrap();
        put_json(
            &store,
            &paths.generation_manifest(Generation(2)),
            &generation_manifest_for_generation(Generation(2), None, Some(loser_ref)),
        )
        .await
        .unwrap();

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(3),
                updated_at: from_micros(456),
            },
            false,
        )
        .await
        .unwrap();

        assert_eq!(
            initialization,
            GenerationInitialization::Initialized {
                generation_manifest: GenerationManifest::new(
                    PipelineId::new("P"),
                    JobId::new("J"),
                    Generation(3),
                    Some(winner_ref.clone()),
                    456,
                ),
                recovery: GenerationRecovery::Ready {
                    checkpoint_ref: winner_ref.clone()
                }
            }
        );
        let written_manifest: GenerationManifest =
            read_json(&store, &paths.generation_manifest(Generation(3)))
                .await
                .unwrap()
                .expect("replacement generation manifest should be written");
        assert_eq!(written_manifest.base_checkpoint_ref, Some(winner_ref));
    }

    #[tokio::test]
    async fn initialize_generation_replays_commit_for_canonical_checkpoint_from_orphaned_manifest()
    {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(3)).await;

        let winner_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let winner_checkpoint = checkpoint_for_generation(Generation(1), 1, None, true);
        let loser_checkpoint = checkpoint_for_generation(Generation(2), 1, None, true);
        put_protobuf(&store, &winner_ref, &winner_checkpoint)
            .await
            .unwrap();
        put_protobuf(&store, &loser_ref, &loser_checkpoint)
            .await
            .unwrap();
        let epoch_record = epoch_record(winner_ref.clone(), &winner_checkpoint);
        put_json(&store, &paths.epoch_record(Epoch(1)), &epoch_record)
            .await
            .unwrap();
        put_json(
            &store,
            &paths.generation_manifest(Generation(2)),
            &generation_manifest_for_generation(Generation(2), None, Some(loser_ref)),
        )
        .await
        .unwrap();

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(3),
                updated_at: from_micros(456),
            },
            false,
        )
        .await
        .unwrap();

        assert_eq!(
            initialization,
            GenerationInitialization::Initialized {
                generation_manifest: GenerationManifest::new(
                    PipelineId::new("P"),
                    JobId::new("J"),
                    Generation(3),
                    Some(winner_ref.clone()),
                    456,
                ),
                recovery: GenerationRecovery::ReplayCommit {
                    checkpoint_ref: winner_ref.clone(),
                    commit_permit: commit_permit(winner_ref, &winner_checkpoint),
                }
            }
        );
    }

    #[tokio::test]
    async fn initialize_generation_exits_when_stale() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(3)).await;

        let initialization = initialize_generation(
            &store,
            InitializeGenerationRequest {
                pipeline_id: PipelineId::new("P"),
                job_id: JobId::new("J"),
                generation: Generation(2),
                updated_at: from_micros(456),
            },
            false,
        )
        .await
        .unwrap();

        assert_eq!(
            initialization,
            GenerationInitialization::StaleGeneration {
                current_generation: Generation(3)
            }
        );
        assert!(
            read_json::<_, GenerationManifest>(&store, &paths.generation_manifest(Generation(2)))
                .await
                .unwrap()
                .is_none()
        );
    }

    #[test]
    fn non_committing_checkpoint_is_unclaimed_until_epoch_record_exists() {
        let checkpoint_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let checkpoint = checkpoint(1, None, false);

        let state =
            derive_checkpoint_state(&checkpoint_ref, Some(&checkpoint), None, None).unwrap();

        assert_eq!(state, CheckpointState::Unclaimed);
        assert!(!state.is_ready());
    }

    #[test]
    fn epoch_record_makes_non_committing_checkpoint_ready() {
        let checkpoint_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let checkpoint = checkpoint(1, None, false);
        let record = epoch_record(checkpoint_ref.clone(), &checkpoint);

        let state = derive_checkpoint_state(
            &checkpoint_ref,
            Some(&checkpoint),
            Some(record.clone()),
            None,
        )
        .unwrap();

        assert_eq!(state, CheckpointState::Ready);
        assert!(state.is_canonical());
    }

    #[test]
    fn orphaning_applies_to_non_committing_checkpoints() {
        let loser_ref = checkpoint_ref(
            "P/J/generations/2/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let winner_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let checkpoint = checkpoint(1, None, false);
        let record = epoch_record(winner_ref.clone(), &checkpoint);

        let state =
            derive_checkpoint_state(&loser_ref, Some(&checkpoint), Some(record), None).unwrap();

        assert_eq!(
            state,
            CheckpointState::Orphaned {
                canonical_ref: winner_ref
            }
        );
    }

    #[test]
    fn committing_checkpoint_requires_committed_marker_to_be_ready() {
        let checkpoint_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let checkpoint = checkpoint(1, None, true);
        let record = epoch_record(checkpoint_ref.clone(), &checkpoint);

        let state = derive_checkpoint_state(
            &checkpoint_ref,
            Some(&checkpoint),
            Some(record.clone()),
            None,
        )
        .unwrap();
        assert_eq!(
            state,
            CheckpointState::Committing {
                epoch_record: record.clone()
            }
        );
        assert!(state.requires_commit_replay());

        let marker = committed_marker(checkpoint_ref.clone(), 1);
        let state = derive_checkpoint_state(
            &checkpoint_ref,
            Some(&checkpoint),
            Some(record),
            Some(&marker),
        )
        .unwrap();
        assert_eq!(state, CheckpointState::Ready);
    }

    #[test]
    fn resolve_current_generation_claims_unclaimed_candidate() {
        let checkpoint_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let manifest = generation_manifest(None, Some(checkpoint_ref.clone()));
        let checkpoint = checkpoint(1, None, false);

        let decision = resolve_candidate(
            &manifest,
            &checkpoint_ref,
            Some(&checkpoint),
            None,
            None,
            ParentCheckpointStatus::NoParent,
            true,
        )
        .unwrap();

        assert_eq!(decision, ResolveDecision::ClaimUnclaimed { checkpoint_ref });
    }

    #[test]
    fn resolve_stale_generation_falls_back_from_unclaimed_latest() {
        let base_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let latest_ref = checkpoint_ref(
            "P/J/generations/2/checkpoints/checkpoint-0000002/checkpoint-manifest.pb",
        );
        let manifest = generation_manifest(Some(base_ref), Some(latest_ref.clone()));
        let checkpoint = checkpoint(2, None, false);

        let decision = resolve_candidate(
            &manifest,
            &latest_ref,
            Some(&checkpoint),
            None,
            None,
            ParentCheckpointStatus::NoParent,
            false,
        )
        .unwrap();

        assert_eq!(decision, ResolveDecision::FallbackToBase);
    }

    #[test]
    fn resolve_orphaned_candidate_stops_generation() {
        let loser_ref = checkpoint_ref(
            "P/J/generations/2/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let winner_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let manifest = generation_manifest(None, Some(loser_ref.clone()));
        let checkpoint = checkpoint(1, None, false);
        let record = epoch_record(winner_ref.clone(), &checkpoint);

        let decision = resolve_candidate(
            &manifest,
            &loser_ref,
            Some(&checkpoint),
            Some(record),
            None,
            ParentCheckpointStatus::NoParent,
            true,
        )
        .unwrap();

        assert_eq!(
            decision,
            ResolveDecision::StopOrphaned {
                canonical_ref: winner_ref
            }
        );
    }

    #[test]
    fn resolve_canonical_uncommitted_checkpoint_requires_replay() {
        let checkpoint_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let manifest = generation_manifest(None, Some(checkpoint_ref.clone()));
        let checkpoint = checkpoint(1, None, true);
        let record = epoch_record(checkpoint_ref.clone(), &checkpoint);

        let decision = resolve_candidate(
            &manifest,
            &checkpoint_ref,
            Some(&checkpoint),
            Some(record.clone()),
            None,
            ParentCheckpointStatus::NoParent,
            true,
        )
        .unwrap();

        assert_eq!(
            decision,
            ResolveDecision::ReplayCommit {
                checkpoint_ref,
                epoch_record: record,
            }
        );
    }

    #[test]
    fn resolve_rejects_child_when_parent_is_not_ready_canonical() {
        let parent_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000001/checkpoint-manifest.pb",
        );
        let child_ref = checkpoint_ref(
            "P/J/generations/1/checkpoints/checkpoint-0000002/checkpoint-manifest.pb",
        );
        let manifest = generation_manifest(None, Some(child_ref.clone()));
        let child = checkpoint(2, Some(parent_ref), false);

        let decision = resolve_candidate(
            &manifest,
            &child_ref,
            Some(&child),
            None,
            None,
            ParentCheckpointStatus::NotReadyCanonical,
            true,
        )
        .unwrap();

        assert_eq!(
            decision,
            ResolveDecision::Failed(ResolveFailure::ParentNotReadyCanonical)
        );
    }

    #[tokio::test]
    async fn claim_epoch_record_creates_canonical_record() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let epoch_record_path = paths.epoch_record(Epoch(1));

        let outcome = claim_epoch_record(
            &store,
            ClaimEpochRecordRequest {
                epoch_record_path: &epoch_record_path,
                pipeline_id: &PipelineId::new("P"),
                generation: Generation(1),
                checkpoint_ref: &checkpoint_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(123),
            },
        )
        .await
        .unwrap();

        assert!(matches!(outcome, EpochClaimOutcome::Owned { .. }));

        let record: EpochRecord = read_json(&store, &epoch_record_path)
            .await
            .unwrap()
            .expect("epoch record should have been written");
        assert_eq!(record.checkpoint_ref, checkpoint_ref);
        assert_eq!(record.epoch, Epoch(1));
    }

    #[tokio::test]
    async fn claim_epoch_record_treats_existing_same_record_as_owned() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let epoch_record_path = paths.epoch_record(Epoch(1));
        let request = ClaimEpochRecordRequest {
            epoch_record_path: &epoch_record_path,
            pipeline_id: &PipelineId::new("P"),
            generation: Generation(1),
            checkpoint_ref: &checkpoint_ref,
            checkpoint: &checkpoint,
            created_at: from_micros(123),
        };

        claim_epoch_record(&store, request.clone()).await.unwrap();
        let outcome = claim_epoch_record(&store, request).await.unwrap();

        assert!(matches!(outcome, EpochClaimOutcome::Owned { .. }));
    }

    #[tokio::test]
    async fn claim_epoch_record_orphans_different_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let winner_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let epoch_record_path = paths.epoch_record(Epoch(1));

        claim_epoch_record(
            &store,
            ClaimEpochRecordRequest {
                epoch_record_path: &epoch_record_path,
                pipeline_id: &PipelineId::new("P"),
                generation: Generation(1),
                checkpoint_ref: &winner_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(123),
            },
        )
        .await
        .unwrap();

        let outcome = claim_epoch_record(
            &store,
            ClaimEpochRecordRequest {
                epoch_record_path: &epoch_record_path,
                pipeline_id: &PipelineId::new("P"),
                generation: Generation(2),
                checkpoint_ref: &loser_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(124),
            },
        )
        .await
        .unwrap();

        assert_eq!(
            outcome,
            EpochClaimOutcome::Orphaned {
                canonical_ref: winner_ref
            }
        );
    }

    #[tokio::test]
    async fn mark_committed_is_idempotent_for_same_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let committed_marker_path = paths.committed_marker(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let permit = commit_permit(checkpoint_ref.clone(), &checkpoint);
        let marker = committed_marker(checkpoint_ref, 1);

        let outcome = mark_committed(&store, &committed_marker_path, &marker, &permit)
            .await
            .unwrap();
        assert_eq!(outcome, CommittedMarkerOutcome::Created);

        let outcome = mark_committed(&store, &committed_marker_path, &marker, &permit)
            .await
            .unwrap();
        assert_eq!(outcome, CommittedMarkerOutcome::AlreadyCommitted);
    }

    #[tokio::test]
    async fn mark_committed_rejects_existing_marker_for_different_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let winner_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let committed_marker_path = paths.committed_marker(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let permit = commit_permit(winner_ref.clone(), &checkpoint);
        let winner_marker = committed_marker(winner_ref, 1);
        let loser_marker = committed_marker(loser_ref, 1);

        mark_committed(&store, &committed_marker_path, &winner_marker, &permit)
            .await
            .unwrap();

        let err = mark_committed(&store, &committed_marker_path, &loser_marker, &permit)
            .await
            .unwrap_err();

        assert!(matches!(
            err,
            StoreError::Protocol(ProtocolError::CommittedMarkerMismatch)
        ));
    }

    #[tokio::test]
    async fn prepare_commit_authorizes_canonical_uncommitted_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let epoch_record = epoch_record(checkpoint_ref.clone(), &checkpoint);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;

        let authorization =
            prepare_commit(&store, &checkpoint_ref, checkpoint.clone(), None, false)
                .await
                .unwrap();

        assert_eq!(
            authorization,
            CommitAuthorization::Authorized {
                checkpoint_ref: checkpoint_ref.clone(),
                checkpoint: checkpoint.clone(),
                commit_permit: CommitPermit::new(checkpoint_ref, &checkpoint, epoch_record)
                    .unwrap(),
            }
        );
    }

    #[tokio::test]
    async fn prepare_commit_reports_already_committed() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;
        put_json(
            &store,
            &paths.committed_marker(Generation(1), Epoch(1)),
            &committed_marker(checkpoint_ref.clone(), 1),
        )
        .await
        .unwrap();

        let authorization = prepare_commit(&store, &checkpoint_ref, checkpoint, None, false)
            .await
            .unwrap();

        assert_eq!(
            authorization,
            CommitAuthorization::AlreadyCommitted { checkpoint_ref }
        );
    }

    #[tokio::test]
    async fn prepare_commit_rejects_unclaimed_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        put_protobuf(&store, &checkpoint_ref, &checkpoint)
            .await
            .unwrap();

        let authorization = prepare_commit(&store, &checkpoint_ref, checkpoint, None, false)
            .await
            .unwrap();

        assert_eq!(
            authorization,
            CommitAuthorization::NotCanonical { checkpoint_ref }
        );
    }

    #[tokio::test]
    async fn prepare_commit_stops_orphaned_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let winner_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        put_protobuf(&store, &loser_ref, &checkpoint).await.unwrap();
        put_json(
            &store,
            &paths.epoch_record(Epoch(1)),
            &epoch_record(winner_ref.clone(), &checkpoint),
        )
        .await
        .unwrap();

        let authorization = prepare_commit(&store, &loser_ref, checkpoint, None, false)
            .await
            .unwrap();

        assert_eq!(
            authorization,
            CommitAuthorization::StopOrphaned {
                canonical_ref: winner_ref
            }
        );
    }

    #[tokio::test]
    async fn prepare_commit_skips_non_committing_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;

        let authorization = prepare_commit(&store, &checkpoint_ref, checkpoint, None, false)
            .await
            .unwrap();

        assert_eq!(
            authorization,
            CommitAuthorization::NoCommitNeeded { checkpoint_ref }
        );
    }

    #[tokio::test]
    async fn complete_commit_writes_committed_marker() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let permit = commit_permit(checkpoint_ref.clone(), &checkpoint);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;

        let completion = complete_commit(&store, &permit, Generation(2))
            .await
            .unwrap();

        assert_eq!(completion, CommittedMarkerOutcome::Created);
        let marker: CommittedMarker =
            read_json(&store, &paths.committed_marker(Generation(1), Epoch(1)))
                .await
                .unwrap()
                .expect("committed marker should be written");
        assert_eq!(marker.checkpoint_ref, checkpoint_ref);
        assert_eq!(marker.writer_generation, Generation(2));
    }

    #[tokio::test]
    async fn complete_commit_is_idempotent() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let permit = commit_permit(checkpoint_ref.clone(), &checkpoint);
        write_canonical_checkpoint(&store, &paths, &checkpoint_ref, &checkpoint).await;

        complete_commit(&store, &permit, Generation(2))
            .await
            .unwrap();
        let completion = complete_commit(&store, &permit, Generation(3))
            .await
            .unwrap();

        assert_eq!(completion, CommittedMarkerOutcome::AlreadyCommitted);
    }

    #[tokio::test]
    async fn complete_commit_writes_marker_from_epoch_record() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let permit = commit_permit(checkpoint_ref.clone(), &checkpoint);
        put_protobuf(&store, &checkpoint_ref, &checkpoint)
            .await
            .unwrap();

        let completion = complete_commit(&store, &permit, Generation(2))
            .await
            .unwrap();

        assert_eq!(completion, CommittedMarkerOutcome::Created);
        let marker: CommittedMarker =
            read_json(&store, &paths.committed_marker(Generation(1), Epoch(1)))
                .await
                .unwrap()
                .expect("committed marker should be written");
        assert_eq!(marker.checkpoint_ref, checkpoint_ref);
    }

    #[tokio::test]
    async fn storage_provider_store_round_trips_conditional_json_create() {
        let temp_dir = std::env::temp_dir().join(format!(
            "arroyo-state-protocol-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let storage =
            arroyo_storage::StorageProvider::for_url(&format!("file://{}", temp_dir.display()))
                .await
                .unwrap();
        let store = storage;
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let record = epoch_record(checkpoint_ref, &checkpoint);
        let epoch_record_path = paths.epoch_record(Epoch(1));

        let created = create_json_if_not_exist(&store, &epoch_record_path, &record)
            .await
            .unwrap();
        assert_eq!(created, CreateResult::Created);

        let existing = create_json_if_not_exist(&store, &epoch_record_path, &record)
            .await
            .unwrap();
        assert_eq!(existing, CreateResult::AlreadyExists(record));

        let _ = tokio::fs::remove_dir_all(temp_dir).await;
    }

    #[tokio::test]
    async fn resolve_generation_manifest_claims_unclaimed_current_latest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        put_protobuf(&store, &checkpoint_ref, &checkpoint)
            .await
            .unwrap();

        let manifest = generation_manifest(None, Some(checkpoint_ref.clone()));

        let resolution = resolve_generation_manifest(&store, &manifest, Generation(1))
            .await
            .unwrap();

        assert_eq!(resolution, GenerationResolution::Ready { checkpoint_ref });
        assert!(
            read_json::<_, EpochRecord>(&store, &paths.epoch_record(Epoch(1)))
                .await
                .unwrap()
                .is_some()
        );
    }

    #[tokio::test]
    async fn resolve_generation_manifest_claims_unclaimed_commit_checkpoint() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        put_protobuf(&store, &checkpoint_ref, &checkpoint)
            .await
            .unwrap();

        let manifest = generation_manifest(None, Some(checkpoint_ref.clone()));

        let resolution = resolve_generation_manifest(&store, &manifest, Generation(1))
            .await
            .unwrap();

        match resolution {
            GenerationResolution::ReplayCommit {
                checkpoint_ref: recovered_ref,
                commit_permit,
            } => {
                assert_eq!(recovered_ref, checkpoint_ref);
                assert_eq!(commit_permit.checkpoint_ref(), &checkpoint_ref);
            }
            other => panic!("expected replay commit resolution, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn resolve_generation_manifest_falls_back_to_base_for_stale_unclaimed_latest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(3)).await;

        let base_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let base = checkpoint(1, None, false);
        put_protobuf(&store, &base_ref, &base).await.unwrap();
        put_json(
            &store,
            &paths.epoch_record(Epoch(1)),
            &epoch_record(base_ref.clone(), &base),
        )
        .await
        .unwrap();

        let latest_ref = paths.checkpoint_manifest(Generation(2), Epoch(2));
        let latest = checkpoint(2, Some(base_ref.clone()), false);
        put_protobuf(&store, &latest_ref, &latest).await.unwrap();

        let manifest = generation_manifest(Some(base_ref.clone()), Some(latest_ref));

        let resolution = resolve_generation_manifest(&store, &manifest, Generation(2))
            .await
            .unwrap();

        assert_eq!(
            resolution,
            GenerationResolution::Ready {
                checkpoint_ref: base_ref
            }
        );
    }

    #[tokio::test]
    async fn resolve_generation_manifest_stops_on_orphaned_latest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(2)).await;

        let winner_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        put_protobuf(&store, &loser_ref, &checkpoint).await.unwrap();
        put_json(
            &store,
            &paths.epoch_record(Epoch(1)),
            &epoch_record(winner_ref.clone(), &checkpoint),
        )
        .await
        .unwrap();

        let manifest = generation_manifest(None, Some(loser_ref));

        let resolution = resolve_generation_manifest(&store, &manifest, Generation(2))
            .await
            .unwrap();

        assert_eq!(
            resolution,
            GenerationResolution::StopOrphaned {
                canonical_ref: winner_ref
            }
        );
    }

    #[tokio::test]
    async fn resolve_generation_manifest_rejects_checkpoint_with_unready_parent() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let parent_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let child_ref = paths.checkpoint_manifest(Generation(1), Epoch(2));
        let child = checkpoint(2, Some(parent_ref), false);
        put_protobuf(&store, &child_ref, &child).await.unwrap();

        let manifest = generation_manifest(None, Some(child_ref));

        let resolution = resolve_generation_manifest(&store, &manifest, Generation(1))
            .await
            .unwrap();

        assert_eq!(
            resolution,
            GenerationResolution::Failed(ResolveFailure::ParentNotReadyCanonical)
        );
    }

    #[tokio::test]
    async fn publish_non_committing_checkpoint_writes_protocol_objects() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let manifest = generation_manifest(None, None);

        let publication = publish_checkpoint(
            &store,
            PublishCheckpointRequest {
                generation_manifest: &manifest,
                checkpoint_ref: &checkpoint_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(42),
            },
        )
        .await
        .unwrap();

        assert_eq!(
            publication,
            CheckpointPublication::Ready {
                checkpoint_ref: checkpoint_ref.clone()
            }
        );

        let written_checkpoint: CheckpointManifest = read_protobuf(&store, &checkpoint_ref)
            .await
            .unwrap()
            .expect("checkpoint manifest should be written");
        assert_eq!(written_checkpoint, checkpoint);

        let written_generation_manifest: GenerationManifest =
            read_json(&store, &paths.generation_manifest(Generation(1)))
                .await
                .unwrap()
                .expect("generation manifest should be updated");
        assert_eq!(
            written_generation_manifest.latest_checkpoint_ref,
            Some(checkpoint_ref.clone())
        );

        let record: EpochRecord = read_json(&store, &paths.epoch_record(Epoch(1)))
            .await
            .unwrap()
            .expect("epoch record should be written");
        assert_eq!(record.checkpoint_ref, checkpoint_ref);
    }

    #[tokio::test]
    async fn publish_committing_checkpoint_requires_commit() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, true);
        let manifest = generation_manifest(None, None);

        let publication = publish_checkpoint(
            &store,
            PublishCheckpointRequest {
                generation_manifest: &manifest,
                checkpoint_ref: &checkpoint_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(42),
            },
        )
        .await
        .unwrap();

        let expected_record = EpochRecord::for_checkpoint(
            PipelineId::new("P"),
            Generation(1),
            checkpoint_ref.clone(),
            &checkpoint,
            from_micros(42),
        )
        .unwrap();
        assert_eq!(
            publication,
            CheckpointPublication::CommitRequired {
                checkpoint_ref: checkpoint_ref.clone(),
                commit_permit: CommitPermit::new(checkpoint_ref, &checkpoint, expected_record)
                    .unwrap(),
            }
        );
    }

    #[tokio::test]
    async fn publish_checkpoint_exits_when_generation_is_stale() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(2)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let manifest = generation_manifest(None, None);

        let publication = publish_checkpoint(
            &store,
            PublishCheckpointRequest {
                generation_manifest: &manifest,
                checkpoint_ref: &checkpoint_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(42),
            },
        )
        .await
        .unwrap();

        assert_eq!(publication, CheckpointPublication::StaleGeneration);
        assert!(
            read_protobuf::<_, CheckpointManifest>(&store, &checkpoint_ref)
                .await
                .unwrap()
                .is_none()
        );
    }

    #[tokio::test]
    async fn publish_checkpoint_is_idempotent_for_existing_same_manifest() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let checkpoint_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        let manifest = generation_manifest(None, None);
        let request = PublishCheckpointRequest {
            generation_manifest: &manifest,
            checkpoint_ref: &checkpoint_ref,
            checkpoint: &checkpoint,
            created_at: from_micros(42),
        };

        publish_checkpoint(&store, request.clone()).await.unwrap();
        let publication = publish_checkpoint(&store, request).await.unwrap();

        assert_eq!(publication, CheckpointPublication::Ready { checkpoint_ref });
    }

    #[tokio::test]
    async fn publish_checkpoint_stops_when_epoch_record_points_elsewhere() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let winner_ref = paths.checkpoint_manifest(Generation(2), Epoch(1));
        let loser_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let checkpoint = checkpoint(1, None, false);
        put_json(
            &store,
            &paths.epoch_record(Epoch(1)),
            &epoch_record(winner_ref.clone(), &checkpoint),
        )
        .await
        .unwrap();

        let manifest = generation_manifest(None, None);
        let publication = publish_checkpoint(
            &store,
            PublishCheckpointRequest {
                generation_manifest: &manifest,
                checkpoint_ref: &loser_ref,
                checkpoint: &checkpoint,
                created_at: from_micros(42),
            },
        )
        .await
        .unwrap();

        assert_eq!(
            publication,
            CheckpointPublication::StopOrphaned {
                canonical_ref: winner_ref
            }
        );
    }

    #[tokio::test]
    async fn publish_checkpoint_rejects_unready_parent() {
        let store = MemoryProtocolStore::default();
        let paths = ProtocolPaths::new(PipelineId::new("P"), JobId::new("J"));
        write_current_generation(&store, &paths, Generation(1)).await;

        let parent_ref = paths.checkpoint_manifest(Generation(1), Epoch(1));
        let child_ref = paths.checkpoint_manifest(Generation(1), Epoch(2));
        let child = checkpoint(2, Some(parent_ref), false);
        let manifest = generation_manifest(None, None);

        let publication = publish_checkpoint(
            &store,
            PublishCheckpointRequest {
                generation_manifest: &manifest,
                checkpoint_ref: &child_ref,
                checkpoint: &child,
                created_at: from_micros(42),
            },
        )
        .await
        .unwrap();

        assert_eq!(
            publication,
            CheckpointPublication::Failed(ResolveFailure::ParentNotReadyCanonical)
        );
        assert!(
            read_json::<_, EpochRecord>(&store, &paths.epoch_record(Epoch(2)))
                .await
                .unwrap()
                .is_none()
        );
    }
}
