import './pipelines.css';

import { useParams } from 'react-router-dom';
import {
  Alert,
  AlertDescription,
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  AlertIcon,
  AlertTitle,
  Badge,
  Box,
  Button,
  ButtonGroup,
  Flex,
  Grid,
  Heading,
  Icon,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalHeader,
  ModalOverlay,
  Popover,
  PopoverArrow,
  PopoverBody,
  PopoverContent,
  PopoverTrigger,
  Spacer,
  Spinner,
  Stack,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  useDisclosure,
  Wrap,
  WrapItem,
} from '@chakra-ui/react';
import React, { useEffect, useRef, useState } from 'react';
import 'reactflow/dist/style.css';
import 'metrics-graphics/dist/mg.css';
import PipelineConfigModal from './PipelineConfigModal';
import {
  StopType,
  useJobCheckpoints,
  useJobMetrics,
  useOperatorErrors,
  usePipeline,
  usePipelineJobs,
  JobLogMessage,
} from '../../lib/data_fetching';
import OperatorDetail from '../../components/OperatorDetail';
import Checkpoints from '../../components/Checkpoints';
import Loading from '../../components/Loading';
import OperatorErrors from '../../components/OperatorErrors';
import { PipelineGraphViewer } from './PipelineGraph';
import PipelineNotFound from '../../components/PipelineNotFound';
import { QuestionOutlineIcon, WarningIcon } from '@chakra-ui/icons';
import { formatError } from '../../lib/util';
import { PipelineOutputs } from './PipelineOutputs';
import PaginatedContent from '../../components/PaginatedContent';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { vs2015 } from 'react-syntax-highlighter/dist/esm/styles/hljs';
import { useNavbar } from '../../App';

function flattenConfig(value: unknown, prefix = ''): [string, string][] {
  if (value === null || typeof value !== 'object') {
    return [[prefix, String(value)]];
  }
  if (Array.isArray(value)) {
    return [[prefix, JSON.stringify(value)]];
  }
  const entries = Object.entries(value as Record<string, unknown>);
  if (entries.length === 0) {
    return prefix ? [[prefix, '{}']] : [];
  }
  return entries.flatMap(([key, v]) => flattenConfig(v, prefix ? `${prefix}.${key}` : key));
}

export function PipelineDetails() {
  const [activeOperator, setActiveOperator] = useState<number | undefined>(undefined);
  const {
    isOpen: configModalOpen,
    onOpen: onConfigModalOpen,
    onClose: onConfigModalClose,
  } = useDisclosure();
  const {
    isOpen: restartWithoutStateModalIsOpen,
    onOpen: onRestartWithoutStateModalOpen,
    onClose: onRestartWithoutStateModalClose,
  } = useDisclosure();
  const {
    isOpen: schedulerConfigModalIsOpen,
    onOpen: onSchedulerConfigModalOpen,
    onClose: onSchedulerConfigModalClose,
  } = useDisclosure();
  const cancelRef = useRef<HTMLButtonElement>(null);

  let { pipelineId: id } = useParams();

  const { pipeline, pipelineError, updatePipeline, restartPipeline } = usePipeline(id, true);
  const { jobs, jobsError } = usePipelineJobs(id, true);
  const job = jobs?.length ? jobs[0] : undefined;
  const { checkpoints, checkpointsError } = useJobCheckpoints(id, job?.id);
  const { operatorErrorsPages, operatorErrorsTotalPages, setOperatorErrorsMaxPages } =
    useOperatorErrors(id, job?.id);
  const [operatorErrors, setOperatorErrors] = useState<JobLogMessage[]>([]);
  const { operatorMetricGroups } = useJobMetrics(id, job?.id);

  const hasErrors = operatorErrorsPages?.length && operatorErrorsPages[0]?.data.length > 0;

  const { setMenuItems } = useNavbar();

  useEffect(() => {
    setMenuItems([]);
  }, []);

  if (pipelineError || jobsError) {
    return (
      <PipelineNotFound
        icon={<QuestionOutlineIcon boxSize={55} />}
        message={formatError(pipelineError ?? jobsError)}
      />
    );
  }

  if (!pipeline || !job || !operatorErrorsPages) {
    return <Loading />;
  }

  async function updateJobState(stop: StopType) {
    console.log(`Setting pipeline stop_mode=${stop}`);
    await updatePipeline({ stop });
  }

  async function updateJobParallelism(parallelism: number) {
    console.log(`Setting pipeline parallelism=${parallelism}`);
    updatePipeline({ parallelism });
  }

  let operatorDetail = undefined;
  if (activeOperator != undefined) {
    operatorDetail = (
      <OperatorDetail pipelineId={pipeline.id} jobId={job.id} nodeId={activeOperator} />
    );
  }

  const operatorsTab = (
    <TabPanel display={'flex'} height={'100%'}>
      <Flex flex="1" height={'100%'}>
        <PipelineGraphViewer
          graph={pipeline.graph}
          operatorMetricGroups={operatorMetricGroups}
          setActiveOperator={setActiveOperator}
          activeOperator={activeOperator}
        />
      </Flex>
      <Stack w="500px" className="pipelineInfo" spacing={2} overflow={'auto'}>
        {job?.failure_reason?.error ? (
          <Box>
            <Alert status="error" marginBottom={5}>
              <Box>
                <AlertTitle>Job Failed</AlertTitle>
                <AlertDescription>{job?.failure_reason?.error}</AlertDescription>
              </Box>
              <Spacer />
              <AlertIcon alignSelf="flex-start" />
            </Alert>
          </Box>
        ) : null}

        <Box className="field">
          <Box className="fieldName">Pipeline ID</Box>
          <Box className="fieldValue">
            <Text>{pipeline.id}</Text>
          </Box>
        </Box>
        <Box className="field">
          <Box className="fieldName">Job ID</Box>
          <Box className="fieldValue">
            <Text>{job.id}</Text>
          </Box>
        </Box>
        <Box className="field">
          <Box className="fieldName">State</Box>
          <Box className="fieldValue">
            <Text>{job.state}</Text>
          </Box>
        </Box>
        {pipeline.state_url ? (
          <Box className="field">
            <Box className="fieldName">State URL</Box>
            <Box className="fieldValue">
              <Text wordBreak="break-all">{pipeline.state_url}</Text>
            </Box>
          </Box>
        ) : null}
        {Object.keys(pipeline.tags).length > 0 ? (
          <Box className="field">
            <Box className="fieldName">Tags</Box>
            <Box className="fieldValue">
              <Wrap spacing={1}>
                {Object.entries(pipeline.tags).map(([k, v]) => (
                  <WrapItem key={k}>
                    <Badge>
                      {k}: {v}
                    </Badge>
                  </WrapItem>
                ))}
              </Wrap>
            </Box>
          </Box>
        ) : null}
        {job.env_vars && Object.keys(job.env_vars as Record<string, string>).length > 0 ? (
          <Box className="field">
            <Box className="fieldName">Env Vars</Box>
            <Box className="fieldValue">
              <Wrap spacing={1}>
                {Object.entries(job.env_vars as Record<string, string>).map(([k, v]) => (
                  <WrapItem key={k}>
                    <Badge>
                      {k}: {v}
                    </Badge>
                  </WrapItem>
                ))}
              </Wrap>
            </Box>
          </Box>
        ) : null}
        {job.scheduler_config && Object.keys(job.scheduler_config as object).length > 0 ? (
          <Box className="field">
            <Box className="fieldName">Scheduler Config</Box>
            <Box className="fieldValue">
              <Button size="sm" onClick={onSchedulerConfigModalOpen}>
                View
              </Button>
            </Box>
          </Box>
        ) : null}
        {operatorDetail}
      </Stack>
    </TabPanel>
  );

  const outputsTab = (
    <TabPanel w={'100%'} h={'100%'}>
      {pipeline.graph.nodes.find(n => n.operator.includes('preview')) == null ? (
        <Text>Pipeline does not have a web sink</Text>
      ) : (
        <PipelineOutputs pipelineId={pipeline.id} job={job} onDemand={true} />
      )}
    </TabPanel>
  );

  const checkpointsTab = (
    <TabPanel>
      {
        <Checkpoints
          pipeline={pipeline}
          job={job}
          checkpoints={checkpoints ?? []}
          checkpointsError={checkpointsError}
        />
      }
    </TabPanel>
  );

  const queryTab = (
    <TabPanel flex={1} display={'flex'} flexDirection={'column'}>
      <SyntaxHighlighter
        language="sql"
        style={vs2015}
        customStyle={{ borderRadius: '5px', flex: '1' }}
      >
        {pipeline.query}
      </SyntaxHighlighter>
    </TabPanel>
  );

  const udfsTab = (
    <TabPanel flex={1} display={'flex'} flexDirection={'column'} gap={3}>
      {pipeline.udfs.map(udf => {
        return (
          <SyntaxHighlighter
            language="rust"
            style={vs2015}
            customStyle={{ borderRadius: '5px', flex: '1' }}
          >
            {udf.definition}
          </SyntaxHighlighter>
        );
      })}
    </TabPanel>
  );

  const errorsTab = (
    <TabPanel padding={5}>
      <PaginatedContent
        pages={operatorErrorsPages}
        totalPages={operatorErrorsTotalPages}
        setMaxPages={setOperatorErrorsMaxPages}
        content={<OperatorErrors operatorErrors={operatorErrors} />}
        setCurrentData={setOperatorErrors}
      />
    </TabPanel>
  );

  const inner = (
    <Tabs display={'Flex'} flexDirection={'column'} width={'100%'}>
      <TabList>
        <Tab>Operators</Tab>
        <Tab>Outputs</Tab>
        <Tab>Checkpoints</Tab>
        <Tab>Query</Tab>
        <Tab>UDFs</Tab>
        <Tab>Errors {hasErrors && <Icon as={WarningIcon} color={'red.400'} ml={2} />}</Tab>
      </TabList>
      <TabPanels display={'flex'} flexDirection={'column'} overflow={'auto'} flex={1}>
        {operatorsTab}
        {outputsTab}
        {checkpointsTab}
        {queryTab}
        {udfsTab}
        {errorsTab}
      </TabPanels>
    </Tabs>
  );

  let configModal = <></>;
  if (pipeline.graph.nodes) {
    const parallelism = Math.max(...pipeline.graph.nodes.map(({ parallelism }) => parallelism));

    configModal = (
      <PipelineConfigModal
        parallelism={parallelism}
        isOpen={configModalOpen}
        onClose={onConfigModalClose}
        updateJobParallelism={updateJobParallelism}
      />
    );
  }

  let editPipelineButton = <></>;
  let actionButton = <></>;
  if (pipeline) {
    editPipelineButton = <Button onClick={onConfigModalOpen}>Edit</Button>;
    const isStopped = job.state === 'Stopped' && pipeline.action != null;
    if (job.state === 'Failed' || isStopped) {
      const actionText = isStopped ? 'Start' : 'Restart';
      actionButton = (
        <Popover trigger="hover" placement="bottom-start">
          <PopoverTrigger>
            <Button
              onClick={async () => {
                if (isStopped) {
                  await updateJobState(pipeline.action!);
                } else {
                  await restartPipeline(false);
                }
              }}
            >
              {actionText}
            </Button>
          </PopoverTrigger>
          <PopoverContent width="auto">
            <PopoverArrow />
            <PopoverBody p={4}>
              <Button size="sm" colorScheme="red" onClick={onRestartWithoutStateModalOpen}>
                {actionText} Without State
              </Button>
            </PopoverBody>
          </PopoverContent>
        </Popover>
      );
    } else {
      actionButton = (
        <Button
          isDisabled={pipeline.action == null}
          onClick={async () => {
            await updateJobState(pipeline.action!);
          }}
        >
          {pipeline.action_in_progress ? <Spinner size="xs" mr={2} /> : null}
          {pipeline.action_text}
        </Button>
      );
    }
  }

  const startingWithoutState = job.state === 'Stopped';
  const withoutStateAction = startingWithoutState ? 'Start' : 'Restart';
  const withoutStateActionPresentParticiple = startingWithoutState ? 'Starting' : 'Restarting';

  const headerArea = (
    <Flex>
      <Box p={5}>
        <Heading as="h4" size="md">
          {pipeline?.name} <Badge>{job?.state}</Badge>
        </Heading>
      </Box>
      <Spacer />
      <Box p={5}>
        <ButtonGroup>
          {editPipelineButton}
          {actionButton}
        </ButtonGroup>
      </Box>
    </Flex>
  );

  return (
    <>
      <Grid templateRows={'min-content minmax(0, 1fr)'} height={'100vh'}>
        {headerArea}
        {inner}
      </Grid>
      {configModal}
      <AlertDialog
        isOpen={restartWithoutStateModalIsOpen}
        leastDestructiveRef={cancelRef}
        onClose={onRestartWithoutStateModalClose}
        isCentered
      >
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              {withoutStateAction} Without State
            </AlertDialogHeader>

            <AlertDialogBody>
              <Text>
                {withoutStateActionPresentParticiple} without state could lead to data loss,
                duplication, and incorrect results. Are you sure you want to continue?
              </Text>
            </AlertDialogBody>

            <AlertDialogFooter>
              <Button ref={cancelRef} onClick={onRestartWithoutStateModalClose}>
                Cancel
              </Button>
              <Button
                colorScheme="red"
                onClick={async () => {
                  await restartPipeline(true);
                  onRestartWithoutStateModalClose();
                }}
                ml={3}
              >
                {withoutStateAction} Without State
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
      <Modal
        isOpen={schedulerConfigModalIsOpen}
        onClose={onSchedulerConfigModalClose}
        isCentered
        size="xl"
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Scheduler Config</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <Stack spacing={1}>
              {flattenConfig(job.scheduler_config).map(([k, v]) => (
                <Text key={k} fontFamily="mono" fontSize="sm" wordBreak="break-all">
                  {k}: {v}
                </Text>
              ))}
            </Stack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
}
