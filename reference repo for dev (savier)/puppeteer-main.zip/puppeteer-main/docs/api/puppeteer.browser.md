---
sidebar_label: Browser
---

# Browser class

[Browser](./puppeteer.browser.md) represents a browser instance that is either:

- connected to via [Puppeteer.connect()](./puppeteer.puppeteer.connect.md) or - launched by [PuppeteerNode.launch()](./puppeteer.puppeteernode.launch.md).

[Browser](./puppeteer.browser.md) [emits](./puppeteer.eventemitter.emit.md) various events which are documented in the [BrowserEvent](./puppeteer.browserevent.md) enum.

### Signature

```typescript
export declare abstract class Browser extends EventEmitter<BrowserEvents>
```

**Extends:** [EventEmitter](./puppeteer.eventemitter.md)&lt;[BrowserEvents](./puppeteer.browserevents.md)&gt;

## Remarks

The constructor for this class is marked as internal. Third-party code should not call the constructor directly or create subclasses that extend the `Browser` class.

## Example 1

Using a [Browser](./puppeteer.browser.md) to create a [Page](./puppeteer.page.md):

```ts
import puppeteer from 'puppeteer';

const browser = await puppeteer.launch();
const page = await browser.newPage();
await page.goto('https://example.com');
await browser.close();
```

## Example 2

Disconnecting from and reconnecting to a [Browser](./puppeteer.browser.md):

```ts
import puppeteer from 'puppeteer';

const browser = await puppeteer.launch();
// Store the endpoint to be able to reconnect to the browser.
const browserWSEndpoint = browser.wsEndpoint();
// Disconnect puppeteer from the browser.
await browser.disconnect();

// Use the endpoint to reestablish a connection
const browser2 = await puppeteer.connect({browserWSEndpoint});
// Close the browser.
await browser2.close();
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

<span id="connected">connected</span>

</td><td>

`readonly`

</td><td>

boolean

</td><td>

Whether Puppeteer is connected to this [browser](./puppeteer.browser.md).

</td></tr>
<tr><td>

<span id="debuginfo">debugInfo</span>

</td><td>

`readonly`

</td><td>

[DebugInfo](./puppeteer.debuginfo.md)

</td><td>

**_(Experimental)_** Get debug information from Puppeteer.

**Remarks:**

Currently, includes pending protocol calls. In the future, we might add more info.

</td></tr>
</tbody></table>

## Methods

<table><thead><tr><th>

Method

</th><th>

Modifiers

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

<span id="_asyncdisposesymbol_">[\[asyncDisposeSymbol\]()](./puppeteer.browser._asyncdisposesymbol_.md)</span>

</td><td>

</td><td>

</td></tr>
<tr><td>

<span id="_disposesymbol_">[\[disposeSymbol\]()](./puppeteer.browser._disposesymbol_.md)</span>

</td><td>

</td><td>

</td></tr>
<tr><td>

<span id="addscreen">[addScreen(params)](./puppeteer.browser.addscreen.md)</span>

</td><td>

</td><td>

Adds a new screen, returns the added [screen information object](./puppeteer.screeninfo.md).

**Remarks:**

Only supported in headless mode.

</td></tr>
<tr><td>

<span id="browsercontexts">[browserContexts()](./puppeteer.browser.browsercontexts.md)</span>

</td><td>

</td><td>

Gets a list of open [browser contexts](./puppeteer.browsercontext.md).

In a newly-created [browser](./puppeteer.browser.md), this will return a single instance of [BrowserContext](./puppeteer.browsercontext.md).

</td></tr>
<tr><td>

<span id="close">[close()](./puppeteer.browser.close.md)</span>

</td><td>

</td><td>

Closes this [browser](./puppeteer.browser.md) and all associated [pages](./puppeteer.page.md).

</td></tr>
<tr><td>

<span id="cookies">[cookies()](./puppeteer.browser.cookies.md)</span>

</td><td>

</td><td>

Returns all cookies in the default [BrowserContext](./puppeteer.browsercontext.md).

**Remarks:**

Shortcut for [browser.defaultBrowserContext().cookies()](./puppeteer.browsercontext.cookies.md).

</td></tr>
<tr><td>

<span id="createbrowsercontext">[createBrowserContext(options)](./puppeteer.browser.createbrowsercontext.md)</span>

</td><td>

</td><td>

Creates a new [browser context](./puppeteer.browsercontext.md).

This won't share cookies/cache with other [browser contexts](./puppeteer.browsercontext.md).

</td></tr>
<tr><td>

<span id="defaultbrowsercontext">[defaultBrowserContext()](./puppeteer.browser.defaultbrowsercontext.md)</span>

</td><td>

</td><td>

Gets the default [browser context](./puppeteer.browsercontext.md).

**Remarks:**

The default [browser context](./puppeteer.browsercontext.md) cannot be closed.

</td></tr>
<tr><td>

<span id="deletecookie">[deleteCookie(cookies)](./puppeteer.browser.deletecookie.md)</span>

</td><td>

</td><td>

Removes cookies from the default [BrowserContext](./puppeteer.browsercontext.md).

**Remarks:**

Shortcut for [browser.defaultBrowserContext().deleteCookie()](./puppeteer.browsercontext.deletecookie.md).

</td></tr>
<tr><td>

<span id="deletematchingcookies">[deleteMatchingCookies(filters)](./puppeteer.browser.deletematchingcookies.md)</span>

</td><td>

</td><td>

Deletes cookies matching the provided filters from the default [BrowserContext](./puppeteer.browsercontext.md).

**Remarks:**

Shortcut for [browser.defaultBrowserContext().deleteMatchingCookies()](./puppeteer.browsercontext.deletematchingcookies.md).

</td></tr>
<tr><td>

<span id="disconnect">[disconnect()](./puppeteer.browser.disconnect.md)</span>

</td><td>

</td><td>

Disconnects Puppeteer from this [browser](./puppeteer.browser.md), but leaves the process running.

</td></tr>
<tr><td>

<span id="extensions">[extensions()](./puppeteer.browser.extensions.md)</span>

</td><td>

</td><td>

Retrieves a map of all extensions installed in the browser, where the keys are extension IDs and the values are the corresponding [Extension](./puppeteer.extension.md) instances.

</td></tr>
<tr><td>

<span id="getpwastate">[getPWAState(options)](./puppeteer.browser.getpwastate.md)</span>

</td><td>

</td><td>

Returns the OS-integration state of an installed Progressive Web App (PWA), such as its badge count and registered file handlers.

**Remarks:**

Only available over a pipe connection. See [Browser.installPWA()](./puppeteer.browser.installpwa.md). Meaningful only for an app that is currently installed; querying an unknown manifest id rejects.

</td></tr>
<tr><td>

<span id="getwindowbounds">[getWindowBounds(windowId)](./puppeteer.browser.getwindowbounds.md)</span>

</td><td>

</td><td>

Gets the specified window [bounds](./puppeteer.windowbounds.md).

</td></tr>
<tr><td>

<span id="installextension">[installExtension(path, options)](./puppeteer.browser.installextension.md)</span>

</td><td>

</td><td>

Installs an extension and returns the ID.

</td></tr>
<tr><td>

<span id="installpwa">[installPWA(options)](./puppeteer.browser.installpwa.md)</span>

</td><td>

</td><td>

Installs a Progressive Web App (PWA) and returns its manifest id.

**Remarks:**

Only available when connected to the browser over a pipe connection. Set `pipe: true` in [puppeteer.launch](./puppeteer.puppeteernode.launch.md); the launch option defaults to `false`. The underlying `PWA` CDP domain is not exposed over a WebSocket connection.

The returned manifest id echoes [InstallPWAOptions.manifestId](./puppeteer.installpwaoptions.md#manifestid), so it can be passed directly to [Browser.launchPWA()](./puppeteer.browser.launchpwa.md), [Browser.getPWAState()](./puppeteer.browser.getpwastate.md), or [Browser.uninstallPWA()](./puppeteer.browser.uninstallpwa.md).

</td></tr>
<tr><td>

<span id="launchpwa">[launchPWA(options)](./puppeteer.browser.launchpwa.md)</span>

</td><td>

</td><td>

Launches an installed Progressive Web App (PWA) and resolves with the [page](./puppeteer.page.md) backing the app window.

**Remarks:**

Only available over a pipe connection. See [Browser.installPWA()](./puppeteer.browser.installpwa.md).

`PWA.launch` resolves with the id of the launched \_tab\_ target. Puppeteer does not expose tab targets through [Browser.targets()](./puppeteer.browser.targets.md); this method instead resolves with the tab's child page target (the app's web contents). If Chromium focuses an existing app window, this returns that window's existing page.

</td></tr>
<tr><td>

<span id="newpage">[newPage(options)](./puppeteer.browser.newpage.md)</span>

</td><td>

</td><td>

Creates a new [page](./puppeteer.page.md) in the [default browser context](./puppeteer.browser.defaultbrowsercontext.md).

</td></tr>
<tr><td>

<span id="pages">[pages(includeAll)](./puppeteer.browser.pages.md)</span>

</td><td>

</td><td>

Gets a list of all open [pages](./puppeteer.page.md) inside this [Browser](./puppeteer.browser.md).

If there are multiple [browser contexts](./puppeteer.browsercontext.md), this returns all [pages](./puppeteer.page.md) in all [browser contexts](./puppeteer.browsercontext.md).

**Remarks:**

Non-visible [pages](./puppeteer.page.md), such as `"background_page"`, will not be listed here. You can find them using [Target.page()](./puppeteer.target.page.md).

</td></tr>
<tr><td>

<span id="process">[process()](./puppeteer.browser.process.md)</span>

</td><td>

</td><td>

Gets the associated [ChildProcess](https://nodejs.org/api/child_process.html#class-childprocess).

</td></tr>
<tr><td>

<span id="removescreen">[removeScreen(screenId)](./puppeteer.browser.removescreen.md)</span>

</td><td>

</td><td>

Removes a screen.

**Remarks:**

Only supported in headless mode. Fails if the primary screen id is specified.

</td></tr>
<tr><td>

<span id="screens">[screens()](./puppeteer.browser.screens.md)</span>

</td><td>

</td><td>

Gets a list of [screen information objects](./puppeteer.screeninfo.md).

</td></tr>
<tr><td>

<span id="setcookie">[setCookie(cookies)](./puppeteer.browser.setcookie.md)</span>

</td><td>

</td><td>

Sets cookies in the default [BrowserContext](./puppeteer.browsercontext.md).

**Remarks:**

Shortcut for [browser.defaultBrowserContext().setCookie()](./puppeteer.browsercontext.setcookie.md).

</td></tr>
<tr><td>

<span id="setpermission">[setPermission(origin, permissions)](./puppeteer.browser.setpermission.md)</span>

</td><td>

</td><td>

Sets the permission for a specific origin in the default [BrowserContext](./puppeteer.browsercontext.md).

**Remarks:**

Shortcut for [browser.defaultBrowserContext().setPermission()](./puppeteer.browsercontext.setpermission.md).

</td></tr>
<tr><td>

<span id="setwindowbounds">[setWindowBounds(windowId, windowBounds)](./puppeteer.browser.setwindowbounds.md)</span>

</td><td>

</td><td>

Sets the specified window [bounds](./puppeteer.windowbounds.md).

</td></tr>
<tr><td>

<span id="target">[target()](./puppeteer.browser.target.md)</span>

</td><td>

</td><td>

Gets the [target](./puppeteer.target.md) associated with the [default browser context](./puppeteer.browser.defaultbrowsercontext.md)).

</td></tr>
<tr><td>

<span id="targets">[targets()](./puppeteer.browser.targets.md)</span>

</td><td>

</td><td>

Gets all active [targets](./puppeteer.target.md).

In case of multiple [browser contexts](./puppeteer.browsercontext.md), this returns all [targets](./puppeteer.target.md) in all [browser contexts](./puppeteer.browsercontext.md).

</td></tr>
<tr><td>

<span id="uninstallextension">[uninstallExtension(id)](./puppeteer.browser.uninstallextension.md)</span>

</td><td>

</td><td>

Uninstalls an extension.

</td></tr>
<tr><td>

<span id="uninstallpwa">[uninstallPWA(options)](./puppeteer.browser.uninstallpwa.md)</span>

</td><td>

</td><td>

Uninstalls a previously installed Progressive Web App (PWA).

**Remarks:**

Only available over a pipe connection. See [Browser.installPWA()](./puppeteer.browser.installpwa.md).

</td></tr>
<tr><td>

<span id="useragent">[userAgent()](./puppeteer.browser.useragent.md)</span>

</td><td>

</td><td>

Gets this [browser's](./puppeteer.browser.md) original user agent.

[Pages](./puppeteer.page.md) can override the user agent with [Page.setUserAgent()](./puppeteer.page.setuseragent.md#overload-2).

</td></tr>
<tr><td>

<span id="version">[version()](./puppeteer.browser.version.md)</span>

</td><td>

</td><td>

Gets a string representing this [browser's](./puppeteer.browser.md) name and version.

For headless browser, this is similar to `"HeadlessChrome/61.0.3153.0"`. For non-headless or new-headless, this is similar to `"Chrome/61.0.3153.0"`. For Firefox, it is similar to `"Firefox/116.0a1"`.

The format of [Browser.version()](./puppeteer.browser.version.md) might change with future releases of browsers.

</td></tr>
<tr><td>

<span id="waitfortarget">[waitForTarget(predicate, options)](./puppeteer.browser.waitfortarget.md)</span>

</td><td>

</td><td>

Waits until a [target](./puppeteer.target.md) matching the given `predicate` appears and returns it.

This will look all open [browser contexts](./puppeteer.browsercontext.md).

</td></tr>
<tr><td>

<span id="wsendpoint">[wsEndpoint()](./puppeteer.browser.wsendpoint.md)</span>

</td><td>

</td><td>

Gets the WebSocket URL to connect to this [browser](./puppeteer.browser.md).

This is usually used with [Puppeteer.connect()](./puppeteer.puppeteer.connect.md).

You can find the debugger URL (`webSocketDebuggerUrl`) from `http://HOST:PORT/json/version`.

See [browser endpoint](https://chromedevtools.github.io/devtools-protocol/#how-do-i-access-the-browser-target) for more information.

**Remarks:**

The format is always `ws://HOST:PORT/devtools/browser/<id>`.

</td></tr>
</tbody></table>
