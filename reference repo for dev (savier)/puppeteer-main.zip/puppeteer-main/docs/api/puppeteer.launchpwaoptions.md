---
sidebar_label: LaunchPWAOptions
---

# LaunchPWAOptions interface

Options for [Browser.launchPWA()](./puppeteer.browser.launchpwa.md).

### Signature

```typescript
export interface LaunchPWAOptions
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th><th>

Default

</th></tr></thead>
<tbody><tr><td>

<span id="manifestid">manifestId</span>

</td><td>

</td><td>

string

</td><td>

The id from the web app's manifest file.

</td><td>

</td></tr>
<tr><td>

<span id="timeout">timeout</span>

</td><td>

`optional`

</td><td>

number

</td><td>

Maximum time in milliseconds to wait for the app's page target to appear. Defaults to 30 seconds. Pass `0` to disable the timeout.

</td><td>

</td></tr>
<tr><td>

<span id="url">url</span>

</td><td>

`optional`

</td><td>

string

</td><td>

An optional URL within the app's scope to launch. Defaults to the app's start URL.

</td><td>

</td></tr>
</tbody></table>
