use std::hint::black_box;

use blobstore::bitmask::MmapBitmask;
use blobstore::config::DEFAULT_REGION_SIZE_BLOCKS;
use common::bitvec::BitVec;
use criterion::{Criterion, criterion_group, criterion_main};
use rand::RngExt;
use rand::rngs::SmallRng;

pub fn bench_bitmask_ops(c: &mut Criterion) {
    let distr = rand::distr::StandardUniform;
    let rng = rand::make_rng::<SmallRng>();
    let random_bitvec = rng
        .sample_iter::<bool, _>(distr)
        .take(1000 * DEFAULT_REGION_SIZE_BLOCKS)
        .collect::<BitVec>();

    let mut bitslice_iter = random_bitvec.windows(DEFAULT_REGION_SIZE_BLOCKS).cycle();

    c.bench_function("calculate_gaps", |b| {
        b.iter(|| {
            let bitslice = bitslice_iter.next().unwrap();
            MmapBitmask::calculate_gaps(black_box(bitslice), DEFAULT_REGION_SIZE_BLOCKS)
        })
    });

    c.bench_function("find_available_blocks_in_slice", |b| {
        let mut rng = rand::make_rng::<SmallRng>();
        b.iter(|| {
            let bitslice = bitslice_iter.next().unwrap();
            let num_blocks = rng.random_range(1..10);
            MmapBitmask::find_available_blocks_in_slice(black_box(bitslice), num_blocks, |_| (0, 0))
        })
    });
}

criterion_group!(benches, bench_bitmask_ops);
criterion_main!(benches);
