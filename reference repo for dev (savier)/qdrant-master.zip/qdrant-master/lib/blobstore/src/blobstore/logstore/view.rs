use std::borrow::Cow;
use std::marker::PhantomData;

use common::counter::counter_cell::CounterCell;
use common::counter::hardware_counter::HardwareCounterCell;
use common::counter::referenced_counter::HwMetricRefCounter;
use common::generic_consts::{AccessPattern, Sequential};
use common::universal_io::{UniversalRead, UserData};

use super::page::AppendOnlyPages;
use crate::Result;
use crate::blob::Blob;
use crate::config::LogstoreConfig;
use crate::error::BlobstoreError;
use crate::tracker::append_only::AppendOnlyTracker;
use crate::tracker::{PointOffset, ValuePointer};

/// A non-owning view into logstore data.
///
/// Holds borrowed references to the tracker and pages, and contains all reading logic.
///
/// All data is read through the universal IO backend `S`.
pub(crate) struct LogstoreView<'a, V, S: UniversalRead> {
    config: &'a LogstoreConfig,
    tracker: &'a AppendOnlyTracker<S>,
    pages: &'a AppendOnlyPages<S>,
    _phantom: PhantomData<V>,
}

impl<'a, V, S: UniversalRead> LogstoreView<'a, V, S> {
    pub(super) fn new(
        config: &'a LogstoreConfig,
        tracker: &'a AppendOnlyTracker<S>,
        pages: &'a AppendOnlyPages<S>,
    ) -> Self {
        Self {
            config,
            tracker,
            pages,
            _phantom: PhantomData,
        }
    }

    pub(crate) fn max_point_offset(&self) -> PointOffset {
        self.tracker.pointer_count()
    }

    /// Return the storage size in bytes (precise, the exact amount of appended value data).
    pub(crate) fn get_storage_size_bytes(&self) -> usize {
        self.pages.len() as usize
    }

    /// Read the raw value bytes at the given pointer.
    pub(crate) fn read_from_pages<P: AccessPattern>(
        &self,
        pointer: ValuePointer,
    ) -> Result<Cow<'_, [u8]>> {
        self.pages.read_value::<P>(pointer)
    }
}

impl<'a, V: Blob, S: UniversalRead> LogstoreView<'a, V, S> {
    /// Get the value for a given point offset.
    pub(crate) fn get_value<P: AccessPattern>(
        &self,
        point_offset: PointOffset,
        hw_counter: &HardwareCounterCell,
    ) -> Result<Option<V>> {
        let bytes = self.get_value_bytes::<P>(point_offset, hw_counter)?;
        Ok(bytes.map(|bytes| V::from_bytes(&bytes)))
    }

    /// Get the serialized value for a given point offset.
    ///
    /// The returned bytes are the value in its [`Blob`] encoding, always decompressed.
    pub(crate) fn get_value_bytes<P: AccessPattern>(
        &self,
        point_offset: PointOffset,
        hw_counter: &HardwareCounterCell,
    ) -> Result<Option<Cow<'_, [u8]>>> {
        let Some(pointer) = self.tracker.get::<P>(point_offset)? else {
            return Ok(None);
        };

        let raw = self.read_from_pages::<P>(pointer)?;
        hw_counter.payload_io_read_counter().incr_delta(raw.len());

        Ok(Some(self.config.compression.decompress(raw)))
    }

    /// Iterate over all given values and execute callback for each one.
    ///
    /// The mappings and the value data are both fetched with batched reads, so async backends
    /// can serve them in parallel. The callback may be invoked in a different order than the
    /// requested point offsets.
    ///
    /// Return `false` from the callback to stop iteration early.
    pub(crate) fn read_values<P, U, E>(
        &self,
        point_offsets: impl Iterator<Item = (U, PointOffset)>,
        mut callback: impl FnMut(U, PointOffset, Option<V>) -> Result<bool, E>,
        hw_counter_cell: &CounterCell,
    ) -> Result<bool, E>
    where
        P: AccessPattern,
        U: UserData,
        E: From<BlobstoreError>,
    {
        self.read_values_bytes::<P, _, _>(
            point_offsets,
            |user_data, point_offset, bytes| {
                callback(user_data, point_offset, bytes.map(V::from_bytes))
            },
            hw_counter_cell,
        )
    }

    /// Byte-blob analogue of [`Self::read_values`]: hands the callback each value in its
    /// [`Blob`] encoding, always decompressed — the same bytes `V::to_bytes` would produce.
    pub(crate) fn read_values_bytes<P, U, E>(
        &self,
        point_offsets: impl Iterator<Item = (U, PointOffset)>,
        mut callback: impl FnMut(U, PointOffset, Option<&[u8]>) -> Result<bool, E>,
        hw_counter_cell: &CounterCell,
    ) -> Result<bool, E>
    where
        P: AccessPattern,
        U: UserData,
        E: From<BlobstoreError>,
    {
        let point_offsets = point_offsets
            .map(|(user_data, point_offset)| ((user_data, point_offset), point_offset));

        let mut pointers = Vec::new();

        for result in self.tracker.iter(point_offsets).map_err(E::from)? {
            let ((user_data, point_offset), pointer) = result.map_err(E::from)?;

            let Some(pointer) = pointer else {
                if !callback(user_data, point_offset, None)? {
                    return Ok(false);
                }

                continue;
            };

            pointers.push(((user_data, point_offset), pointer));
        }

        self.pages.read_batch_values::<P, _, _>(
            pointers.into_iter(),
            |(user_data, point_offset), bytes| {
                hw_counter_cell.incr_delta(bytes.len());

                let decompressed = self.config.compression.decompress(bytes);
                callback(user_data, point_offset, Some(&decompressed))
            },
        )
    }

    /// Iterate over a contiguous range of point offsets and execute callback for each existing
    /// value. Missing values are skipped.
    ///
    /// The mappings for the whole range are fetched with a single batched read, and the value
    /// data with batched reads through the backend's read pipeline, so async backends can fetch
    /// values in parallel. The callback may therefore be invoked in a different order than the
    /// requested point offsets.
    ///
    /// Return `false` from the callback to stop iteration early. Returns whether iteration should
    /// continue.
    pub(crate) fn iter_range<F, E>(
        &self,
        point_offsets: std::ops::Range<PointOffset>,
        mut callback: F,
        hw_counter: HwMetricRefCounter,
    ) -> Result<bool, E>
    where
        F: FnMut(PointOffset, V) -> Result<bool, E>,
        E: From<BlobstoreError>,
    {
        let start = point_offsets.start;
        let pointers = self
            .tracker
            .get_range::<Sequential>(point_offsets)
            .map_err(E::from)?;

        // Skip the gaps, and carry each value's point offset through the batch as user data
        let pointers = pointers
            .into_iter()
            .enumerate()
            .filter_map(|(index, pointer)| {
                pointer.map(|pointer| (start + index as PointOffset, pointer))
            });

        self.pages
            .read_batch_values::<Sequential, _, _>(pointers, |point_offset, bytes| {
                hw_counter.incr_delta(bytes.len());

                let decompressed = self.config.compression.decompress(bytes);
                let value = V::from_bytes(&decompressed);

                callback(point_offset, value)
            })
    }
}
