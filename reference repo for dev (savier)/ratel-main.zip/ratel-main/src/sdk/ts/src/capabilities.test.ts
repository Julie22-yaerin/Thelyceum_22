import { trace } from "@opentelemetry/api";
import {
  BasicTracerProvider,
  InMemorySpanExporter,
  SimpleSpanProcessor,
} from "@opentelemetry/sdk-trace-base";
import { afterEach, describe, expect, it } from "vitest";
import {
  type ExecutableTool,
  INVOKE_TOOL_ERROR_CAUSE,
  INVOKE_TOOL_ID,
  invokeToolTool,
  isInvokeToolError,
  runCapabilitiesSearch,
  SEARCH_CAPABILITIES_ID,
  type SearchCapabilitiesResult,
  type Skill,
  SkillCatalog,
  searchCapabilitiesTool,
  ToolCatalog,
} from "./index.js";

// A span test may register a global OTel provider; drop it after every test so it
// can't leak into the others (which assert on the local recordEvent stream).
afterEach(() => trace.disable());

const readFile: ExecutableTool = {
  id: "fs__read_file",
  name: "read_file",
  description: "Read a file from local disk.",
  inputSchema: { properties: { path: { type: "string", description: "path to read" } } },
  outputSchema: {},
  execute: async ({ path }) => ({ contents: `contents of ${path}` }),
};

const sendEmail: ExecutableTool = {
  id: "mail__send_email",
  name: "send_email",
  description: "Send an email via SMTP.",
  inputSchema: { properties: { to: { type: "string" } } },
  outputSchema: {},
  execute: async ({ to }) => ({ messageId: "abc", to }),
};

async function skillCatalogWith(...skills: Skill[]): Promise<SkillCatalog> {
  const c = new SkillCatalog();
  for (const s of skills) await c.register(s);
  return c;
}

const vercelSkill: Skill = {
  id: "vercel-deploy",
  name: "vercel-deploy",
  description: "How to deploy to Vercel: env vars, preview vs production, rollbacks.",
  tags: ["vercel", "deployment"],
  body: "# Vercel Deploy",
};

describe("searchCapabilitiesTool", () => {
  it("uses the canonical id and name", () => {
    const tool = searchCapabilitiesTool(new ToolCatalog());
    expect(tool.id).toBe(SEARCH_CAPABILITIES_ID);
    expect(SEARCH_CAPABILITIES_ID).toBe("search_capabilities");
  });

  it("returns tools grouped by server and an empty skills bucket when no skill catalog", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    await tools.register(sendEmail);
    const tool = searchCapabilitiesTool(tools);

    const result = (await tool.execute({ query: "read a file" })) as SearchCapabilitiesResult;
    expect(result.tools.groups[0].server.name).toBe("fs");
    expect(result.tools.groups[0].hits[0].toolId).toBe("fs__read_file");
    expect(result.skills).toEqual([]);
  });

  it("returns a skills bucket alongside tools when a skill catalog is wired", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    const tool = searchCapabilitiesTool(tools, await skillCatalogWith(vercelSkill));

    const result = (await tool.execute({ query: "deploy to vercel" })) as SearchCapabilitiesResult;
    expect(result.skills[0]?.skillId).toBe("vercel-deploy");
    expect(result.skills[0]?.description).toContain("Vercel");
  });

  it("never starves skills: many matching tools do not crowd the skill out of its own bucket", async () => {
    const tools = new ToolCatalog();
    for (let i = 0; i < 8; i++) {
      await tools.register({
        id: `deploy__tool_${i}`,
        name: `deploy_${i}`,
        description: "deploy the project to production",
        inputSchema: {},
        outputSchema: {},
        execute: async () => ({}),
      });
    }
    const tool = searchCapabilitiesTool(tools, await skillCatalogWith(vercelSkill));

    const result = (await tool.execute({
      query: "deploy to production",
      topKTools: 5,
      topKSkills: 3,
    })) as SearchCapabilitiesResult;
    // tools bucket capped at 5, skills bucket independently retains the skill
    const toolCount = result.tools.groups.reduce((n, g) => n + g.hits.length, 0);
    expect(toolCount).toBeLessThanOrEqual(5);
    expect(result.skills.map((s) => s.skillId)).toContain("vercel-deploy");
  });

  it("pulls a matched skill's declared tools into the tools bucket, additively and deduped", async () => {
    const deployPush: ExecutableTool = {
      id: "vercel__push",
      name: "push",
      description: "Deploy the project to Vercel production.",
      inputSchema: {},
      outputSchema: {},
      execute: async () => ({}),
    };
    const tools = new ToolCatalog();
    await tools.register(deployPush); // matches the query "deploy to vercel"
    await tools.register(readFile); // declared by the skill but does NOT match the query
    const deployWithDeps: Skill = {
      ...vercelSkill,
      // one dep already query-matched (vercel__push), one not (fs__read_file), one absent
      tools: ["vercel__push", "fs__read_file", "ghost__missing"],
    };
    const tool = searchCapabilitiesTool(tools, await skillCatalogWith(deployWithDeps));

    const result = (await tool.execute({
      query: "deploy to vercel",
      topKTools: 5,
      topKSkills: 3,
    })) as SearchCapabilitiesResult;

    const toolIds = result.tools.groups.flatMap((g) => g.hits.map((h) => h.toolId));
    // read_file rode in on the skill even though it never matched the query…
    expect(toolIds).toContain("fs__read_file");
    // …vercel__push appears exactly once (query hit + dep must not double it)…
    expect(toolIds.filter((id) => id === "vercel__push")).toHaveLength(1);
    // …and a declared id the catalog doesn't have is silently skipped.
    expect(toolIds).not.toContain("ghost__missing");
  });

  it("includes upstream server description in the tool group", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    const tool = searchCapabilitiesTool(tools, undefined, {
      upstreamServers: [{ name: "fs", description: "filesystem helpers" }],
    });
    const result = (await tool.execute({ query: "read a file" })) as SearchCapabilitiesResult;
    expect(result.tools.groups.find((g) => g.server.name === "fs")?.server.description).toBe(
      "filesystem helpers",
    );
  });

  it("emits gateway_search telemetry for the tool search", async () => {
    const tools = new ToolCatalog({ trace: { kind: "memory", sessionId: "t" } });
    await tools.register(readFile);
    tools.drainTraceEvents();
    const tool = searchCapabilitiesTool(tools);
    await tool.execute({ query: "read a file", topKTools: 3 });
    const events = tools.drainTraceEvents() as Array<Record<string, unknown>>;
    const gw = events.find((e) => e.type === "gateway_search");
    expect(gw?.top_k).toBe(3);
    expect(gw?.origin).toBe("agent"); // searchCapabilitiesTool drives runCapabilitiesSearch as origin "agent"
  });

  it("clamps a non-positive / non-integer topK back to the default", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    await tools.register(sendEmail);
    const tool = searchCapabilitiesTool(tools);
    const count = async (input: object): Promise<number> => {
      const r = (await tool.execute(input)) as SearchCapabilitiesResult;
      return r.tools.groups.reduce((n, g) => n + g.hits.length, 0);
    };
    const q = "read a file or send an email";
    const baseline = await count({ query: q }); // default top-K
    // 0 / negative / fractional must fall back to the default, never return zero
    // tools (TS) or an unbounded set (negative wrapping to u32 in the native layer).
    expect(await count({ query: q, topKTools: 0 })).toBe(baseline);
    expect(await count({ query: q, topKTools: -3 })).toBe(baseline);
    expect(await count({ query: q, topKTools: 1.5 })).toBe(baseline);
    expect(await count({ query: q, topKTools: 1 })).toBe(1); // a valid positive int is honored
  });

  it("advertises skills in its description only when a non-empty skill catalog is wired", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);

    const toolsOnly = searchCapabilitiesTool(tools);
    expect(toolsOnly.description).not.toContain("get_skill_content");
    expect(toolsOnly.description.toLowerCase()).not.toContain("skill");

    const withSkills = searchCapabilitiesTool(tools, await skillCatalogWith(vercelSkill));
    expect(withSkills.description).toContain("get_skill_content");

    // an empty catalog is treated as no skills
    const emptyCatalog = searchCapabilitiesTool(tools, new SkillCatalog());
    expect(emptyCatalog.description).not.toContain("get_skill_content");
  });

  it("advertiseSkills overrides the size-based description default in both directions", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    // A host that always exposes get_skill_content pins the skills clause on…
    const pinnedOn = searchCapabilitiesTool(tools, new SkillCatalog(), { advertiseSkills: true });
    expect(pinnedOn.description).toContain("get_skill_content");
    // …and one that never exposes it pins the clause off despite a genuinely
    // non-empty catalog — awaited, so the "despite live skills" precondition is
    // real and the override (not a short-circuit on an unresolved Promise) is
    // what suppresses the clause.
    const pinnedOff = searchCapabilitiesTool(tools, await skillCatalogWith(vercelSkill), {
      advertiseSkills: false,
    });
    expect(pinnedOff.description).not.toContain("get_skill_content");
  });
});

describe("runCapabilitiesSearch", () => {
  it("records one gateway_search event stamped with the given origin", async () => {
    const tools = new ToolCatalog({ trace: { kind: "memory", sessionId: "t" } });
    tools.register(readFile);
    tools.drainTraceEvents();

    await runCapabilitiesSearch(tools, "read a file", { topKTools: 3, origin: "direct" });

    const ev = (tools.drainTraceEvents() as Array<Record<string, unknown>>).find(
      (e) => e.type === "gateway_search",
    );
    // Every field of the behavior-identity contract, not just origin: a dropped
    // hits/query would silently break gateway_search analytics on both paths.
    expect(ev?.origin).toBe("direct");
    expect(ev?.top_k).toBe(3);
    expect(ev?.query).toBe("read a file");
    expect(ev?.hits).toBe(1); // only readFile is registered and it matches
  });

  it("produces the same shape searchCapabilitiesTool returns (single source of truth)", async () => {
    const tools = new ToolCatalog();
    tools.register(readFile);
    tools.register(sendEmail);
    const skills = await skillCatalogWith(vercelSkill);

    const direct = await runCapabilitiesSearch(tools, "read a file", { skillCatalog: skills });
    const viaTool = (await searchCapabilitiesTool(tools, skills).execute({
      query: "read a file",
    })) as SearchCapabilitiesResult;

    expect(direct.tools.groups[0].server.name).toBe(viaTool.tools.groups[0].server.name);
    expect(direct.tools.groups[0].hits[0].toolId).toBe(viaTool.tools.groups[0].hits[0].toolId);
  });
});

describe("invokeToolTool", () => {
  it("uses the canonical id and invokes by nested args", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    const tool = invokeToolTool(tools);
    expect(tool.id).toBe(INVOKE_TOOL_ID);
    const result = await tool.execute({ toolId: "fs__read_file", args: { path: "/tmp/x" } });
    expect(result).toEqual({ contents: "contents of /tmp/x" });
  });

  it("forwards an opaque invocation context to the selected tool by identity", async () => {
    const context = { adapter: "test", value: { tenantId: "tenant-42" } };
    const tools = new ToolCatalog();
    await tools.register({
      ...readFile,
      execute: (_input, receivedContext) => ({ sameContext: receivedContext === context }),
    });

    const result = await invokeToolTool(tools).execute(
      { toolId: "fs__read_file", args: { path: "/tmp/x" } },
      context,
    );

    expect(result).toEqual({ sameContext: true });
  });

  it("tolerates flattened args", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    const tool = invokeToolTool(tools);
    const result = await tool.execute({ toolId: "fs__read_file", path: "/tmp/y" });
    expect(result).toEqual({ contents: "contents of /tmp/y" });
  });

  it("returns a raw result (no relatedSkills wrapping)", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    const tool = invokeToolTool(tools);
    const out = await tool.execute({ toolId: "fs__read_file", args: { path: "/x" } });
    expect(out).toEqual({ contents: "contents of /x" });
  });

  it("preserves an AsyncIterable synchronously and settles trace events after iteration", async () => {
    const tools = new ToolCatalog({ trace: { kind: "memory", sessionId: "stream" } });
    await tools.register({
      id: "jobs__watch",
      name: "watch",
      description: "Watch a job.",
      inputSchema: {},
      outputSchema: {},
      execute: () =>
        (async function* () {
          yield { progress: 25 };
          yield { progress: 100 };
        })(),
    });
    tools.drainTraceEvents();

    const result = invokeToolTool(tools).execute({ toolId: "jobs__watch", args: {} });

    expect(typeof (result as AsyncIterable<unknown>)[Symbol.asyncIterator]).toBe("function");
    expect(typeof (result as { then?: unknown }).then).not.toBe("function");
    expect(
      (tools.drainTraceEvents() as Array<{ type: string }>).map((event) => event.type),
    ).toEqual(["invoke_start"]);

    const outputs: unknown[] = [];
    for await (const output of result as AsyncIterable<unknown>) outputs.push(output);

    expect(outputs).toEqual([{ progress: 25 }, { progress: 100 }]);
    const eventTypes = (tools.drainTraceEvents() as Array<{ type: string }>).map(
      (event) => event.type,
    );
    expect(eventTypes).toContain("invoke_end");
    expect(eventTypes).toContain("gateway_invoke");
  });

  it("preserves a stream after the host prevalidates with an async target parser", async () => {
    const tools = new ToolCatalog();
    await tools.register({
      id: "jobs__watch",
      name: "watch",
      description: "Watch a job.",
      inputSchema: {},
      outputSchema: {},
      validateInput: async (input) => ({
        success: true,
        value: { jobId: String((input as { jobId: unknown }).jobId).toUpperCase() },
      }),
      execute: ({ jobId }) =>
        (async function* () {
          yield { jobId, progress: 100 };
        })(),
    });
    const invoke = invokeToolTool(tools);
    const parsed = await invoke.validateInput?.({
      toolId: "jobs__watch",
      args: { jobId: "job-1" },
    });
    if (!parsed?.success) throw parsed?.error ?? new Error("validation failed");

    const result = invoke.execute(parsed.value);

    expect(typeof (result as AsyncIterable<unknown>)[Symbol.asyncIterator]).toBe("function");
    const outputs: unknown[] = [];
    for await (const output of result as AsyncIterable<unknown>) outputs.push(output);
    expect(outputs).toEqual([{ jobId: "JOB-1", progress: 100 }]);
  });

  it("brands a caught target error non-enumerably while keeping the generic result structured", async () => {
    const failure = new Error("target failed");
    const tools = new ToolCatalog();
    await tools.register({
      id: "jobs__fail",
      name: "fail",
      description: "Fail a job.",
      inputSchema: {},
      outputSchema: {},
      execute: async () => {
        throw failure;
      },
    });

    const result = await invokeToolTool(tools).execute({ toolId: "jobs__fail", args: {} });

    expect(result).toEqual({ error: "tool jobs__fail threw: target failed", isError: true });
    expect(isInvokeToolError(result)).toBe(true);
    if (!isInvokeToolError(result)) throw new Error("expected a branded invoke error");
    expect(result[INVOKE_TOOL_ERROR_CAUSE]).toBe(failure);
    expect(Object.keys(result)).toEqual(["error", "isError"]);
    expect(Object.getOwnPropertyDescriptor(result, INVOKE_TOOL_ERROR_CAUSE)?.enumerable).toBe(
      false,
    );
    expect(JSON.parse(JSON.stringify(result))).toEqual({
      error: "tool jobs__fail threw: target failed",
      isError: true,
    });
  });

  it("settles an errored AsyncIterable as a branded result after its preliminary outputs", async () => {
    const failure = new Error("stream failed");
    const tools = new ToolCatalog({ trace: { kind: "memory", sessionId: "stream-error" } });
    await tools.register({
      id: "jobs__broken_watch",
      name: "broken_watch",
      description: "Watch a broken job.",
      inputSchema: {},
      outputSchema: {},
      execute: () =>
        (async function* () {
          yield { progress: 25 };
          throw failure;
        })(),
    });
    tools.drainTraceEvents();

    const result = invokeToolTool(tools).execute({ toolId: "jobs__broken_watch", args: {} });
    const outputs: unknown[] = [];
    for await (const output of result as AsyncIterable<unknown>) outputs.push(output);

    expect(outputs[0]).toEqual({ progress: 25 });
    expect(isInvokeToolError(outputs[1])).toBe(true);
    const eventTypes = (tools.drainTraceEvents() as Array<{ type: string }>).map(
      (event) => event.type,
    );
    expect(eventTypes).toContain("invoke_error");
    expect(eventTypes).toContain("gateway_error");
    expect(eventTypes).not.toContain("gateway_invoke");
  });

  it("returns an error object (with isError) for unknown toolId", async () => {
    const tool = invokeToolTool(new ToolCatalog());
    const result = (await tool.execute({ toolId: "nope", args: {} })) as {
      error: string;
      isError?: boolean;
    };
    expect(result.error).toMatch(/unknown toolId: nope/);
    expect(result.isError).toBe(true);
  });

  it("rejects non-object args instead of forwarding stray top-level keys", async () => {
    const tools = new ToolCatalog();
    await tools.register(readFile);
    const tool = invokeToolTool(tools);
    // `args` present but a string → reject, don't silently flatten.
    const result = (await tool.execute({ toolId: "fs__read_file", args: "oops", path: "/x" })) as {
      error: string;
      isError?: boolean;
    };
    expect(result.error).toMatch(/must be an object/);
    expect(result.isError).toBe(true);
  });

  it("treats explicit args: null as no args, not a stray `args` key", async () => {
    const tools = new ToolCatalog();
    // Echo tool returns exactly the args object it was invoked with.
    await tools.register({
      id: "x__echo",
      name: "echo",
      description: "echoes its args",
      inputSchema: {},
      outputSchema: {},
      execute: async (a) => a,
    });
    const tool = invokeToolTool(tools);
    // explicit null → {} (no leftover `args` key), not { args: null }
    expect(await tool.execute({ toolId: "x__echo", args: null })).toEqual({});
    // a genuinely flattened call still passes its keys through (minus toolId/args)
    expect(await tool.execute({ toolId: "x__echo", foo: 1, args: null })).toEqual({ foo: 1 });
  });

  it("keeps invoke_tool guidance neutral about the discovery tool (compat-safe)", async () => {
    // invoke_tool is shared by the deprecated `search_tools` and the new
    // `search_capabilities`; naming either would misdirect the other deployment.
    const tool = invokeToolTool(new ToolCatalog());
    expect(tool.description).not.toContain("search_capabilities");
    const toolIdDesc = (tool.inputSchema as { properties: { toolId: { description: string } } })
      .properties.toolId.description;
    expect(toolIdDesc).not.toContain("search_capabilities");
    const result = (await tool.execute({ toolId: "nope", args: {} })) as { error: string };
    expect(result.error).not.toContain("search_capabilities");
  });

  it("returns a needs_auth payload + calls onUnauthorized on UnauthorizedError", async () => {
    const tools = new ToolCatalog();
    class UnauthorizedError extends Error {
      constructor(m: string) {
        super(m);
        this.name = "UnauthorizedError";
      }
    }
    await tools.register({
      id: "stripe__charges",
      name: "charges",
      description: "...",
      inputSchema: {},
      outputSchema: {},
      execute: async () => {
        throw new UnauthorizedError("expired");
      },
    });
    const seen: string[] = [];
    const tool = invokeToolTool(tools, { onUnauthorized: (u) => seen.push(u) });
    const result = (await tool.execute({ toolId: "stripe__charges", args: {} })) as {
      error: string;
      isError?: boolean;
      upstream?: string;
    };
    expect(result.error).toBe("needs_auth");
    // needs_auth is a failed call (the tool didn't run) — host promotes on isError.
    expect(result.isError).toBe(true);
    expect(result.upstream).toBe("stripe");
    expect(seen).toEqual(["stripe"]);
  });

  it("emits a ratel.auth.flow span (outcome=needs_auth, upstream) on the needs_auth path", async () => {
    const exporter = new InMemorySpanExporter();
    trace.setGlobalTracerProvider(
      new BasicTracerProvider({ spanProcessors: [new SimpleSpanProcessor(exporter)] }),
    );
    const tools = new ToolCatalog();
    class UnauthorizedError extends Error {
      constructor(m: string) {
        super(m);
        this.name = "UnauthorizedError";
      }
    }
    await tools.register({
      id: "stripe__charges",
      name: "charges",
      description: "...",
      inputSchema: {},
      outputSchema: {},
      execute: async () => {
        throw new UnauthorizedError("expired");
      },
    });
    const tool = invokeToolTool(tools);
    await tool.execute({ toolId: "stripe__charges", args: {} });

    const [span] = exporter.getFinishedSpans().filter((s) => s.name === "ratel.auth.flow");
    expect(span, "one ratel.auth.flow span").toBeTruthy();
    expect(span.attributes["ratel.auth.outcome"]).toBe("needs_auth");
    expect(span.attributes["ratel.upstream.server"]).toBe("stripe");
  });

  it("emits gateway_invoke on success", async () => {
    const tools = new ToolCatalog({ trace: { kind: "memory", sessionId: "t" } });
    await tools.register(readFile);
    tools.drainTraceEvents();
    const tool = invokeToolTool(tools);
    await tool.execute({ toolId: "fs__read_file", args: { path: "/x" } });
    const events = tools.drainTraceEvents() as Array<Record<string, unknown>>;
    expect(events.find((e) => e.type === "gateway_invoke")?.tool_id).toBe("fs__read_file");
  });
});
