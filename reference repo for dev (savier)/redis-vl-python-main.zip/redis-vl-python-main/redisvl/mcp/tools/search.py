import asyncio
import inspect
from typing import Any

from redisvl.mcp.auth import ensure_tool_scope
from redisvl.mcp.config import reserved_score_metadata_field_names
from redisvl.mcp.errors import MCPErrorCode, RedisVLMCPError, map_exception
from redisvl.mcp.filters import parse_filter
from redisvl.query import AggregateHybridQuery, HybridQuery, TextQuery, VectorQuery
from redisvl.schema import IndexSchema

DEFAULT_SEARCH_DESCRIPTION = "Search records in the configured Redis index."
_DSL_FILTER_FIELD_TYPES = frozenset({"tag", "text", "numeric"})

_NATIVE_HYBRID_DEFAULTS = {
    "combination_method": "LINEAR",
    "linear_text_weight": 0.3,
}
_FALLBACK_HYBRID_UNSUPPORTED_PARAMS = frozenset(
    {
        "vector_search_method",
        "knn_ef_runtime",
        "range_radius",
        "range_epsilon",
        "rrf_window",
        "rrf_constant",
    }
)


def _build_filter_hint(schema: IndexSchema) -> str:
    """Describe fields with typed operator support in the JSON filter DSL."""
    filter_fields = [
        f"{field.name}({getattr(field.type, 'value', field.type)})"
        for field in schema.fields.values()
        if field.type in _DSL_FILTER_FIELD_TYPES
    ]
    if not filter_fields:
        return "Object filter fields: none."
    return "Object filter fields: " + ", ".join(filter_fields) + "."


def _build_return_fields_hint(schema: IndexSchema) -> str:
    """Describe all fields that callers can request in `return_fields`."""
    returnable_fields = [
        field.name for field in schema.fields.values() if field.type != "vector"
    ]
    if not returnable_fields:
        return "Allowed return_fields: none."
    return "Allowed return_fields: " + ", ".join(returnable_fields) + "."


def _build_search_tool_description(
    schema: IndexSchema | None, base_description: str | None = None
) -> str:
    """Build the `search-records` description from static text plus schema hints.

    With multiple bindings configured the schema is ambiguous (the caller picks
    an index per call via `list-indexes`), so per-field hints are omitted and a
    routing note is appended instead.
    """
    description = (base_description or DEFAULT_SEARCH_DESCRIPTION).strip()
    if schema is None:
        return (
            description + " Multiple indexes are configured: call list-indexes "
            "first, then pass the chosen index id as the `index` argument."
        )

    # `exists` is currently accepted for any schema field in the MCP object filter.
    exists_fields = [field.name for field in schema.fields.values()]
    if exists_fields:
        exists_hint = "Object filter exists support: " + ", ".join(exists_fields) + "."
    else:
        exists_hint = "Object filter exists support: none."

    return " ".join(
        [
            description,
            _build_filter_hint(schema),
            exists_hint,
            _build_return_fields_hint(schema),
        ]
    )


def _validate_request(
    *,
    query: str,
    limit: int | None,
    offset: int,
    return_fields: list[str] | None,
    runtime: Any,
    schema: Any,
) -> tuple[int, list[str]]:
    """Validate a `search-records` request and resolve default projection.

    The MCP caller can only supply query text, pagination, filters, and return
    fields. Search mode and tuning are sourced from the selected binding's
    config, so this validation step focuses only on the public request contract.
    """

    if not isinstance(query, str) or not query.strip():
        raise RedisVLMCPError(
            "query must be a non-empty string",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )

    effective_limit = runtime.default_limit if limit is None else limit
    if not isinstance(effective_limit, int) or effective_limit <= 0:
        raise RedisVLMCPError(
            "limit must be greater than 0",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )
    if effective_limit > runtime.max_limit:
        raise RedisVLMCPError(
            f"limit must be less than or equal to {runtime.max_limit}",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )
    if not isinstance(offset, int) or offset < 0:
        raise RedisVLMCPError(
            "offset must be greater than or equal to 0",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )
    if offset + effective_limit > runtime.max_result_window:
        raise RedisVLMCPError(
            "offset + limit must be less than or equal to "
            f"{runtime.max_result_window}",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )

    schema_fields = set(schema.field_names)
    vector_field_names = {
        field_name
        for field_name, field in schema.fields.items()
        if field.type == "vector"
    }

    if return_fields is None:
        fields = [
            field_name
            for field_name in schema.field_names
            if field_name not in vector_field_names
        ]
    else:
        if not isinstance(return_fields, list):
            raise RedisVLMCPError(
                "return_fields must be a list of field names",
                code=MCPErrorCode.INVALID_REQUEST,
                retryable=False,
            )
        fields = []
        for field_name in return_fields:
            if not isinstance(field_name, str) or not field_name:
                raise RedisVLMCPError(
                    "return_fields must contain non-empty strings",
                    code=MCPErrorCode.INVALID_REQUEST,
                    retryable=False,
                )
            if field_name not in schema_fields:
                raise RedisVLMCPError(
                    f"Unknown return field '{field_name}'",
                    code=MCPErrorCode.INVALID_REQUEST,
                    retryable=False,
                )
            if field_name in vector_field_names:
                raise RedisVLMCPError(
                    f"Vector field '{field_name}' cannot be returned",
                    code=MCPErrorCode.INVALID_REQUEST,
                    retryable=False,
                )
            fields.append(field_name)

    return effective_limit, fields


def _normalize_record(
    result: dict[str, Any],
    score_field: str,
    score_type: str,
) -> dict[str, Any]:
    """Convert one RedisVL result into the stable MCP result shape."""
    score = result.get(score_field)
    if score_field == "score" and "__score" in result:
        score = result["__score"]
    if score is None:
        raise RedisVLMCPError(
            f"Search result missing expected score field '{score_field}'",
            code=MCPErrorCode.INTERNAL_ERROR,
            retryable=False,
        )

    record = dict(result)
    doc_id = record.pop("id", None)
    if doc_id is None:
        doc_id = record.pop("__key", None)
    if doc_id is None:
        doc_id = record.pop("key", None)
    if doc_id is None:
        raise RedisVLMCPError(
            "Search result missing id",
            code=MCPErrorCode.INTERNAL_ERROR,
            retryable=False,
        )

    for field_name in reserved_score_metadata_field_names():
        record.pop(field_name, None)

    return {
        "id": doc_id,
        "score": float(score),
        "score_type": score_type,
        "record": record,
    }


async def _embed_query(vectorizer: Any, query: str) -> Any:
    """Embed the query text, tolerating vectorizers without real async support."""
    aembed = getattr(vectorizer, "aembed", None)
    if callable(aembed):
        try:
            return await aembed(query)
        except NotImplementedError:
            pass
    embed = getattr(vectorizer, "embed")
    if inspect.iscoroutinefunction(embed):
        return await embed(query)
    return await asyncio.to_thread(embed, query)


def _get_configured_search(rt: Any) -> tuple[str, dict[str, Any]]:
    """Return the binding's configured search mode and normalized query params."""
    search_config = rt.binding.search
    return search_config.type, search_config.to_query_params()


def _require_vectorizer(rt: Any) -> Any:
    """Return the binding's vectorizer or fail when it is not configured."""
    if rt.vectorizer is None:
        raise RuntimeError("MCP server vectorizer is not configured")
    return rt.vectorizer


def _build_native_hybrid_kwargs(
    *,
    query: str,
    embedding: Any,
    runtime: Any,
    filter_expression: Any,
    return_fields: list[str],
    num_results: int,
    search_params: dict[str, Any],
) -> dict[str, Any]:
    """Build native `HybridQuery` kwargs from MCP config-owned hybrid params."""
    if runtime.text_field_name is None or runtime.vector_field_name is None:
        raise RuntimeError("Hybrid search requires configured text and vector fields")

    params = dict(search_params)
    combination_method = params.setdefault(
        "combination_method",
        _NATIVE_HYBRID_DEFAULTS["combination_method"],
    )
    if combination_method == "LINEAR":
        linear_text_weight = params.pop(
            "linear_text_weight",
            _NATIVE_HYBRID_DEFAULTS["linear_text_weight"],
        )
        params["linear_alpha"] = linear_text_weight
    else:
        params.pop("linear_text_weight", None)

    return {
        "text": query,
        "text_field_name": runtime.text_field_name,
        "vector": embedding,
        "vector_field_name": runtime.vector_field_name,
        "filter_expression": filter_expression,
        "return_fields": ["__key", *return_fields],
        "num_results": num_results,
        "yield_text_score_as": "text_score",
        "yield_vsim_score_as": "vector_similarity",
        "yield_combined_score_as": "hybrid_score",
        **params,
    }


def _build_fallback_hybrid_kwargs(
    *,
    query: str,
    embedding: Any,
    runtime: Any,
    filter_expression: Any,
    return_fields: list[str],
    num_results: int,
    search_params: dict[str, Any],
) -> dict[str, Any]:
    """Build aggregate fallback kwargs while preserving MCP fusion semantics."""
    if runtime.text_field_name is None or runtime.vector_field_name is None:
        raise RuntimeError("Hybrid search requires configured text and vector fields")

    params = dict(search_params)
    linear_text_weight = params.pop(
        "linear_text_weight",
        _NATIVE_HYBRID_DEFAULTS["linear_text_weight"],
    )
    params.pop("combination_method", None)
    for key in _FALLBACK_HYBRID_UNSUPPORTED_PARAMS:
        params.pop(key, None)
    params["alpha"] = 1 - linear_text_weight

    return {
        "text": query,
        "text_field_name": runtime.text_field_name,
        "vector": embedding,
        "vector_field_name": runtime.vector_field_name,
        "filter_expression": filter_expression,
        "return_fields": ["__key", *return_fields],
        "num_results": num_results,
        **params,
    }


async def _build_query(
    *,
    rt: Any,
    query: str,
    limit: int,
    offset: int,
    filter_value: str | dict[str, Any] | None,
    return_fields: list[str],
) -> tuple[Any, str, str, str]:
    """Build the RedisVL query object from the binding's search mode and params.

    Returns the query instance, the raw score field to read from RedisVL
    results, the public MCP `score_type`, and the configured `search_type`.
    """
    runtime = rt.binding.runtime
    search_type, search_params = _get_configured_search(rt)
    num_results = limit + offset
    filter_expression = parse_filter(filter_value, rt.schema)

    if search_type == "vector":
        if runtime.vector_field_name is None:
            raise RuntimeError("Vector search requires a configured vector field")
        embedding = await _embed_query(_require_vectorizer(rt), query)
        vector_kwargs = {
            "vector": embedding,
            "vector_field_name": runtime.vector_field_name,
            "filter_expression": filter_expression,
            "return_fields": return_fields,
            "num_results": num_results,
            **search_params,
        }
        if "normalize_vector_distance" not in vector_kwargs:
            vector_kwargs["normalize_vector_distance"] = True
        normalize_vector_distance = vector_kwargs["normalize_vector_distance"]
        return (
            VectorQuery(**vector_kwargs),
            "vector_distance",
            (
                "vector_distance_normalized"
                if normalize_vector_distance
                else "vector_distance"
            ),
            search_type,
        )

    if search_type == "fulltext":
        if runtime.text_field_name is None:
            raise RuntimeError("Full-text search requires a configured text field")
        return (
            TextQuery(
                text=query,
                text_field_name=runtime.text_field_name,
                filter_expression=filter_expression,
                return_fields=return_fields,
                num_results=num_results,
                **search_params,
            ),
            "score",
            "text_score",
            search_type,
        )

    embedding = await _embed_query(_require_vectorizer(rt), query)
    if rt.supports_native_hybrid_search:
        native_query = HybridQuery(
            **_build_native_hybrid_kwargs(
                query=query,
                embedding=embedding,
                runtime=runtime,
                filter_expression=filter_expression,
                return_fields=return_fields,
                num_results=num_results,
                search_params=search_params,
            )
        )
        native_query.postprocessing_config.apply(__key="@__key")
        return (
            native_query,
            "hybrid_score",
            "hybrid_score",
            search_type,
        )

    fallback_query = AggregateHybridQuery(
        **_build_fallback_hybrid_kwargs(
            query=query,
            embedding=embedding,
            runtime=runtime,
            filter_expression=filter_expression,
            return_fields=return_fields,
            num_results=num_results,
            search_params=search_params,
        )
    )
    return (
        fallback_query,
        "hybrid_score",
        "hybrid_score",
        search_type,
    )


async def search_records(
    server: Any,
    *,
    query: str,
    index: str | None = None,
    limit: int | None = None,
    offset: int = 0,
    filter: str | dict[str, Any] | None = None,
    return_fields: list[str] | None = None,
) -> dict[str, Any]:
    """Execute `search-records` against the selected Redis index binding.

    ``index`` names the logical binding to query. It is optional when exactly
    one binding is configured (preserving single-index behavior) and required
    when multiple bindings exist. The resolved logical id is echoed back in the
    response so multi-index clients can confirm routing.
    """
    try:
        rt = server.resolve_binding(index)
        effective_limit, effective_return_fields = _validate_request(
            query=query,
            limit=limit,
            offset=offset,
            return_fields=return_fields,
            runtime=rt.binding.runtime,
            schema=rt.schema,
        )
        built_query, score_field, score_type, search_type = await _build_query(
            rt=rt,
            query=query.strip(),
            limit=effective_limit,
            offset=offset,
            filter_value=filter,
            return_fields=effective_return_fields,
        )
        raw_results = await server.run_guarded(
            "search-records",
            rt.index.query(built_query),
            timeout_seconds=rt.binding.runtime.request_timeout_seconds,
        )
        sliced_results = raw_results[offset : offset + effective_limit]
        return {
            "index": rt.binding_id,
            "search_type": search_type,
            "offset": offset,
            "limit": effective_limit,
            "results": [
                _normalize_record(
                    result,
                    score_field,
                    score_type,
                )
                for result in sliced_results
            ],
        }
    except RedisVLMCPError:
        raise
    except Exception as exc:
        raise map_exception(exc) from exc


def register_search_tool(server: Any, schema: IndexSchema | None) -> None:
    """Register the MCP `search-records` tool with its config-owned contract."""
    description = _build_search_tool_description(
        schema=schema,
        base_description=server.mcp_settings.tool_search_description,
    )

    async def search_records_tool(
        query: str,
        index: str | None = None,
        limit: int | None = None,
        offset: int = 0,
        filter: str | dict[str, Any] | None = None,
        return_fields: list[str] | None = None,
    ):
        """FastMCP wrapper for the `search-records` tool."""
        auth_config = getattr(server, "auth_config", None)
        read_scope = auth_config.read_scope if auth_config is not None else None
        ensure_tool_scope(server, read_scope)
        return await search_records(
            server,
            query=query,
            index=index,
            limit=limit,
            offset=offset,
            filter=filter,
            return_fields=return_fields,
        )

    server.tool(name="search-records", description=description)(search_records_tool)
