import asyncio
import inspect
from copy import deepcopy
from typing import Any

from redisvl.mcp.auth import ensure_tool_scope
from redisvl.mcp.errors import MCPErrorCode, RedisVLMCPError, map_exception
from redisvl.redis.utils import array_to_buffer
from redisvl.schema.schema import StorageType
from redisvl.schema.validation import validate_object

DEFAULT_UPSERT_DESCRIPTION = "Upsert records in the configured Redis index."


def _validate_request(
    *,
    runtime: Any,
    records: list[dict[str, Any]],
    id_field: str | None,
    skip_embedding_if_present: bool | None,
) -> bool:
    """Validate the public upsert request contract and resolve defaults."""
    if not isinstance(records, list) or not records:
        raise RedisVLMCPError(
            "records must be a non-empty list",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )
    if len(records) > runtime.max_upsert_records:
        raise RedisVLMCPError(
            "records length must be less than or equal to "
            f"{runtime.max_upsert_records}",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )
    if id_field is not None and (not isinstance(id_field, str) or not id_field):
        raise RedisVLMCPError(
            "id_field must be a non-empty string when provided",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )

    effective_skip_embedding = runtime.skip_embedding_if_present
    if skip_embedding_if_present is not None:
        if not isinstance(skip_embedding_if_present, bool):
            raise RedisVLMCPError(
                "skip_embedding_if_present must be a boolean when provided",
                code=MCPErrorCode.INVALID_REQUEST,
                retryable=False,
            )
        effective_skip_embedding = skip_embedding_if_present

    for record in records:
        if not isinstance(record, dict):
            raise RedisVLMCPError(
                "records must contain only objects",
                code=MCPErrorCode.INVALID_REQUEST,
                retryable=False,
            )
        if id_field is not None and id_field not in record:
            raise RedisVLMCPError(
                "id_field '{id_field}' must exist in every record".format(
                    id_field=id_field
                ),
                code=MCPErrorCode.INVALID_REQUEST,
                retryable=False,
            )

    return effective_skip_embedding


def _record_needs_embedding(
    record: dict[str, Any],
    *,
    vector_field_name: str | None,
    skip_embedding_if_present: bool,
) -> bool:
    """Determine whether a record requires server-side embedding."""
    if vector_field_name is None:
        return False
    return (
        not skip_embedding_if_present
        or vector_field_name not in record
        or record[vector_field_name] is None
    )


def _validate_embed_sources(
    records: list[dict[str, Any]],
    *,
    embed_text_field: str,
    vector_field_name: str,
    skip_embedding_if_present: bool,
) -> list[str]:
    """Collect embed sources for records that require embedding."""
    contents = []
    for record in records:
        if not _record_needs_embedding(
            record,
            vector_field_name=vector_field_name,
            skip_embedding_if_present=skip_embedding_if_present,
        ):
            continue

        content = record.get(embed_text_field)
        if not isinstance(content, str) or not content.strip():
            raise RedisVLMCPError(
                "records requiring embedding must include a non-empty "
                "'{field}' field".format(field=embed_text_field),
                code=MCPErrorCode.INVALID_REQUEST,
                retryable=False,
            )
        contents.append(content)

    return contents


def _validate_supplied_vectors(
    records: list[dict[str, Any]],
    *,
    vector_field_name: str,
    skip_embedding_if_present: bool,
) -> None:
    """Require explicit vectors when embedding support is not configured."""
    missing_vector_count = 0
    for record in records:
        if _record_needs_embedding(
            record,
            vector_field_name=vector_field_name,
            skip_embedding_if_present=skip_embedding_if_present,
        ):
            missing_vector_count += 1

    if missing_vector_count:
        raise RedisVLMCPError(
            "records requiring vector-backed upsert must include a non-empty "
            f"'{vector_field_name}' field when server-side embedding is disabled",
            code=MCPErrorCode.INVALID_REQUEST,
            retryable=False,
        )


async def _embed_one(vectorizer: Any, content: str) -> list[float]:
    """Embed one record, falling back from async to sync implementations."""
    aembed = getattr(vectorizer, "aembed", None)
    if callable(aembed):
        try:
            return await aembed(content)
        except NotImplementedError:
            pass

    embed = getattr(vectorizer, "embed", None)
    if embed is None:
        raise AttributeError("Configured vectorizer does not support embed()")
    if inspect.iscoroutinefunction(embed):
        return await embed(content)
    return await asyncio.to_thread(embed, content)


async def _embed_many(vectorizer: Any, contents: list[str]) -> list[list[float]]:
    """Embed multiple records with batch-first fallbacks."""
    if not contents:
        return []

    aembed_many = getattr(vectorizer, "aembed_many", None)
    if callable(aembed_many):
        try:
            return await aembed_many(contents)
        except NotImplementedError:
            pass

    embed_many = getattr(vectorizer, "embed_many", None)
    if callable(embed_many):
        if inspect.iscoroutinefunction(embed_many):
            return await embed_many(contents)
        return await asyncio.to_thread(embed_many, contents)

    embeddings = []
    for content in contents:
        embeddings.append(await _embed_one(vectorizer, content))
    return embeddings


def _vector_dtype(rt: Any) -> str:
    """Resolve the binding's vector field datatype as a lowercase string."""
    field = rt.binding.get_vector_field(rt.schema)
    datatype = getattr(field.attrs.datatype, "value", field.attrs.datatype)
    return str(datatype).lower()


def _validation_schema_for_record(
    index: Any,
    *,
    vector_field_name: str | None,
    record: dict[str, Any],
) -> Any:
    """Use a JSON-shaped schema when validating list vectors for HASH storage."""
    if (
        vector_field_name is not None
        and index.schema.index.storage_type == StorageType.HASH
        and isinstance(record.get(vector_field_name), list)
    ):
        schema = index.schema.model_copy(deep=True)
        schema.index.storage_type = StorageType.JSON
        return schema
    return index.schema


def _validate_record(
    record: dict[str, Any], *, index: Any, vector_field_name: str | None
) -> None:
    """Validate one record against the schema, allowing HASH list vectors."""
    validate_object(
        _validation_schema_for_record(
            index,
            vector_field_name=vector_field_name,
            record=record,
        ),
        record,
    )


def _prepare_record_for_storage(
    record: dict[str, Any],
    *,
    rt: Any,
) -> dict[str, Any]:
    """Validate records before serializing HASH vectors for storage."""
    prepared = dict(record)
    index = rt.index
    vector_field_name = rt.binding.runtime.vector_field_name
    _validate_record(prepared, index=index, vector_field_name=vector_field_name)

    if vector_field_name is None:
        return prepared

    vector_value = prepared.get(vector_field_name)

    if index.schema.index.storage_type == StorageType.HASH:
        if isinstance(vector_value, list):
            prepared[vector_field_name] = array_to_buffer(
                vector_value,
                _vector_dtype(rt),
            )
    return prepared


async def upsert_records(
    server: Any,
    *,
    records: list[dict[str, Any]],
    index: str | None = None,
    id_field: str | None = None,
    skip_embedding_if_present: bool | None = None,
) -> dict[str, Any]:
    """Execute `upsert-records` against the selected Redis index binding.

    ``index`` names the logical binding to write to. It is optional when exactly
    one binding is configured and required when multiple exist. Writes to a
    read-only binding (whether from global read-only mode or the binding's own
    ``read_only`` policy) are rejected with ``invalid_request``. The resolved
    logical id is echoed back in the response.
    """
    try:
        rt = server.resolve_binding(index)
        if rt.effective_read_only:
            raise RedisVLMCPError(
                f"index '{rt.binding_id}' is read-only",
                code=MCPErrorCode.FORBIDDEN,
                retryable=False,
            )
        index_obj = rt.index
        runtime = rt.binding.runtime
        effective_skip_embedding = _validate_request(
            runtime=runtime,
            records=records,
            id_field=id_field,
            skip_embedding_if_present=skip_embedding_if_present,
        )
        # Copy caller-provided records before enriching them with embeddings or
        # storage-specific serialization so the MCP tool does not mutate inputs.
        prepared_records = [deepcopy(record) for record in records]
        for record in prepared_records:
            _validate_record(
                record,
                index=index_obj,
                vector_field_name=runtime.vector_field_name,
            )
        if rt.binding.supports_server_side_embedding:
            if (
                runtime.default_embed_text_field is None
                or runtime.vector_field_name is None
            ):
                raise RuntimeError(
                    "Server-side embedding requires configured text and vector fields"
                )
            embed_contents = _validate_embed_sources(
                prepared_records,
                embed_text_field=runtime.default_embed_text_field,
                vector_field_name=runtime.vector_field_name,
                skip_embedding_if_present=effective_skip_embedding,
            )

            if embed_contents:
                if rt.vectorizer is None:
                    raise RuntimeError("MCP server vectorizer is not configured")
                vectorizer = rt.vectorizer
                # TODO: Avoid re-embedding records that already include vectors.
                # The current flow can regenerate embeddings for caller-supplied
                # vectors, which is wasteful and can add external service cost.
                embeddings = await _embed_many(vectorizer, embed_contents)
                # Tracks position in the compact embeddings list, which only contains
                # vectors for records that still need server-side embedding.
                embedding_index = 0
                for record in prepared_records:
                    if _record_needs_embedding(
                        record,
                        vector_field_name=runtime.vector_field_name,
                        skip_embedding_if_present=effective_skip_embedding,
                    ):
                        record[runtime.vector_field_name] = embeddings[embedding_index]
                        embedding_index += 1
        elif runtime.vector_field_name is not None:
            if not effective_skip_embedding:
                raise RedisVLMCPError(
                    "skip_embedding_if_present=false requires server-side embedding support",
                    code=MCPErrorCode.INVALID_REQUEST,
                    retryable=False,
                )
            _validate_supplied_vectors(
                prepared_records,
                vector_field_name=runtime.vector_field_name,
                skip_embedding_if_present=effective_skip_embedding,
            )

        loadable_records = [
            _prepare_record_for_storage(record, rt=rt) for record in prepared_records
        ]

        try:
            keys = await server.run_guarded(
                "upsert-records",
                index_obj.load(loadable_records, id_field=id_field),
                timeout_seconds=runtime.request_timeout_seconds,
            )
        except Exception as exc:
            mapped = map_exception(exc)
            mapped.metadata["partial_write_possible"] = True
            raise mapped from exc

        return {
            "index": rt.binding_id,
            "status": "success",
            "keys_upserted": len(keys),
            "keys": keys,
        }
    except RedisVLMCPError:
        raise
    except Exception as exc:
        raise map_exception(exc) from exc


def register_upsert_tool(server: Any) -> None:
    """Register the MCP upsert tool on a server-like object."""
    description = (
        server.mcp_settings.tool_upsert_description or DEFAULT_UPSERT_DESCRIPTION
    )

    async def upsert_records_tool(
        records: list[dict[str, Any]],
        index: str | None = None,
        id_field: str | None = None,
        skip_embedding_if_present: bool | None = None,
    ):
        """FastMCP wrapper for the `upsert-records` tool."""
        auth_config = getattr(server, "auth_config", None)
        write_scope = auth_config.write_scope if auth_config is not None else None
        ensure_tool_scope(server, write_scope)
        return await upsert_records(
            server,
            records=records,
            index=index,
            id_field=id_field,
            skip_embedding_if_present=skip_embedding_if_present,
        )

    server.tool(name="upsert-records", description=description)(upsert_records_tool)
