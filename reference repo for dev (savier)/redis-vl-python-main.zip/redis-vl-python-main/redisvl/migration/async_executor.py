from __future__ import annotations

import asyncio
import hashlib
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncGenerator, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from redisvl.migration.backup import VectorBackup

from redis.asyncio.cluster import RedisCluster as AsyncRedisCluster
from redis.exceptions import ResponseError

from redisvl.index import AsyncSearchIndex
from redisvl.migration.async_planner import AsyncMigrationPlanner
from redisvl.migration.async_validation import AsyncMigrationValidator
from redisvl.migration.executor import (
    _BACKUP_QUANTIZE_PHASES,
    _BACKUP_QUANTIZED_PHASES,
    _checkpoint_identity,
    _checkpoint_identity_matches,
    _delete_backup_prefix,
    _delete_multi_worker_backup_prefix,
    _extract_prefixes_from_info,
    _key_prefix_map,
    _map_key_prefix,
    _map_keys_prefix,
    _require_backup_dir,
    _resolve_backup_path,
)
from redisvl.migration.models import (
    MigrationBackupInfo,
    MigrationBenchmarkSummary,
    MigrationPlan,
    MigrationReport,
    MigrationTimings,
    MigrationValidation,
)
from redisvl.migration.reliability import is_same_width_dtype_conversion
from redisvl.migration.utils import (
    build_scan_match_patterns,
    estimate_disk_space,
    get_schema_field_path,
    normalize_keys,
    timestamp_utc,
)
from redisvl.types import AsyncRedisClient
from redisvl.utils.log import get_logger

logger = get_logger(__name__)


class AsyncMigrationExecutor:
    """Async migration executor for document-preserving drop/recreate flows.

    This is the async version of MigrationExecutor. It uses AsyncSearchIndex
    and async Redis operations for better performance on large indexes,
    especially during vector quantization.
    """

    def __init__(self, validator: Optional[AsyncMigrationValidator] = None):
        self.validator = validator or AsyncMigrationValidator()

    async def _detect_aof_enabled(self, client: Any) -> bool:
        """Best-effort detection of whether AOF is enabled on the live Redis."""
        try:
            info = await client.info("persistence")
            if isinstance(info, dict) and "aof_enabled" in info:
                return bool(int(info["aof_enabled"]))
        except Exception:
            logger.debug("Could not read Redis INFO persistence for AOF detection.")

        try:
            config = await client.config_get("appendonly")
            if isinstance(config, dict):
                value = config.get("appendonly")
                if value is not None:
                    return str(value).lower() in {"yes", "1", "true", "on"}
        except Exception:
            logger.debug("Could not read Redis CONFIG GET appendonly.")

        return False

    async def _enumerate_indexed_keys(
        self,
        client: AsyncRedisClient,
        index_name: str,
        batch_size: int = 1000,
        key_separator: str = ":",
    ) -> AsyncGenerator[str, None]:
        """Async version: Enumerate document keys using FT.AGGREGATE with SCAN fallback.

        Uses FT.AGGREGATE WITHCURSOR for efficient enumeration when the index
        is fully built and has no indexing failures. Falls back to SCAN if:
        - Index has hash_indexing_failures > 0 (would miss failed docs)
        - Index has percent_indexed < 1.0 (background HNSW build still in
          progress; FT.AGGREGATE returns only fully-indexed docs and would
          silently drop the pending tail)
        - FT.AGGREGATE command fails for any reason
        """
        # Check for indexing failures or in-progress indexing — either
        # condition means FT.AGGREGATE would miss documents, so fall
        # back to SCAN for complete enumeration.
        try:
            info = await client.ft(index_name).info()
            failures = int(info.get("hash_indexing_failures", 0) or 0)
            percent_indexed = float(info.get("percent_indexed", 1.0) or 1.0)
            if failures > 0:
                logger.warning(
                    f"Index '{index_name}' has {failures} indexing failures. "
                    "Using SCAN for complete enumeration."
                )
                async for key in self._enumerate_with_scan(
                    client, index_name, batch_size, key_separator
                ):
                    yield key
                return
            if percent_indexed < 1.0:
                logger.warning(
                    f"Index '{index_name}' is still building "
                    f"(percent_indexed={percent_indexed:.4f}). "
                    "Using SCAN for complete enumeration."
                )
                async for key in self._enumerate_with_scan(
                    client, index_name, batch_size, key_separator
                ):
                    yield key
                return
        except Exception as e:
            logger.warning(f"Failed to check index info: {e}. Using SCAN fallback.")
            async for key in self._enumerate_with_scan(
                client, index_name, batch_size, key_separator
            ):
                yield key
            return

        # Try FT.AGGREGATE enumeration
        try:
            async for key in self._enumerate_with_aggregate(
                client, index_name, batch_size
            ):
                yield key
        except ResponseError as e:
            logger.warning(
                f"FT.AGGREGATE failed: {e}. Falling back to SCAN enumeration."
            )
            async for key in self._enumerate_with_scan(
                client, index_name, batch_size, key_separator
            ):
                yield key

    async def _enumerate_with_aggregate(
        self,
        client: AsyncRedisClient,
        index_name: str,
        batch_size: int = 1000,
    ) -> AsyncGenerator[str, None]:
        """Async version: Enumerate keys using FT.AGGREGATE WITHCURSOR.

        Uses MAXIDLE to extend the server-side cursor idle timeout (default
        ~5 min).  If the cursor still expires, the ResponseError propagates
        so the caller can fall back to SCAN.
        """
        cursor_id: Optional[int] = None

        try:
            # Initial aggregate call with LOAD 1 __key
            result = await client.execute_command(
                "FT.AGGREGATE",
                index_name,
                "*",
                "LOAD",
                "1",
                "__key",
                "WITHCURSOR",
                "COUNT",
                str(batch_size),
                "MAXIDLE",
                "300000",
            )

            while True:
                results_data, cursor_id = result

                # Extract keys from results
                for item in results_data[1:]:
                    if isinstance(item, (list, tuple)) and len(item) >= 2:
                        key = item[1]
                        yield key.decode() if isinstance(key, bytes) else str(key)

                if cursor_id == 0:
                    break

                result = await client.execute_command(
                    "FT.CURSOR",
                    "READ",
                    index_name,
                    str(cursor_id),
                    "COUNT",
                    str(batch_size),
                )
        finally:
            if cursor_id and cursor_id != 0:
                try:
                    await client.execute_command(
                        "FT.CURSOR", "DEL", index_name, str(cursor_id)
                    )
                except Exception:
                    pass

    async def _enumerate_with_scan(
        self,
        client: AsyncRedisClient,
        index_name: str,
        batch_size: int = 1000,
        key_separator: str = ":",
    ) -> AsyncGenerator[str, None]:
        """Async version: Enumerate keys using SCAN with prefix matching."""
        # Get prefix from index info
        try:
            info = await client.ft(index_name).info()
            normalized_prefixes = _extract_prefixes_from_info(info)
        except Exception as e:
            logger.warning(f"Failed to get prefix from index info: {e}")
            normalized_prefixes = []

        seen_keys: set[str] = set()
        for match_pattern in build_scan_match_patterns(
            normalized_prefixes, key_separator
        ):
            cursor: int = 0
            while True:
                cursor, keys = await client.scan(
                    cursor=cursor,
                    match=match_pattern,
                    count=batch_size,
                )
                for key in keys:
                    key_str = key.decode() if isinstance(key, bytes) else str(key)
                    if key_str not in seen_keys:
                        seen_keys.add(key_str)
                        yield key_str

                if cursor == 0:
                    break

    async def _rename_keys(
        self,
        client: AsyncRedisClient,
        keys: List[str],
        old_prefix: str,
        new_prefix: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> int:
        """Async version: Rename keys from old prefix to new prefix.

        Uses RENAMENX for standalone Redis.  For Redis Cluster, falls back
        to DUMP/RESTORE/DEL to avoid CROSSSLOT errors.
        """
        is_cluster = isinstance(client, AsyncRedisCluster)
        if is_cluster:
            return await self._rename_keys_cluster(
                client, keys, old_prefix, new_prefix, progress_callback
            )
        return await self._rename_keys_standalone(
            client, keys, old_prefix, new_prefix, progress_callback
        )

    async def _rename_keys_standalone(
        self,
        client: AsyncRedisClient,
        keys: List[str],
        old_prefix: str,
        new_prefix: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> int:
        """Rename keys using pipelined RENAMENX (standalone Redis only)."""
        renamed = 0
        total = len(keys)
        pipeline_size = 100
        collisions: List[str] = []
        successfully_renamed: List[tuple] = []

        for i in range(0, total, pipeline_size):
            batch = keys[i : i + pipeline_size]
            pipe = client.pipeline(transaction=False)
            batch_key_pairs: List[tuple] = []

            for key in batch:
                if key.startswith(old_prefix):
                    new_key = new_prefix + key[len(old_prefix) :]
                else:
                    logger.warning(
                        f"Key '{key}' does not start with prefix '{old_prefix}'"
                    )
                    continue
                pipe.renamenx(key, new_key)
                batch_key_pairs.append((key, new_key))

            try:
                results = await pipe.execute()
                for j, r in enumerate(results):
                    if r is True or r == 1:
                        renamed += 1
                        successfully_renamed.append(batch_key_pairs[j])
                    else:
                        old_key, new_key = batch_key_pairs[j]
                        # If the source is gone and destination exists, this
                        # key was already renamed in a prior (crashed) run —
                        # treat it as a successful no-op for idempotent resume.
                        src_exists = await client.exists(old_key)
                        dst_exists = await client.exists(new_key)
                        if not src_exists and dst_exists:
                            logger.info(
                                "Key '%s' already renamed to '%s' (prior run), skipping",
                                old_key,
                                new_key,
                            )
                            renamed += 1
                            successfully_renamed.append(batch_key_pairs[j])
                        else:
                            collisions.append(new_key)
            except Exception as e:
                logger.warning(f"Error in rename batch: {e}")
                raise

            if collisions:
                raise RuntimeError(
                    f"Prefix rename aborted after {renamed} successful rename(s): "
                    f"{len(collisions)} destination key(s) already exist "
                    f"(first 5: {collisions[:5]}). This would overwrite existing data. "
                    f"Remove conflicting keys or choose a different prefix. "
                    f"Note: {renamed} key(s) were already renamed from "
                    f"'{old_prefix}*' to '{new_prefix}*' and must be reversed "
                    f"manually if you want to retry."
                )

            if progress_callback:
                progress_callback(min(i + pipeline_size, total), total)

        return renamed

    async def _rename_keys_cluster(
        self,
        client: AsyncRedisClient,
        keys: List[str],
        old_prefix: str,
        new_prefix: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> int:
        """Rename keys using batched DUMP/RESTORE/DEL for Redis Cluster.

        RENAME/RENAMENX raises CROSSSLOT errors when source and destination
        hash to different slots.  DUMP/RESTORE works across slots.

        Batches DUMP+PTTL reads and RESTORE+DEL writes in groups of
        ``pipeline_size`` to reduce per-key round-trip overhead.
        """
        renamed = 0
        total = len(keys)
        pipeline_size = 100

        for i in range(0, total, pipeline_size):
            batch = keys[i : i + pipeline_size]

            # Build (key, new_key) pairs for this batch
            pairs = []
            for key in batch:
                if not key.startswith(old_prefix):
                    logger.warning(
                        "Key '%s' does not start with prefix '%s'", key, old_prefix
                    )
                    continue
                new_key = new_prefix + key[len(old_prefix) :]
                pairs.append((key, new_key))

            if not pairs:
                continue

            # Phase 1: Check destination keys don't exist (batched).
            # Also check source keys so we can detect already-renamed keys
            # from a prior crashed run and skip them for idempotent resume.
            check_pipe = client.pipeline(transaction=False)
            for old_key, new_key in pairs:
                check_pipe.exists(new_key)
                check_pipe.exists(old_key)
            check_results = await check_pipe.execute()

            live_pairs = []
            for idx, (old_key, new_key) in enumerate(pairs):
                dst_exists = check_results[idx * 2]
                src_exists = check_results[idx * 2 + 1]
                if dst_exists:
                    if not src_exists:
                        # Already renamed in a prior run — count and skip.
                        logger.info(
                            "Key '%s' already renamed to '%s' (prior run), skipping",
                            old_key,
                            new_key,
                        )
                        renamed += 1
                    else:
                        raise RuntimeError(
                            f"Prefix rename aborted after {renamed} successful rename(s): "
                            f"destination key '{new_key}' already exists. "
                            f"Remove conflicting keys or choose a different prefix."
                        )
                else:
                    if not src_exists:
                        logger.warning(
                            "Key '%s' does not exist and destination '%s' is also missing, skipping",
                            old_key,
                            new_key,
                        )
                    else:
                        live_pairs.append((old_key, new_key))
            pairs = live_pairs

            # Phase 2: DUMP + PTTL all source keys (batched — 1 RTT)
            dump_pipe = client.pipeline(transaction=False)
            for key, _ in pairs:
                dump_pipe.dump(key)
                dump_pipe.pttl(key)
            dump_results = await dump_pipe.execute()

            # Phase 3: RESTORE + DEL (batched — 1 RTT)
            restore_pipe = client.pipeline(transaction=False)
            valid_pairs = []
            for idx, (key, new_key) in enumerate(pairs):
                dumped = dump_results[idx * 2]
                ttl = dump_results[idx * 2 + 1]
                if dumped is None:
                    logger.warning("Key '%s' does not exist, skipping", key)
                    continue
                restore_ttl = max(ttl, 0)
                restore_pipe.restore(new_key, restore_ttl, dumped, replace=False)
                restore_pipe.delete(key)
                valid_pairs.append((key, new_key))

            if valid_pairs:
                await restore_pipe.execute()
                renamed += len(valid_pairs)

            if progress_callback:
                progress_callback(min(i + pipeline_size, total), total)

        if progress_callback:
            progress_callback(total, total)

        return renamed

    async def _rename_field_in_hash(
        self,
        client: AsyncRedisClient,
        keys: List[str],
        old_name: str,
        new_name: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> int:
        """Async version: Rename a field in hash documents."""
        renamed = 0
        total = len(keys)
        pipeline_size = 100

        for i in range(0, total, pipeline_size):
            batch = keys[i : i + pipeline_size]

            # Get old field values AND check if destination exists
            pipe = client.pipeline(transaction=False)
            for key in batch:
                pipe.hget(key, old_name)
                pipe.hexists(key, new_name)
            raw_results = await pipe.execute()
            # Interleaved: [hget_0, hexists_0, hget_1, hexists_1, ...]
            values = raw_results[0::2]
            dest_exists = raw_results[1::2]

            pipe = client.pipeline(transaction=False)
            batch_ops = 0
            for key, value, exists in zip(batch, values, dest_exists):
                if value is not None:
                    if exists:
                        logger.warning(
                            "Field '%s' already exists in key '%s'; "
                            "overwriting with value from '%s'",
                            new_name,
                            key,
                            old_name,
                        )
                    pipe.hset(key, new_name, value)
                    pipe.hdel(key, old_name)
                    batch_ops += 1

            try:
                await pipe.execute()
                # Count by number of keys that had old field values,
                # not by HSET return (HSET returns 0 for existing field updates)
                renamed += batch_ops
            except Exception as e:
                logger.warning(f"Error in field rename batch: {e}")
                raise

            if progress_callback:
                progress_callback(min(i + pipeline_size, total), total)

        return renamed

    async def _rename_field_in_json(
        self,
        client: AsyncRedisClient,
        keys: List[str],
        old_path: str,
        new_path: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> int:
        """Async version: Rename a field in JSON documents."""
        renamed = 0
        total = len(keys)
        pipeline_size = 100

        for i in range(0, total, pipeline_size):
            batch = keys[i : i + pipeline_size]

            pipe = client.pipeline(transaction=False)
            for key in batch:
                pipe.json().get(key, old_path)
            values = await pipe.execute()

            # JSONPath GET returns results as a list; unwrap single-element
            # results to preserve the original document shape.
            # Missing paths return None or [] depending on Redis version.
            pipe = client.pipeline(transaction=False)
            batch_ops = 0
            for key, value in zip(batch, values):
                if value is None or value == []:
                    continue
                if isinstance(value, list) and len(value) == 1:
                    value = value[0]
                pipe.json().set(key, new_path, value)
                pipe.json().delete(key, old_path)
                batch_ops += 1
            try:
                await pipe.execute()
                # Count by number of keys that had old field values,
                # not by JSON.SET return value
                renamed += batch_ops
            except Exception as e:
                logger.warning(f"Error in JSON field rename batch: {e}")
                raise

            if progress_callback:
                progress_callback(min(i + pipeline_size, total), total)

        return renamed

    async def apply(
        self,
        plan: MigrationPlan,
        *,
        redis_url: Optional[str] = None,
        redis_client: Optional[AsyncRedisClient] = None,
        query_check_file: Optional[str] = None,
        progress_callback: Optional[Callable[[str, Optional[str]], None]] = None,
        backup_dir: Optional[str] = None,
        batch_size: int = 500,
        num_workers: int = 1,
    ) -> MigrationReport:
        """Apply a migration plan asynchronously.

        Async counterpart of :meth:`MigrationExecutor.apply`. Uses
        ``await`` for Redis I/O so the event loop remains responsive during
        large quantization jobs. Multi-worker quantization uses
        ``asyncio.gather`` with independent connections.

        Args:
            plan: The migration plan to apply (from
                ``AsyncMigrationPlanner.create_plan``).
            redis_url: Redis connection URL (e.g.
                ``"redis://localhost:6379"``). Required when
                *num_workers* > 1.
            redis_client: Optional existing async Redis client.
            query_check_file: Optional YAML file with post-migration queries.
            progress_callback: Optional ``callback(step, detail)``.
            backup_dir: Required directory for vector backup files. Enables
                crash-safe resume and rollback.
                Disk usage ≈ ``num_docs × dims × bytes_per_element``.
            batch_size: Keys per pipeline batch (default 500). Values
                between 200 and 1000 are typical.
            num_workers: Parallel quantization workers (default 1). For
                low-dimensional vectors (≤ 256 dims) a single worker is
                often fastest. Diminishing returns above 4–8 workers.
        """
        started_at = timestamp_utc()
        started = time.perf_counter()

        report = MigrationReport(
            source_index=plan.source.index_name,
            target_index=plan.merged_target_schema["index"]["name"],
            result="failed",
            started_at=started_at,
            finished_at=started_at,
            warnings=list(plan.warnings),
        )

        backup_dir = _require_backup_dir(backup_dir)
        backup_path = _resolve_backup_path(backup_dir, plan.source.index_name)
        report.backup = MigrationBackupInfo(backup_dir=backup_dir)

        if not plan.diff_classification.supported:
            report.validation.errors.extend(plan.diff_classification.blocked_reasons)
            report.manual_actions.append(
                "This change requires document migration, which is not yet supported."
            )
            report.finished_at = timestamp_utc()
            return report

        if batch_size < 1:
            report.validation.errors.append(
                f"batch_size must be >= 1, got {batch_size}."
            )
            report.finished_at = timestamp_utc()
            return report

        if num_workers < 1:
            report.validation.errors.append(
                f"num_workers must be >= 1, got {num_workers}."
            )
            report.finished_at = timestamp_utc()
            return report

        if num_workers > 1 and redis_url is None:
            report.validation.errors.append(
                "redis_url is required when using num_workers > 1. "
                "Pass redis_url so each worker can open its own Redis connection."
            )
            report.finished_at = timestamp_utc()
            return report

        datatype_changes = AsyncMigrationPlanner.get_vector_datatype_changes(
            plan.source.schema_snapshot,
            plan.merged_target_schema,
            rename_operations=plan.rename_operations,
        )
        checkpoint_identity = _checkpoint_identity(plan, datatype_changes)

        from redisvl.migration.backup import MultiWorkerBackupManifest, VectorBackup

        resuming_from_backup = False
        resuming_from_manifest = False
        existing_backup: Optional[VectorBackup] = VectorBackup.load(backup_path)
        existing_manifest: Optional[MultiWorkerBackupManifest] = (
            MultiWorkerBackupManifest.load(backup_path)
        )

        source_matches_snapshot = await self._async_current_source_matches_snapshot(
            plan.source.index_name,
            plan.source.schema_snapshot,
            redis_url=redis_url,
            redis_client=redis_client,
        )
        target_matches_snapshot = await self._async_current_source_matches_snapshot(
            plan.merged_target_schema["index"]["name"],
            plan.merged_target_schema,
            redis_url=redis_url,
            redis_client=redis_client,
            strip_excluded=True,
        )

        if existing_backup is not None:
            if existing_backup.header.index_name != plan.source.index_name:
                existing_backup = None
            elif not _checkpoint_identity_matches(
                existing_backup.header, checkpoint_identity
            ):
                if source_matches_snapshot:
                    _delete_backup_prefix(backup_path)
                    existing_backup = None
                else:
                    report.validation.errors.append(
                        "Existing vector backup does not match this migration plan."
                    )
                    report.manual_actions.append(
                        "Resume with the original migration plan for this backup, "
                        "or restore the source index before starting a new plan."
                    )
                    report.finished_at = timestamp_utc()
                    return report
            elif existing_backup.header.phase == "dump":
                if source_matches_snapshot:
                    _delete_backup_prefix(backup_path)
                    existing_backup = None
                else:
                    report.validation.errors.append(
                        "Found an incomplete vector backup, but the live source "
                        "index no longer matches the migration plan."
                    )
                    report.manual_actions.append(
                        "Restore the source index or restore vectors from a complete "
                        "backup before retrying."
                    )
                    report.finished_at = timestamp_utc()
                    return report
            elif existing_backup.header.phase in _BACKUP_QUANTIZE_PHASES:
                resuming_from_backup = True
            elif existing_backup.header.phase in _BACKUP_QUANTIZED_PHASES:
                if source_matches_snapshot and not target_matches_snapshot:
                    _delete_backup_prefix(backup_path)
                    existing_backup = None
                else:
                    resuming_from_backup = True

        if existing_backup is None and existing_manifest is not None:
            if existing_manifest.index_name != plan.source.index_name:
                existing_manifest = None
            elif not _checkpoint_identity_matches(
                existing_manifest, checkpoint_identity
            ):
                if source_matches_snapshot:
                    _delete_multi_worker_backup_prefix(
                        backup_path, existing_manifest.worker_backup_paths
                    )
                    existing_manifest = None
                else:
                    report.validation.errors.append(
                        "Existing multi-worker backup manifest does not match this "
                        "migration plan."
                    )
                    report.manual_actions.append(
                        "Resume with the original migration plan for this manifest, "
                        "or restore the source index before starting a new plan."
                    )
                    report.finished_at = timestamp_utc()
                    return report
            elif existing_manifest.phase in (
                "quantized",
                "target_created",
                "validated",
            ):
                if source_matches_snapshot and not target_matches_snapshot:
                    _delete_multi_worker_backup_prefix(
                        backup_path, existing_manifest.worker_backup_paths
                    )
                    existing_manifest = None
                else:
                    resuming_from_manifest = True
            elif existing_manifest.phase in (
                "prepared",
                "index_dropped",
                "keys_renamed",
                "quantizing",
            ):
                resuming_from_manifest = True

        if (
            resuming_from_manifest
            and existing_manifest is not None
            and existing_manifest.phase
            not in ("quantized", "target_created", "validated")
            and existing_manifest.requested_workers > 1
            and redis_url is None
        ):
            report.validation.errors.append(
                "redis_url is required to resume a multi-worker migration manifest. "
                "Pass redis_url so each worker can open its own Redis connection."
            )
            report.finished_at = timestamp_utc()
            return report

        resuming = resuming_from_backup or resuming_from_manifest

        if not resuming:
            if not source_matches_snapshot:
                report.validation.errors.append(
                    "The current live source schema no longer matches the saved source snapshot."
                )
                report.manual_actions.append(
                    "Re-run `rvl migrate plan` to refresh the migration plan before applying."
                )
                report.finished_at = timestamp_utc()
                return report

            source_index = await AsyncSearchIndex.from_existing(
                plan.source.index_name,
                redis_url=redis_url,
                redis_client=redis_client,
            )
        elif source_matches_snapshot:
            source_index = await AsyncSearchIndex.from_existing(
                plan.source.index_name,
                redis_url=redis_url,
                redis_client=redis_client,
            )
        else:
            source_index = AsyncSearchIndex.from_dict(
                plan.source.schema_snapshot,
                redis_url=redis_url,
                redis_client=redis_client,
            )

        target_index = AsyncSearchIndex.from_dict(
            plan.merged_target_schema,
            redis_url=redis_url,
            redis_client=redis_client,
        )

        enumerate_duration = 0.0
        drop_duration = 0.0
        quantize_duration = 0.0
        field_rename_duration = 0.0
        key_rename_duration = 0.0
        recreate_duration = 0.0
        indexing_duration = 0.0
        target_info: Dict[str, Any] = {}
        docs_quantized = 0
        keys_to_process: List[str] = []
        expected_source_count: Optional[int] = None
        storage_type = plan.source.keyspace.storage_type

        # Check for rename operations
        rename_ops = plan.rename_operations
        has_prefix_change = rename_ops.change_prefix is not None
        has_field_renames = bool(rename_ops.rename_fields)
        needs_quantization = bool(datatype_changes) and storage_type != "json"
        source_failures = int(
            plan.source.stats_snapshot.get("hash_indexing_failures", 0) or 0
        )
        source_percent_indexed = float(
            plan.source.stats_snapshot.get("percent_indexed", 1.0) or 1.0
        )
        needs_exact_count = source_failures > 0 or source_percent_indexed < 1.0
        needs_enumeration = (
            needs_quantization
            or has_prefix_change
            or has_field_renames
            or needs_exact_count
        )
        has_same_width_quantization = any(
            is_same_width_dtype_conversion(change["source"], change["target"])
            for change in datatype_changes.values()
        )
        if needs_quantization and has_same_width_quantization:
            report.validation.errors.append(
                "Crash-safe resume is not supported for same-width datatype "
                "changes (float16<->bfloat16 or int8<->uint8)."
            )
            report.manual_actions.append(
                "Split the migration to avoid same-width datatype changes."
            )
            report.finished_at = timestamp_utc()
            return report

        def _notify(step: str, detail: Optional[str] = None) -> None:
            if progress_callback:
                progress_callback(step, detail)

        key_prefix = (
            _key_prefix_map(plan.source.keyspace.prefixes[0], rename_ops.change_prefix)
            if has_prefix_change
            else None
        )
        key_transform = (
            (lambda key: _map_key_prefix(key, key_prefix))
            if key_prefix is not None
            else None
        )

        try:
            client = await source_index._get_client()
            if client is None:
                raise ValueError("Failed to get Redis client from source index")
            aof_enabled = await self._detect_aof_enabled(client)
            disk_estimate = estimate_disk_space(plan, aof_enabled=aof_enabled)
            if disk_estimate.has_quantization:
                logger.info(
                    "Disk space estimate: RDB ~%d bytes, AOF ~%d bytes, total ~%d bytes",
                    disk_estimate.rdb_snapshot_disk_bytes,
                    disk_estimate.aof_growth_bytes,
                    disk_estimate.total_new_disk_bytes,
                )
            report.disk_space_estimate = disk_estimate
            active_backup = None
            active_manifest = None

            if resuming_from_backup and existing_backup is not None:
                _notify("enumerate", "skipped (resume from backup)")
                expected_source_count = sum(
                    len(batch_keys) for batch_keys, _ in existing_backup.iter_batches()
                )
                if report.backup is not None:
                    report.backup.backup_paths = [backup_path]

                if (
                    existing_backup.header.phase in _BACKUP_QUANTIZE_PHASES
                    and source_matches_snapshot
                ):
                    _notify("drop", "Dropping index definition (resume)...")
                    drop_started = time.perf_counter()
                    await source_index.delete(drop=False)
                    drop_duration = round(time.perf_counter() - drop_started, 3)
                    existing_backup.mark_index_dropped()
                    source_matches_snapshot = False
                    _notify("drop", f"done ({drop_duration}s)")
                else:
                    _notify("drop", "skipped (already dropped)")

                if (
                    has_prefix_change
                    and existing_backup.header.phase in _BACKUP_QUANTIZE_PHASES
                ):
                    resume_keys = []
                    for batch_keys, _ in existing_backup.iter_batches():
                        resume_keys.extend(batch_keys)
                    if resume_keys:
                        old_prefix = plan.source.keyspace.prefixes[0]
                        new_prefix = rename_ops.change_prefix
                        assert new_prefix is not None
                        _notify("key_rename", "Renaming keys (resume)...")
                        key_rename_started = time.perf_counter()
                        renamed_count = await self._rename_keys(
                            client,
                            resume_keys,
                            old_prefix,
                            new_prefix,
                            progress_callback=lambda done, total: _notify(
                                "key_rename", f"{done:,}/{total:,} keys"
                            ),
                        )
                        key_rename_duration = round(
                            time.perf_counter() - key_rename_started, 3
                        )
                        _notify(
                            "key_rename",
                            f"done ({renamed_count:,} keys in {key_rename_duration}s)",
                        )

                if existing_backup.header.phase in _BACKUP_QUANTIZED_PHASES:
                    _notify("quantize", "skipped (already completed)")
                elif existing_backup.header.phase in _BACKUP_QUANTIZE_PHASES:
                    effective_changes = datatype_changes
                    if has_field_renames:
                        field_rename_map = {
                            fr.old_name: fr.new_name for fr in rename_ops.rename_fields
                        }
                        effective_changes = {
                            field_rename_map.get(k, k): v
                            for k, v in datatype_changes.items()
                        }
                    _notify("quantize", "Resuming vector re-encoding from backup...")
                    quantize_started = time.perf_counter()
                    docs_quantized = await self._quantize_from_backup(
                        client=client,
                        backup=existing_backup,
                        datatype_changes=effective_changes,
                        key_transform=key_transform,
                        progress_callback=lambda done, total: _notify(
                            "quantize", f"{done:,}/{total:,} docs"
                        ),
                    )
                    quantize_duration = round(time.perf_counter() - quantize_started, 3)
                    _notify(
                        "quantize",
                        f"done ({docs_quantized:,} docs in {quantize_duration}s)",
                    )
            elif resuming_from_manifest and existing_manifest is not None:
                _notify("enumerate", "skipped (resume from multi-worker manifest)")
                expected_source_count = len(existing_manifest.keys)

                if existing_manifest.phase == "prepared" and source_matches_snapshot:
                    _notify("drop", "Dropping index definition (resume)...")
                    drop_started = time.perf_counter()
                    await source_index.delete(drop=False)
                    drop_duration = round(time.perf_counter() - drop_started, 3)
                    existing_manifest.mark_index_dropped()
                    source_matches_snapshot = False
                    _notify("drop", f"done ({drop_duration}s)")
                elif existing_manifest.phase == "prepared":
                    existing_manifest.mark_index_dropped()
                    _notify("drop", "skipped (already dropped)")
                else:
                    _notify("drop", "skipped (already dropped)")

                if (
                    has_prefix_change
                    and existing_manifest.phase == "index_dropped"
                    and existing_manifest.keys
                ):
                    old_prefix = plan.source.keyspace.prefixes[0]
                    new_prefix = rename_ops.change_prefix
                    assert new_prefix is not None
                    _notify("key_rename", "Renaming keys (resume)...")
                    key_rename_started = time.perf_counter()
                    renamed_count = await self._rename_keys(
                        client,
                        existing_manifest.keys,
                        old_prefix,
                        new_prefix,
                        progress_callback=lambda done, total: _notify(
                            "key_rename", f"{done:,}/{total:,} keys"
                        ),
                    )
                    key_rename_duration = round(
                        time.perf_counter() - key_rename_started, 3
                    )
                    remapped_keys = _map_keys_prefix(existing_manifest.keys, key_prefix)
                    from redisvl.migration.quantize import split_keys

                    existing_manifest.update_key_slices(
                        split_keys(remapped_keys, existing_manifest.requested_workers)
                    )
                    existing_manifest.mark_keys_renamed()
                    _notify(
                        "key_rename",
                        f"done ({renamed_count:,} keys in {key_rename_duration}s)",
                    )

                if existing_manifest.phase in (
                    "quantized",
                    "target_created",
                    "validated",
                ):
                    _notify("quantize", "skipped (already completed)")
                    if report.backup is not None:
                        report.backup.backup_paths = (
                            existing_manifest.worker_backup_paths
                        )
                else:
                    from redisvl.migration.quantize import async_multi_worker_quantize

                    _notify(
                        "quantize",
                        f"Re-encoding vectors ({existing_manifest.actual_workers} workers)...",
                    )
                    existing_manifest.mark_quantizing()
                    quantize_started = time.perf_counter()
                    mw_result = await async_multi_worker_quantize(
                        redis_url=redis_url or "",
                        keys=existing_manifest.keys,
                        datatype_changes=datatype_changes,
                        backup_dir=backup_dir,
                        index_name=plan.source.index_name,
                        num_workers=existing_manifest.requested_workers,
                        batch_size=existing_manifest.batch_size,
                        worker_backup_paths=existing_manifest.worker_backup_paths,
                    )
                    docs_quantized = mw_result.total_docs_quantized
                    existing_manifest.mark_quantized()
                    if report.backup is not None:
                        report.backup.backup_paths = mw_result.backup_paths
                    quantize_duration = round(time.perf_counter() - quantize_started, 3)
                    _notify(
                        "quantize",
                        f"done ({docs_quantized:,} docs in {quantize_duration}s)",
                    )
            else:
                # Normal (non-resume) path
                if needs_enumeration:
                    _notify("enumerate", "Enumerating indexed documents...")
                    enumerate_started = time.perf_counter()
                    keys_to_process = [
                        key
                        async for key in self._enumerate_indexed_keys(
                            client,
                            plan.source.index_name,
                            batch_size=1000,
                            key_separator=plan.source.keyspace.key_separator,
                        )
                    ]
                    keys_to_process = normalize_keys(keys_to_process)
                    expected_source_count = len(keys_to_process)
                    enumerate_duration = round(
                        time.perf_counter() - enumerate_started, 3
                    )
                    _notify(
                        "enumerate",
                        f"found {len(keys_to_process):,} documents ({enumerate_duration}s)",
                    )

                # Field renames
                if has_field_renames and keys_to_process:
                    _notify("field_rename", "Renaming fields in documents...")
                    field_rename_started = time.perf_counter()
                    for field_rename in rename_ops.rename_fields:
                        if storage_type == "json":
                            old_path = get_schema_field_path(
                                plan.source.schema_snapshot, field_rename.old_name
                            )
                            new_path = get_schema_field_path(
                                plan.merged_target_schema, field_rename.new_name
                            )
                            if not old_path or not new_path or old_path == new_path:
                                continue
                            await self._rename_field_in_json(
                                client,
                                keys_to_process,
                                old_path,
                                new_path,
                                progress_callback=lambda done, total: _notify(
                                    "field_rename",
                                    f"{field_rename.old_name} -> {field_rename.new_name}: {done:,}/{total:,}",
                                ),
                            )
                        else:
                            await self._rename_field_in_hash(
                                client,
                                keys_to_process,
                                field_rename.old_name,
                                field_rename.new_name,
                                progress_callback=lambda done, total: _notify(
                                    "field_rename",
                                    f"{field_rename.old_name} -> {field_rename.new_name}: {done:,}/{total:,}",
                                ),
                            )
                    field_rename_duration = round(
                        time.perf_counter() - field_rename_started, 3
                    )
                    _notify("field_rename", f"done ({field_rename_duration}s)")

                # Dump original vectors to backup file (before drop)
                use_multi_worker = num_workers > 1
                if (
                    needs_quantization
                    and keys_to_process
                    and backup_path
                    and not use_multi_worker
                ):
                    effective_changes = datatype_changes
                    if has_field_renames:
                        field_rename_map = {
                            fr.old_name: fr.new_name for fr in rename_ops.rename_fields
                        }
                        effective_changes = {
                            field_rename_map.get(k, k): v
                            for k, v in datatype_changes.items()
                        }
                    _notify("dump", "Backing up original vectors...")
                    dump_started = time.perf_counter()
                    active_backup = await self._dump_vectors(
                        client=client,
                        index_name=plan.source.index_name,
                        keys=keys_to_process,
                        datatype_changes=effective_changes,
                        backup_path=backup_path,
                        batch_size=batch_size,
                        key_prefix=key_prefix,
                        checkpoint_identity=checkpoint_identity,
                        progress_callback=lambda done, total: _notify(
                            "dump", f"{done:,}/{total:,} docs"
                        ),
                    )
                    if report.backup is not None:
                        report.backup.backup_paths = [backup_path]
                    dump_duration = round(time.perf_counter() - dump_started, 3)
                    _notify("dump", f"done ({dump_duration}s)")
                elif needs_quantization and keys_to_process and use_multi_worker:
                    from redisvl.migration.backup import MultiWorkerBackupManifest
                    from redisvl.migration.quantize import (
                        build_worker_backup_paths,
                        split_keys,
                    )

                    manifest_key_slices = split_keys(keys_to_process, num_workers)
                    worker_backup_paths = build_worker_backup_paths(
                        backup_dir, plan.source.index_name, len(manifest_key_slices)
                    )
                    active_manifest = MultiWorkerBackupManifest.create(
                        backup_path,
                        index_name=plan.source.index_name,
                        batch_size=batch_size,
                        requested_workers=num_workers,
                        key_slices=manifest_key_slices,
                        worker_backup_paths=worker_backup_paths,
                        key_prefix=key_prefix,
                        **checkpoint_identity,
                    )

                # Drop the index
                _notify("drop", "Dropping index definition...")
                drop_started = time.perf_counter()
                await source_index.delete(drop=False)
                drop_duration = round(time.perf_counter() - drop_started, 3)
                if active_backup is not None:
                    active_backup.mark_index_dropped()
                if active_manifest is not None:
                    active_manifest.mark_index_dropped()
                _notify("drop", f"done ({drop_duration}s)")

                # Key renames
                if has_prefix_change and keys_to_process:
                    _notify("key_rename", "Renaming keys...")
                    key_rename_started = time.perf_counter()
                    old_prefix = plan.source.keyspace.prefixes[0]
                    new_prefix = rename_ops.change_prefix
                    assert new_prefix is not None
                    renamed_count = await self._rename_keys(
                        client,
                        keys_to_process,
                        old_prefix,
                        new_prefix,
                        progress_callback=lambda done, total: _notify(
                            "key_rename", f"{done:,}/{total:,} keys"
                        ),
                    )
                    key_rename_duration = round(
                        time.perf_counter() - key_rename_started, 3
                    )
                    _notify(
                        "key_rename",
                        f"done ({renamed_count:,} keys in {key_rename_duration}s)",
                    )
                    if active_manifest is not None:
                        from redisvl.migration.quantize import split_keys

                        remapped_keys = _map_keys_prefix(keys_to_process, key_prefix)
                        active_manifest.update_key_slices(
                            split_keys(remapped_keys, num_workers)
                        )
                        active_manifest.mark_keys_renamed()

                # Quantize vectors
                if needs_quantization and keys_to_process:
                    effective_changes = datatype_changes
                    if has_field_renames:
                        field_rename_map = {
                            fr.old_name: fr.new_name for fr in rename_ops.rename_fields
                        }
                        effective_changes = {
                            field_rename_map.get(k, k): v
                            for k, v in datatype_changes.items()
                        }

                    # Update key references if prefix changed
                    if has_prefix_change and rename_ops.change_prefix:
                        keys_to_process = _map_keys_prefix(keys_to_process, key_prefix)

                    if use_multi_worker:
                        from redisvl.migration.quantize import (
                            async_multi_worker_quantize,
                        )

                        _notify(
                            "quantize",
                            f"Re-encoding vectors ({num_workers} workers)...",
                        )
                        if active_manifest is not None:
                            active_manifest.mark_quantizing()
                        quantize_started = time.perf_counter()
                        mw_result = await async_multi_worker_quantize(
                            redis_url=redis_url or "",
                            keys=keys_to_process,
                            datatype_changes=effective_changes,
                            backup_dir=backup_dir,
                            index_name=plan.source.index_name,
                            num_workers=num_workers,
                            batch_size=batch_size,
                            worker_backup_paths=(
                                active_manifest.worker_backup_paths
                                if active_manifest is not None
                                else None
                            ),
                        )
                        docs_quantized = mw_result.total_docs_quantized
                        if active_manifest is not None:
                            active_manifest.mark_quantized()
                        if report.backup is not None:
                            report.backup.backup_paths = mw_result.backup_paths
                    elif active_backup:
                        _notify("quantize", "Re-encoding vectors from backup...")
                        quantize_started = time.perf_counter()
                        docs_quantized = await self._quantize_from_backup(
                            client=client,
                            backup=active_backup,
                            datatype_changes=effective_changes,
                            key_transform=key_transform,
                            progress_callback=lambda done, total: _notify(
                                "quantize", f"{done:,}/{total:,} docs"
                            ),
                        )
                    else:
                        # Fallback direct pipeline path; normal hash
                        # quantization uses the backup path above.
                        from redisvl.migration.quantize import convert_vectors

                        _notify("quantize", "Re-encoding vectors...")
                        quantize_started = time.perf_counter()
                        docs_quantized = 0
                        total = len(keys_to_process)
                        field_names = list(effective_changes.keys())
                        for batch_start in range(0, total, batch_size):
                            batch_keys = keys_to_process[
                                batch_start : batch_start + batch_size
                            ]
                            # Async pipelined read
                            pipe = client.pipeline(transaction=False)
                            call_order: list[tuple] = []
                            for key in batch_keys:
                                for fn in field_names:
                                    pipe.hget(key, fn)
                                    call_order.append((key, fn))
                            results = await pipe.execute()
                            originals: dict[str, dict[str, bytes]] = {}
                            for (key, fn), value in zip(call_order, results):
                                if value is not None:
                                    originals.setdefault(key, {})[fn] = value
                            converted = convert_vectors(originals, effective_changes)
                            if converted:
                                wpipe = client.pipeline(transaction=False)
                                for key, fields in converted.items():
                                    for fn, data in fields.items():
                                        wpipe.hset(key, fn, data)
                                await wpipe.execute()
                            docs_quantized += len(converted) if converted else 0
                            if progress_callback:
                                _notify(
                                    "quantize",
                                    f"{docs_quantized:,}/{total:,} docs",
                                )
                    quantize_duration = round(time.perf_counter() - quantize_started, 3)
                    _notify(
                        "quantize",
                        f"done ({docs_quantized:,} docs in {quantize_duration}s)",
                    )
                    report.warnings.append(
                        f"Re-encoded {docs_quantized} documents for vector quantization: "
                        f"{datatype_changes}"
                    )
                elif datatype_changes and storage_type == "json":
                    _notify(
                        "quantize", "skipped (JSON vectors are re-indexed on recreate)"
                    )

            backup_checkpoint = existing_backup or active_backup
            manifest_checkpoint = existing_manifest or active_manifest
            target_already_live = target_matches_snapshot and (
                (
                    backup_checkpoint is not None
                    and backup_checkpoint.header.phase in _BACKUP_QUANTIZED_PHASES
                )
                or (
                    manifest_checkpoint is not None
                    and manifest_checkpoint.phase
                    in ("quantized", "target_created", "validated")
                )
            )

            if target_already_live:
                _notify("create", "skipped (target schema already live)")
                _notify("index", "skipped (target schema already live)")
            else:
                _notify("create", "Creating index with new schema...")
                recreate_started = time.perf_counter()
                await target_index.create()
                recreate_duration = round(time.perf_counter() - recreate_started, 3)
                if (
                    backup_checkpoint is not None
                    and backup_checkpoint.header.phase == "completed"
                ):
                    backup_checkpoint.mark_target_created()
                if (
                    manifest_checkpoint is not None
                    and manifest_checkpoint.phase == "quantized"
                ):
                    manifest_checkpoint.mark_target_created()
                _notify("create", f"done ({recreate_duration}s)")

                _notify("index", "Waiting for re-indexing...")

                def _index_progress(indexed: int, total: int, pct: float) -> None:
                    _notify("index", f"{indexed:,}/{total:,} docs ({pct:.0f}%)")

                target_info, indexing_duration = await self._async_wait_for_index_ready(
                    target_index, progress_callback=_index_progress
                )
                _notify("index", f"done ({indexing_duration}s)")

            _notify("validate", "Validating migration...")
            (
                validation,
                target_info,
                validation_duration,
            ) = await self.validator.validate(
                plan,
                redis_url=redis_url,
                redis_client=redis_client,
                query_check_file=query_check_file,
                expected_source_count=expected_source_count,
            )
            _notify("validate", f"done ({validation_duration}s)")
            report.validation = validation
            if not validation.errors:
                if (
                    backup_checkpoint is not None
                    and backup_checkpoint.header.phase
                    in (
                        "completed",
                        "target_created",
                    )
                ):
                    backup_checkpoint.mark_validated()
                if manifest_checkpoint is not None and manifest_checkpoint.phase in (
                    "quantized",
                    "target_created",
                ):
                    manifest_checkpoint.mark_validated()
            total_duration = round(time.perf_counter() - started, 3)
            report.timings = MigrationTimings(
                total_migration_duration_seconds=total_duration,
                drop_duration_seconds=drop_duration,
                quantize_duration_seconds=(
                    quantize_duration if quantize_duration else None
                ),
                field_rename_duration_seconds=(
                    field_rename_duration if field_rename_duration else None
                ),
                key_rename_duration_seconds=(
                    key_rename_duration if key_rename_duration else None
                ),
                recreate_duration_seconds=recreate_duration,
                initial_indexing_duration_seconds=indexing_duration,
                validation_duration_seconds=validation_duration,
                downtime_duration_seconds=round(
                    drop_duration
                    + field_rename_duration
                    + key_rename_duration
                    + quantize_duration
                    + recreate_duration
                    + indexing_duration,
                    3,
                ),
            )
            report.benchmark_summary = self._build_benchmark_summary(
                plan,
                target_info,
                report.timings,
            )
            report.result = "succeeded" if not validation.errors else "failed"
            if validation.errors:
                report.manual_actions.append(
                    "Review validation errors before treating the migration as complete."
                )
        except Exception as exc:
            total_duration = round(time.perf_counter() - started, 3)
            report.timings = MigrationTimings(
                total_migration_duration_seconds=total_duration,
                drop_duration_seconds=drop_duration or None,
                quantize_duration_seconds=quantize_duration or None,
                field_rename_duration_seconds=field_rename_duration or None,
                key_rename_duration_seconds=key_rename_duration or None,
                recreate_duration_seconds=recreate_duration or None,
                initial_indexing_duration_seconds=indexing_duration or None,
                downtime_duration_seconds=(
                    round(
                        drop_duration
                        + field_rename_duration
                        + key_rename_duration
                        + quantize_duration
                        + recreate_duration
                        + indexing_duration,
                        3,
                    )
                    if drop_duration
                    or field_rename_duration
                    or key_rename_duration
                    or quantize_duration
                    or recreate_duration
                    or indexing_duration
                    else None
                ),
            )
            report.validation = MigrationValidation(
                errors=[f"Migration execution failed: {exc}"]
            )
            report.manual_actions.extend(
                [
                    "Inspect the Redis index state before retrying.",
                    "If the source index was dropped, recreate it from the saved migration plan.",
                ]
            )
        finally:
            report.finished_at = timestamp_utc()

        return report

    def _cleanup_backup_files(self, backup_dir: str, index_name: str) -> None:
        """Remove backup files after successful migration.

        Only removes files with the exact extensions produced by VectorBackup
        (.header and .data), avoiding accidental deletion of unrelated files
        that happen to share the same prefix.
        """
        safe_name = index_name.replace("/", "_").replace("\\", "_").replace(":", "_")
        name_hash = hashlib.sha256(index_name.encode()).hexdigest()[:8]
        base_prefix = f"migration_backup_{safe_name}_{name_hash}"
        known_suffixes = (".header", ".data")
        backup_dir_path = Path(backup_dir)

        for entry in backup_dir_path.iterdir():
            if not entry.is_file():
                continue
            name = entry.name
            if not name.startswith(base_prefix):
                continue
            if not any(name.endswith(s) for s in known_suffixes):
                continue
            remainder = name[len(base_prefix) :]
            if remainder and remainder[0] not in (".", "_"):
                continue
            try:
                entry.unlink()
                logger.debug("Removed backup file: %s", entry)
            except OSError as e:
                logger.warning("Failed to remove backup file %s: %s", entry, e)

    # ------------------------------------------------------------------
    # Two-phase quantization: dump originals → convert from backup
    # ------------------------------------------------------------------

    async def _dump_vectors(
        self,
        client: Any,
        index_name: str,
        keys: List[str],
        datatype_changes: Dict[str, Dict[str, Any]],
        backup_path: str,
        batch_size: int = 500,
        key_prefix: Optional[Dict[str, str]] = None,
        checkpoint_identity: Optional[Dict[str, str]] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> "VectorBackup":
        """Phase 1: Pipeline-read original vectors and write to backup file.

        Async version. Runs BEFORE index drop.
        """
        from redisvl.migration.backup import VectorBackup

        backup = VectorBackup.create(
            path=backup_path,
            index_name=index_name,
            fields=datatype_changes,
            batch_size=batch_size,
            key_prefix=key_prefix,
            **(checkpoint_identity or {}),
        )

        total = len(keys)
        field_names = list(datatype_changes.keys())

        for batch_start in range(0, total, batch_size):
            batch_keys = keys[batch_start : batch_start + batch_size]

            # Pipelined async reads
            pipe = client.pipeline(transaction=False)
            call_order: List[tuple] = []
            for key in batch_keys:
                for field_name in field_names:
                    pipe.hget(key, field_name)
                    call_order.append((key, field_name))
            results = await pipe.execute()

            # Reassemble
            originals: Dict[str, Dict[str, bytes]] = {}
            for (key, field_name), value in zip(call_order, results):
                if value is not None:
                    if key not in originals:
                        originals[key] = {}
                    originals[key][field_name] = value

            backup.write_batch(batch_start // batch_size, batch_keys, originals)
            if progress_callback:
                progress_callback(min(batch_start + batch_size, total), total)

        backup.mark_dump_complete()
        return backup

    async def _quantize_from_backup(
        self,
        client: Any,
        backup: "VectorBackup",
        datatype_changes: Dict[str, Dict[str, Any]],
        key_transform: Optional[Callable[[str], str]] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> int:
        """Phase 2: Read originals from backup file, convert, pipeline-write.

        Async version. Runs AFTER index drop.
        """
        from redisvl.migration.quantize import convert_vectors

        if backup.header.phase in ("ready", "index_dropped"):
            backup.start_quantize()

        docs_quantized = 0
        start_batch = backup.header.quantize_completed_batches
        docs_done = start_batch * backup.header.batch_size

        for batch_idx, (batch_keys, originals) in enumerate(
            backup.iter_remaining_batches()
        ):
            actual_batch_idx = start_batch + batch_idx
            converted = convert_vectors(originals, datatype_changes)
            if key_transform is not None:
                converted = {
                    key_transform(key): fields for key, fields in converted.items()
                }
            if converted:
                pipe = client.pipeline(transaction=False)
                for key, fields in converted.items():
                    for field_name, data in fields.items():
                        pipe.hset(key, field_name, data)
                await pipe.execute()
            backup.mark_batch_quantized(actual_batch_idx)
            docs_quantized += len(batch_keys)
            docs_done += len(batch_keys)
            if progress_callback:
                total = backup.header.dump_completed_batches * backup.header.batch_size
                progress_callback(docs_done, total)

        backup.mark_complete()
        return docs_quantized

    async def _async_wait_for_index_ready(
        self,
        index: AsyncSearchIndex,
        *,
        timeout_seconds: int = 1800,
        poll_interval_seconds: float = 0.5,
        progress_callback: Optional[Callable[[int, int, float], None]] = None,
    ) -> tuple[Dict[str, Any], float]:
        """Wait for index to finish indexing all documents (async version)."""
        start = time.perf_counter()
        deadline = start + timeout_seconds
        latest_info = await index.info()

        stable_ready_checks: Optional[int] = None
        while time.perf_counter() < deadline:
            ready = False
            latest_info = await index.info()
            indexing = latest_info.get("indexing")
            percent_indexed = latest_info.get("percent_indexed")

            if percent_indexed is not None or indexing is not None:
                pct = float(percent_indexed) if percent_indexed is not None else None
                is_indexing = bool(indexing)
                if pct is not None:
                    ready = pct >= 1.0 and not is_indexing
                else:
                    # percent_indexed missing but indexing flag present:
                    # treat as ready when indexing flag is falsy (0 / False).
                    ready = not is_indexing
                if progress_callback:
                    total_docs = int(latest_info.get("num_docs", 0))
                    display_pct = pct if pct is not None else (1.0 if ready else 0.0)
                    indexed_docs = int(total_docs * display_pct)
                    progress_callback(indexed_docs, total_docs, display_pct * 100)
            else:
                current_docs = latest_info.get("num_docs")
                if current_docs is None:
                    ready = True
                else:
                    if stable_ready_checks is None:
                        stable_ready_checks = int(current_docs)
                        await asyncio.sleep(poll_interval_seconds)
                        continue
                    current = int(current_docs)
                    if current == stable_ready_checks:
                        ready = True
                    else:
                        # num_docs changed; update baseline and keep waiting
                        stable_ready_checks = current

            if ready:
                return latest_info, round(time.perf_counter() - start, 3)

            await asyncio.sleep(poll_interval_seconds)

        raise TimeoutError(
            f"Index {index.schema.index.name} did not become ready within {timeout_seconds} seconds"
        )

    async def _async_current_source_matches_snapshot(
        self,
        index_name: str,
        expected_schema: Dict[str, Any],
        *,
        redis_url: Optional[str] = None,
        redis_client: Optional[AsyncRedisClient] = None,
        strip_excluded: bool = False,
    ) -> bool:
        """Check if current source schema matches the snapshot (async version)."""
        from redisvl.migration.utils import schemas_equal

        try:
            current_index = await AsyncSearchIndex.from_existing(
                index_name,
                redis_url=redis_url,
                redis_client=redis_client,
            )
        except Exception:
            # Index no longer exists (e.g. already dropped during migration)
            return False
        return schemas_equal(
            current_index.schema.to_dict(),
            expected_schema,
            strip_excluded=strip_excluded,
        )

    def _build_benchmark_summary(
        self,
        plan: MigrationPlan,
        target_info: dict,
        timings: MigrationTimings,
    ) -> MigrationBenchmarkSummary:
        source_index_size = float(
            plan.source.stats_snapshot.get("vector_index_sz_mb", 0) or 0
        )
        target_index_size = float(target_info.get("vector_index_sz_mb", 0) or 0)
        source_num_docs = int(plan.source.stats_snapshot.get("num_docs", 0) or 0)
        indexed_per_second = None
        indexing_time = timings.initial_indexing_duration_seconds
        if indexing_time and indexing_time > 0:
            indexed_per_second = round(source_num_docs / indexing_time, 3)

        return MigrationBenchmarkSummary(
            documents_indexed_per_second=indexed_per_second,
            source_index_size_mb=round(source_index_size, 3),
            target_index_size_mb=round(target_index_size, 3),
            index_size_delta_mb=round(target_index_size - source_index_size, 3),
        )
