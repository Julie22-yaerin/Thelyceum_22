"""Batch migration executor with checkpointing and resume support."""

from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Any, Callable, Optional

import yaml

from redisvl.migration.executor import MigrationExecutor, _require_backup_dir
from redisvl.migration.models import (
    BatchIndexReport,
    BatchIndexState,
    BatchPlan,
    BatchReport,
    BatchReportSummary,
    BatchState,
)
from redisvl.migration.planner import MigrationPlanner
from redisvl.migration.utils import timestamp_utc, write_yaml
from redisvl.redis.connection import RedisConnectionFactory


class BatchMigrationExecutor:
    """Executor for batch migration of multiple indexes.

    Supports:
    - Sequential execution (one index at a time)
    - Checkpointing for resume after failure
    - Configurable failure policies (fail_fast, continue_on_error)
    """

    def __init__(self, executor: Optional[MigrationExecutor] = None):
        self._single_executor = executor or MigrationExecutor()
        self._planner = MigrationPlanner()

    def apply(
        self,
        batch_plan: BatchPlan,
        *,
        batch_plan_path: Optional[str] = None,
        state_path: str = "batch_state.yaml",
        report_dir: str = "./reports",
        redis_url: Optional[str] = None,
        redis_client: Optional[Any] = None,
        progress_callback: Optional[Callable[[str, int, int, str], None]] = None,
        backup_dir: Optional[str] = None,
        batch_size: int = 500,
        num_workers: int = 1,
    ) -> BatchReport:
        """Execute batch migration with checkpointing.

        Args:
            batch_plan: The batch plan to execute.
            batch_plan_path: Path to the batch plan file (stored in state for resume).
            state_path: Path to checkpoint state file.
            report_dir: Directory for per-index reports.
            redis_url: Redis connection URL.
            redis_client: Existing Redis client.
            progress_callback: Optional callback(index_name, position, total, status).
            backup_dir: Required directory for vector backup files.
            batch_size: Keys per pipeline batch (default 500).
            num_workers: Number of parallel quantization workers (default 1).

        Returns:
            BatchReport with results for all indexes.
        """
        backup_dir = _require_backup_dir(backup_dir)
        if num_workers > 1 and redis_url is None:
            raise ValueError(
                "redis_url is required when using num_workers > 1. "
                "Pass redis_url so each worker can open its own Redis connection."
            )

        # Get Redis client
        client = redis_client
        if client is None:
            if not redis_url:
                raise ValueError("Must provide either redis_url or redis_client")
            client = RedisConnectionFactory.get_redis_connection(redis_url=redis_url)

        # Ensure report directory exists
        report_path = Path(report_dir).resolve()
        report_path.mkdir(parents=True, exist_ok=True)

        # Initialize or load state
        state = self._init_or_load_state(
            batch_plan, state_path, batch_plan_path, backup_dir=backup_dir
        )
        started_at = state.started_at
        batch_start_time = time.perf_counter()

        # Get applicable indexes
        applicable_indexes = [idx for idx in batch_plan.indexes if idx.applicable]
        total = len(applicable_indexes)

        # Calculate the correct starting position for progress reporting
        # (accounts for already-completed indexes during resume)
        already_completed = len(state.completed)

        # Process each remaining index
        for offset, index_name in enumerate(state.remaining[:]):
            state.current_index = index_name
            state.updated_at = timestamp_utc()
            self._write_state(state, state_path)

            position = already_completed + offset + 1
            if progress_callback:
                progress_callback(index_name, position, total, "starting")

            # Find the index entry
            index_entry = next(
                (idx for idx in batch_plan.indexes if idx.name == index_name), None
            )
            if not index_entry or not index_entry.applicable:
                # Skip non-applicable indexes
                state.remaining.remove(index_name)
                state.completed.append(
                    BatchIndexState(
                        name=index_name,
                        status="skipped",
                        completed_at=timestamp_utc(),
                    )
                )
                state.current_index = None
                state.updated_at = timestamp_utc()
                self._write_state(state, state_path)
                if progress_callback:
                    progress_callback(index_name, position, total, "skipped")
                continue

            # Execute migration for this index
            index_state = self._migrate_single_index(
                index_name=index_name,
                batch_plan=batch_plan,
                report_dir=report_path,
                redis_url=redis_url,
                redis_client=client,
                backup_dir=backup_dir,
                batch_size=batch_size,
                num_workers=num_workers,
            )

            # Update state
            state.remaining.remove(index_name)
            state.completed.append(index_state)
            state.current_index = None
            state.updated_at = timestamp_utc()
            self._write_state(state, state_path)

            if progress_callback:
                progress_callback(index_name, position, total, index_state.status)

            # Check failure policy
            if (
                index_state.status == "failed"
                and batch_plan.failure_policy == "fail_fast"
            ):
                # Leave remaining indexes in state.remaining so that
                # checkpoint resume can pick them up later.
                break

        # Build final report
        total_duration = time.perf_counter() - batch_start_time
        return self._build_batch_report(batch_plan, state, started_at, total_duration)

    def resume(
        self,
        state_path: str,
        *,
        batch_plan_path: Optional[str] = None,
        retry_failed: bool = False,
        report_dir: str = "./reports",
        redis_url: Optional[str] = None,
        redis_client: Optional[Any] = None,
        progress_callback: Optional[Callable[[str, int, int, str], None]] = None,
        backup_dir: Optional[str] = None,
        batch_size: int = 500,
        num_workers: int = 1,
    ) -> BatchReport:
        """Resume batch migration from checkpoint.

        Args:
            state_path: Path to checkpoint state file.
            batch_plan_path: Path to batch plan (uses state.plan_path if not provided).
            retry_failed: If True, retry previously failed indexes.
            report_dir: Directory for per-index reports.
            redis_url: Redis connection URL.
            redis_client: Existing Redis client.
            progress_callback: Optional callback(index_name, position, total, status).
            backup_dir: Required directory for vector backup files.
            batch_size: Keys per pipeline batch (default 500).
            num_workers: Number of parallel quantization workers (default 1).
        """
        state = self._load_state(state_path)
        plan_path = batch_plan_path or state.plan_path
        if not plan_path or not plan_path.strip():
            raise ValueError(
                "No batch plan path available. Provide batch_plan_path explicitly, "
                "or ensure the checkpoint state contains a valid plan_path."
            )
        batch_plan = self._load_batch_plan(plan_path)
        backup_dir = backup_dir or state.backup_dir

        # Optionally retry failed indexes
        if retry_failed:
            failed_names = [
                idx.name for idx in state.completed if idx.status == "failed"
            ]
            state.remaining = failed_names + state.remaining
            state.completed = [idx for idx in state.completed if idx.status != "failed"]
            # Write updated state back to file so apply() picks up the changes
            self._write_state(state, state_path)

        # Re-run apply with the updated state
        return self.apply(
            batch_plan,
            batch_plan_path=batch_plan_path,
            state_path=state_path,
            report_dir=report_dir,
            redis_url=redis_url,
            redis_client=redis_client,
            progress_callback=progress_callback,
            backup_dir=backup_dir,
            batch_size=batch_size,
            num_workers=num_workers,
        )

    def _migrate_single_index(
        self,
        *,
        index_name: str,
        batch_plan: BatchPlan,
        report_dir: Path,
        redis_client: Any,
        redis_url: Optional[str] = None,
        backup_dir: Optional[str] = None,
        batch_size: int = 500,
        num_workers: int = 1,
    ) -> BatchIndexState:
        """Execute migration for a single index."""
        try:
            # Create migration plan for this index
            plan = self._planner.create_plan_from_patch(
                index_name,
                schema_patch=batch_plan.shared_patch,
                redis_client=redis_client,
            )

            # Execute migration
            report = self._single_executor.apply(
                plan,
                redis_url=redis_url,
                redis_client=redis_client,
                backup_dir=backup_dir,
                batch_size=batch_size,
                num_workers=num_workers,
            )

            # Sanitize index_name: replace any character that isn't
            # alphanumeric, dot, hyphen, or underscore to avoid path
            # traversal and filesystem-invalid characters (e.g. : on Windows).
            safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", index_name)
            report_file = report_dir / f"{safe_name}_report.yaml"
            write_yaml(report.model_dump(exclude_none=True), str(report_file))

            return BatchIndexState(
                name=index_name,
                status="success" if report.result == "succeeded" else "failed",
                completed_at=timestamp_utc(),
                report_path=str(report_file),
                error=report.validation.errors[0] if report.validation.errors else None,
            )

        except Exception as e:
            return BatchIndexState(
                name=index_name,
                status="failed",
                completed_at=timestamp_utc(),
                error=str(e),
            )

    def _init_or_load_state(
        self,
        batch_plan: BatchPlan,
        state_path: str,
        batch_plan_path: Optional[str] = None,
        backup_dir: Optional[str] = None,
    ) -> BatchState:
        """Initialize new state or load existing checkpoint."""
        path = Path(state_path).resolve()
        if path.exists():
            loaded = self._load_state(state_path)
            # Validate that loaded state matches the current batch plan
            if loaded.batch_id and loaded.batch_id != batch_plan.batch_id:
                raise ValueError(
                    f"Checkpoint state batch_id '{loaded.batch_id}' does not match "
                    f"current batch plan '{batch_plan.batch_id}'. "
                    "Remove the stale state file or use a different state_path."
                )
            # Update plan_path if caller provided one (handles cases where
            # the original path was empty or pointed to a deleted temp dir).
            if batch_plan_path:
                loaded.plan_path = str(Path(batch_plan_path).resolve())
            if loaded.backup_dir and backup_dir:
                loaded_backup_dir = str(Path(loaded.backup_dir).resolve())
                current_backup_dir = str(Path(backup_dir).resolve())
                if loaded_backup_dir != current_backup_dir:
                    raise ValueError(
                        f"Checkpoint state backup_dir '{loaded.backup_dir}' does not "
                        f"match current backup_dir '{backup_dir}'. Resume with the "
                        "same backup directory or use a different state_path."
                    )
            elif backup_dir:
                loaded.backup_dir = backup_dir
            return loaded

        # Create new state with plan_path for resume support
        applicable_names = [idx.name for idx in batch_plan.indexes if idx.applicable]
        return BatchState(
            batch_id=batch_plan.batch_id,
            plan_path=str(Path(batch_plan_path).resolve()) if batch_plan_path else "",
            backup_dir=backup_dir,
            started_at=timestamp_utc(),
            updated_at=timestamp_utc(),
            remaining=applicable_names,
            completed=[],
            current_index=None,
        )

    def _write_state(self, state: BatchState, state_path: str) -> None:
        """Write checkpoint state to file atomically.

        Writes to a temporary file first, then renames to avoid corruption
        if the process crashes mid-write.
        """
        path = Path(state_path).resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = path.with_suffix(".tmp")
        with open(tmp_path, "w") as f:
            yaml.safe_dump(state.model_dump(exclude_none=True), f, sort_keys=False)
            f.flush()
        tmp_path.replace(path)

    def _load_state(self, state_path: str) -> BatchState:
        """Load checkpoint state from file."""
        path = Path(state_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"State file not found: {state_path}")
        with open(path, "r") as f:
            data = yaml.safe_load(f) or {}
        return BatchState.model_validate(data)

    def _load_batch_plan(self, plan_path: str) -> BatchPlan:
        """Load batch plan from file."""
        path = Path(plan_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"Batch plan not found: {plan_path}")
        with open(path, "r") as f:
            data = yaml.safe_load(f) or {}
        return BatchPlan.model_validate(data)

    def _build_batch_report(
        self,
        batch_plan: BatchPlan,
        state: BatchState,
        started_at: str,
        total_duration: float,
    ) -> BatchReport:
        """Build final batch report from state."""
        index_reports = []
        succeeded = 0
        failed = 0
        skipped = 0

        for idx_state in state.completed:
            index_reports.append(
                BatchIndexReport(
                    name=idx_state.name,
                    status=idx_state.status,
                    report_path=idx_state.report_path,
                    error=idx_state.error,
                )
            )
            if idx_state.status == "success":
                succeeded += 1
            elif idx_state.status == "failed":
                failed += 1
            else:
                skipped += 1

        # Add remaining indexes (fail-fast left them pending) as skipped
        for remaining_name in state.remaining:
            index_reports.append(
                BatchIndexReport(
                    name=remaining_name,
                    status="skipped",
                    error="Skipped due to fail_fast policy",
                )
            )
            skipped += 1

        # Add non-applicable indexes as skipped
        for idx in batch_plan.indexes:
            if not idx.applicable:
                index_reports.append(
                    BatchIndexReport(
                        name=idx.name,
                        status="skipped",
                        error=idx.skip_reason,
                    )
                )
                skipped += 1

        # Determine overall status
        if failed == 0 and len(state.remaining) == 0:
            status = "completed"
        elif succeeded > 0:
            status = "partial_failure"
        else:
            status = "failed"

        return BatchReport(
            batch_id=batch_plan.batch_id,
            status=status,
            backup_dir=state.backup_dir,
            started_at=started_at,
            completed_at=timestamp_utc(),
            summary=BatchReportSummary(
                total_indexes=len(batch_plan.indexes),
                successful=succeeded,
                failed=failed,
                skipped=skipped,
                total_duration_seconds=round(total_duration, 3),
            ),
            indexes=index_reports,
        )
