from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from redisvl.index import SearchIndex
from redisvl.migration.models import (
    DiffClassification,
    FieldRename,
    KeyspaceSnapshot,
    MigrationPlan,
    RenameOperations,
    SchemaPatch,
    SourceSnapshot,
)
from redisvl.redis.connection import supports_svs
from redisvl.schema.schema import IndexSchema


class MigrationPlanner:
    """Migration planner for drop/recreate-based index migrations.

    The `drop_recreate` mode drops the index definition and recreates it with
    a new schema. By default, documents are preserved in Redis. When possible,
    the planner/executor can apply transformations so the preserved documents
    remain compatible with the new index schema.

    This means:
    - Index-only changes are always safe (algorithm, distance metric, tuning
      params, quantization, etc.)
    - Some document-dependent changes are supported via explicit migration
      operations in the migration plan

    Supported document-dependent changes:
    - Prefix/keyspace changes: keys are renamed via RENAME command
    - Field renames: documents are updated to use new field names
    - Index renaming: the new index is created with a different name

    Document-dependent changes that remain unsupported:
    - Vector dimensions: stored vectors have wrong number of dimensions
    - Storage type: documents are in hash format but index expects JSON
    """

    def __init__(self, key_sample_limit: int = 10):
        self.key_sample_limit = key_sample_limit

    def create_plan(
        self,
        index_name: str,
        *,
        redis_url: Optional[str] = None,
        schema_patch_path: Optional[str] = None,
        target_schema_path: Optional[str] = None,
        redis_client: Optional[Any] = None,
    ) -> MigrationPlan:
        """Generate a migration plan by comparing the live index to a desired schema.

        Snapshots the current index metadata from Redis, loads the requested
        changes from either a *schema_patch_path* or *target_schema_path*, and
        produces a :class:`MigrationPlan` that describes every step required to
        reach the target schema.

        No data is modified — this is a read-only planning step. The resulting
        plan should be reviewed before passing to
        :meth:`MigrationExecutor.apply`.

        Args:
            index_name: Name of the existing Redis Search index.
            redis_url: Redis connection URL
                (e.g. ``"redis://localhost:6379"``).
            schema_patch_path: Path to a YAML schema-patch file describing
                incremental changes (add/remove/update fields, change
                algorithm, rename fields, etc.).
            target_schema_path: Path to a full target-schema YAML file.
                The planner diffs the live schema against this target.
            redis_client: Optional pre-existing Redis client instance.

        Returns:
            MigrationPlan: An immutable plan object containing the source
            snapshot, diff classification, target schema, and any warnings.

        Raises:
            ValueError: If neither or both of *schema_patch_path* and
                *target_schema_path* are provided.
        """
        if not schema_patch_path and not target_schema_path:
            raise ValueError(
                "Must provide either --schema-patch or --target-schema for migration planning"
            )
        if schema_patch_path and target_schema_path:
            raise ValueError(
                "Provide only one of --schema-patch or --target-schema for migration planning"
            )

        snapshot = self.snapshot_source(
            index_name,
            redis_url=redis_url,
            redis_client=redis_client,
        )
        source_schema = IndexSchema.from_dict(snapshot.schema_snapshot)

        if schema_patch_path:
            schema_patch = self.load_schema_patch(schema_patch_path)
        else:
            # target_schema_path is guaranteed non-None here due to validation above
            assert target_schema_path is not None
            schema_patch = self.normalize_target_schema_to_patch(
                source_schema, target_schema_path
            )

        return self.create_plan_from_patch(
            index_name,
            schema_patch=schema_patch,
            redis_url=redis_url,
            redis_client=redis_client,
            _snapshot=snapshot,
        )

    def create_plan_from_patch(
        self,
        index_name: str,
        *,
        schema_patch: SchemaPatch,
        redis_url: Optional[str] = None,
        redis_client: Optional[Any] = None,
        _snapshot: Optional[Any] = None,
    ) -> MigrationPlan:
        if _snapshot is None:
            _snapshot = self.snapshot_source(
                index_name,
                redis_url=redis_url,
                redis_client=redis_client,
            )
        snapshot = _snapshot
        source_schema = IndexSchema.from_dict(snapshot.schema_snapshot)
        merged_target_schema = self.merge_patch(source_schema, schema_patch)

        # Extract rename operations first
        rename_operations, rename_warnings = self._extract_rename_operations(
            source_schema, schema_patch
        )

        # Classify diff with awareness of rename operations
        diff_classification = self.classify_diff(
            source_schema, schema_patch, merged_target_schema, rename_operations
        )

        # Build warnings list
        warnings = ["Index downtime is required"]
        warnings.extend(rename_warnings)

        # Warn if source index has hash indexing failures
        source_failures = int(
            snapshot.stats_snapshot.get("hash_indexing_failures", 0) or 0
        )
        if source_failures > 0:
            warnings.append(
                f"Source index has {source_failures:,} hash indexing failure(s). "
                "Documents that previously failed to index may become indexable after "
                "migration, causing the post-migration document count to differ from "
                "the pre-migration count. This is expected and validation accounts for it."
            )

        # Warn if source index is still building.  FT.AGGREGATE returns only
        # fully-indexed docs, so applying a migration before the background
        # build settles would silently drop the pending tail.  The executor
        # falls back to SCAN automatically, but surface the condition here
        # so users running `rvl migrate plan` can wait for indexing to
        # complete before applying.
        source_percent_indexed = float(
            snapshot.stats_snapshot.get("percent_indexed", 1.0) or 1.0
        )
        if source_percent_indexed < 1.0:
            warnings.append(
                f"Source index is still building "
                f"(percent_indexed={source_percent_indexed:.4f}). "
                "Apply will fall back to SCAN enumeration to avoid missing "
                "documents whose background HNSW indexing has not completed. "
                "Wait for percent_indexed to reach 1.0 before applying for "
                "the fastest migration path."
            )

        # Check for SVS-VAMANA in target schema and add appropriate warnings
        svs_warnings = self._check_svs_vamana_requirements(
            merged_target_schema,
            redis_url=redis_url,
            redis_client=redis_client,
        )
        warnings.extend(svs_warnings)

        return MigrationPlan(
            source=snapshot,
            requested_changes=schema_patch.model_dump(exclude_none=True),
            merged_target_schema=merged_target_schema.to_dict(),
            diff_classification=diff_classification,
            rename_operations=rename_operations,
            warnings=warnings,
        )

    def snapshot_source(
        self,
        index_name: str,
        *,
        redis_url: Optional[str] = None,
        redis_client: Optional[Any] = None,
    ) -> SourceSnapshot:
        index = SearchIndex.from_existing(
            index_name,
            redis_url=redis_url,
            redis_client=redis_client,
        )
        schema_dict = index.schema.to_dict()
        stats_snapshot = index.info()
        prefixes = index.schema.index.prefix
        prefix_list = prefixes if isinstance(prefixes, list) else [prefixes]

        return SourceSnapshot(
            index_name=index_name,
            schema_snapshot=schema_dict,
            stats_snapshot=stats_snapshot,
            keyspace=KeyspaceSnapshot(
                storage_type=index.schema.index.storage_type.value,
                prefixes=prefix_list,
                key_separator=index.schema.index.key_separator,
                key_sample=self._sample_keys(
                    client=index.client,
                    prefixes=prefix_list,
                    key_separator=index.schema.index.key_separator,
                ),
            ),
        )

    def load_schema_patch(self, schema_patch_path: str) -> SchemaPatch:
        patch_path = Path(schema_patch_path).resolve()
        if not patch_path.exists():
            raise FileNotFoundError(
                f"Schema patch file {schema_patch_path} does not exist"
            )

        with open(patch_path, "r") as f:
            patch_data = yaml.safe_load(f) or {}
        return SchemaPatch.model_validate(patch_data)

    def normalize_target_schema_to_patch(
        self, source_schema: IndexSchema, target_schema_path: str
    ) -> SchemaPatch:
        target_schema = IndexSchema.from_yaml(target_schema_path)
        source_dict = source_schema.to_dict()
        target_dict = target_schema.to_dict()

        changes: Dict[str, Any] = {
            "add_fields": [],
            "remove_fields": [],
            "update_fields": [],
            "index": {},
        }

        source_fields = {field["name"]: field for field in source_dict["fields"]}
        target_fields = {field["name"]: field for field in target_dict["fields"]}

        for field_name, target_field in target_fields.items():
            if field_name not in source_fields:
                changes["add_fields"].append(target_field)
            elif source_fields[field_name] != target_field:
                changes["update_fields"].append(target_field)

        for field_name in source_fields:
            if field_name not in target_fields:
                changes["remove_fields"].append(field_name)

        for index_key, target_value in target_dict["index"].items():
            source_value = source_dict["index"].get(index_key)
            # Normalize single-element list prefixes for comparison so that
            # e.g. source ["docs"] and target "docs" are treated as equal.
            sv, tv = source_value, target_value
            if index_key == "prefix":
                if isinstance(sv, list) and len(sv) == 1:
                    sv = sv[0]
                if isinstance(tv, list) and len(tv) == 1:
                    tv = tv[0]
            if sv != tv:
                changes["index"][index_key] = target_value

        return SchemaPatch.model_validate({"version": 1, "changes": changes})

    def merge_patch(
        self, source_schema: IndexSchema, schema_patch: SchemaPatch
    ) -> IndexSchema:
        schema_dict = deepcopy(source_schema.to_dict())
        changes = schema_patch.changes
        fields_by_name = {
            field["name"]: deepcopy(field) for field in schema_dict["fields"]
        }

        # Apply field renames first (before other modifications)
        # This ensures the merged schema's field names match the executor's renamed fields
        for rename in changes.rename_fields:
            if rename.old_name not in fields_by_name:
                raise ValueError(
                    f"Cannot rename field '{rename.old_name}' because it does not exist in the source schema"
                )
            if rename.new_name in fields_by_name and rename.new_name != rename.old_name:
                raise ValueError(
                    f"Cannot rename field '{rename.old_name}' to '{rename.new_name}' because a field with the new name already exists"
                )
            if rename.new_name == rename.old_name:
                continue  # No-op rename
            field_def = fields_by_name.pop(rename.old_name)
            field_def["name"] = rename.new_name
            fields_by_name[rename.new_name] = field_def

        for field_name in changes.remove_fields:
            fields_by_name.pop(field_name, None)

        # Build a mapping from old field names to new names so that
        # update_fields entries referencing pre-rename names still resolve.
        rename_map = {
            rename.old_name: rename.new_name
            for rename in changes.rename_fields
            if rename.old_name != rename.new_name
        }

        for field_update in changes.update_fields:
            # Resolve through renames: if the update references the old name,
            # look up the field under its new name.
            resolved_name = rename_map.get(field_update.name, field_update.name)
            if resolved_name not in fields_by_name:
                raise ValueError(
                    f"Cannot update field '{field_update.name}' because it does not exist in the source schema"
                )
            existing_field = fields_by_name[resolved_name]
            if field_update.type is not None:
                existing_field["type"] = field_update.type
            if field_update.path is not None:
                existing_field["path"] = field_update.path
            if field_update.attrs:
                merged_attrs = dict(existing_field.get("attrs", {}))
                merged_attrs.update(field_update.attrs)
                existing_field["attrs"] = merged_attrs

        for field in changes.add_fields:
            field_name = field["name"]
            if field_name in fields_by_name:
                raise ValueError(
                    f"Cannot add field '{field_name}' because it already exists in the source schema"
                )
            fields_by_name[field_name] = deepcopy(field)

        schema_dict["fields"] = list(fields_by_name.values())
        schema_dict["index"].update(changes.index)
        return IndexSchema.from_dict(schema_dict)

    def _extract_rename_operations(
        self,
        source_schema: IndexSchema,
        schema_patch: SchemaPatch,
    ) -> Tuple[RenameOperations, List[str]]:
        """Extract rename operations from the patch and generate warnings.

        Returns:
            Tuple of (RenameOperations, warnings list)
        """
        source_dict = source_schema.to_dict()
        changes = schema_patch.changes
        warnings: List[str] = []

        # Index rename
        rename_index: Optional[str] = None
        if "name" in changes.index:
            new_name = changes.index["name"]
            old_name = source_dict["index"].get("name")
            if new_name != old_name:
                rename_index = new_name
                warnings.append(
                    f"Index rename: '{old_name}' -> '{new_name}' (index-only change, no document migration needed)"
                )

        # Prefix change
        change_prefix: Optional[str] = None
        if "prefix" in changes.index:
            new_prefix = changes.index["prefix"]
            # Normalize list-type prefix to a single string (local copy only)
            if isinstance(new_prefix, list):
                if len(new_prefix) != 1:
                    raise ValueError(
                        f"Target prefix must be a single string, got list: {new_prefix}. "
                        f"Multi-prefix migrations are not supported."
                    )
                new_prefix = new_prefix[0]
            old_prefix = source_dict["index"].get("prefix")
            # Normalize single-element list to string for comparison
            if isinstance(old_prefix, list) and len(old_prefix) == 1:
                old_prefix = old_prefix[0]
            if new_prefix != old_prefix:
                # Block multi-prefix migrations - we only support single prefix
                if isinstance(old_prefix, list) and len(old_prefix) > 1:
                    raise ValueError(
                        f"Cannot change prefix for multi-prefix indexes. "
                        f"Source index has multiple prefixes: {old_prefix}. "
                        f"Multi-prefix migrations are not supported."
                    )
                change_prefix = new_prefix
                warnings.append(
                    f"Prefix change: '{old_prefix}' -> '{new_prefix}' "
                    "(requires RENAME for all keys, may be slow for large datasets)"
                )

        # Field renames from explicit rename_fields
        rename_fields: List[FieldRename] = list(changes.rename_fields)
        for field_rename in rename_fields:
            warnings.append(
                f"Field rename: '{field_rename.old_name}' -> '{field_rename.new_name}' "
                "(requires read/write for all documents, may be slow for large datasets)"
            )

        return (
            RenameOperations(
                rename_index=rename_index,
                change_prefix=change_prefix,
                rename_fields=rename_fields,
            ),
            warnings,
        )

    def _check_svs_vamana_requirements(
        self,
        target_schema: IndexSchema,
        *,
        redis_url: Optional[str] = None,
        redis_client: Optional[Any] = None,
    ) -> List[str]:
        """Check SVS-VAMANA requirements and return warnings.

        Checks:
        1. If target uses SVS-VAMANA, verify Redis version supports it
        2. Add Intel hardware warning for LVQ/LeanVec optimizations
        """
        warnings: List[str] = []
        target_dict = target_schema.to_dict()

        # Check if any vector field uses SVS-VAMANA
        uses_svs = False
        uses_compression = False
        compression_types: set = set()

        for field in target_dict.get("fields", []):
            if field.get("type") != "vector":
                continue
            attrs = field.get("attrs", {})
            algo = attrs.get("algorithm", "").upper()
            if algo == "SVS-VAMANA":
                uses_svs = True
                compression = attrs.get("compression", "")
                if compression:
                    uses_compression = True
                    compression_types.add(compression)

        if not uses_svs:
            return warnings

        # Check Redis version support
        created_client = None
        try:
            if redis_client:
                client = redis_client
            elif redis_url:
                from redis import Redis

                client = Redis.from_url(redis_url)
                created_client = client
            else:
                client = None

            if client and not supports_svs(client):
                warnings.append(
                    "SVS-VAMANA requires Redis >= 8.2.0 and Redis Search >= 2.8.10. "
                    "The target Redis instance may not support this algorithm. "
                    "Migration will fail at apply time if requirements are not met."
                )
        except Exception:
            # If we can't check, add a general warning
            warnings.append(
                "SVS-VAMANA requires Redis >= 8.2.0 and Redis Search >= 2.8.10. "
                "Verify your Redis instance supports this algorithm before applying."
            )
        finally:
            if created_client:
                created_client.close()

        # Intel hardware warning for compression
        if uses_compression:
            compression_label = ", ".join(sorted(compression_types))
            warnings.append(
                f"SVS-VAMANA with {compression_label} compression: "
                "LVQ and LeanVec optimizations require Intel hardware with AVX-512 support. "
                "On non-Intel platforms or Redis Open Source, these fall back to basic "
                "8-bit scalar quantization with reduced performance benefits."
            )
        else:
            warnings.append(
                "SVS-VAMANA: For optimal performance, Intel hardware with AVX-512 support "
                "is recommended. LVQ/LeanVec compression options provide additional memory "
                "savings on supported hardware."
            )

        return warnings

    def classify_diff(
        self,
        source_schema: IndexSchema,
        schema_patch: SchemaPatch,
        merged_target_schema: IndexSchema,
        rename_operations: Optional[RenameOperations] = None,
    ) -> DiffClassification:
        blocked_reasons: List[str] = []
        changes = schema_patch.changes
        source_dict = source_schema.to_dict()
        target_dict = merged_target_schema.to_dict()

        # Check which rename operations are being handled
        has_index_rename = rename_operations and rename_operations.rename_index
        has_prefix_change = (
            rename_operations and rename_operations.change_prefix is not None
        )
        has_field_renames = (
            rename_operations and len(rename_operations.rename_fields) > 0
        )

        for index_key, target_value in changes.index.items():
            source_value = source_dict["index"].get(index_key)
            # Normalize single-element list prefixes for comparison so that
            # e.g. source ``["docs"]`` and target ``"docs"`` are treated as equal.
            sv, tv = source_value, target_value
            if index_key == "prefix":
                if isinstance(sv, list) and len(sv) == 1:
                    sv = sv[0]
                if isinstance(tv, list) and len(tv) == 1:
                    tv = tv[0]
            if sv == tv:
                continue
            if index_key == "name":
                # Index rename is now supported - skip blocking if we have rename_operations
                if not has_index_rename:
                    blocked_reasons.append(
                        "Changing the index name requires document migration (not yet supported)."
                    )
            elif index_key == "prefix":
                # Prefix change is now supported
                if not has_prefix_change:
                    blocked_reasons.append(
                        "Changing index prefixes requires document migration (not yet supported)."
                    )
            elif index_key == "key_separator":
                blocked_reasons.append(
                    "Changing the key separator requires document migration (not yet supported)."
                )
            elif index_key == "storage_type":
                blocked_reasons.append(
                    "Changing the storage type requires document migration (not yet supported)."
                )

        source_fields = {field["name"]: field for field in source_dict["fields"]}
        target_fields = {field["name"]: field for field in target_dict["fields"]}

        for field in changes.add_fields:
            if field["type"] == "vector":
                blocked_reasons.append(
                    f"Adding vector field '{field['name']}' requires document migration (not yet supported)."
                )

        # Build rename mappings: old->new and new->old so update_fields
        # can reference either the pre-rename or post-rename name
        classify_rename_map = {
            rename.old_name: rename.new_name
            for rename in changes.rename_fields
            if rename.old_name != rename.new_name
        }
        reverse_rename_map = {v: k for k, v in classify_rename_map.items()}

        for field_update in changes.update_fields:
            # Resolve through renames: update_fields may use old or new name
            if field_update.name in classify_rename_map:
                # update references old name -> look up source by old, target by new
                source_name = field_update.name
                target_name = classify_rename_map[field_update.name]
            elif field_update.name in reverse_rename_map:
                # update references new name -> look up source by old, target by new
                source_name = reverse_rename_map[field_update.name]
                target_name = field_update.name
            else:
                # no rename involved
                source_name = field_update.name
                target_name = field_update.name
            source_field = source_fields.get(source_name)
            target_field = target_fields.get(target_name)
            if source_field is None or target_field is None:
                # Field not found in source or target; skip classification
                continue
            source_type = source_field["type"]
            target_type = target_field["type"]

            if source_type != target_type:
                blocked_reasons.append(
                    f"Changing field '{field_update.name}' type from {source_type} to {target_type} is not supported by drop_recreate."
                )
                continue

            source_path = source_field.get("path")
            target_path = target_field.get("path")
            if source_path != target_path:
                blocked_reasons.append(
                    f"Changing field '{field_update.name}' path from {source_path} to {target_path} is not supported by drop_recreate."
                )
                continue

            if target_type == "vector" and source_field != target_field:
                # Check for document-dependent changes that are not yet supported
                vector_blocked = self._classify_vector_field_change(
                    source_field, target_field
                )
                blocked_reasons.extend(vector_blocked)

        # Detect possible undeclared field renames. When explicit renames
        # exist, exclude those fields from heuristic detection so we still
        # catch additional add/remove pairs that look like renames.
        detect_source = dict(source_fields)
        detect_target = dict(target_fields)
        if has_field_renames and rename_operations:
            for fr in rename_operations.rename_fields:
                detect_source.pop(fr.old_name, None)
                detect_target.pop(fr.new_name, None)
        blocked_reasons.extend(
            self._detect_possible_field_renames(detect_source, detect_target)
        )

        return DiffClassification(
            supported=len(blocked_reasons) == 0,
            blocked_reasons=self._dedupe(blocked_reasons),
        )

    def write_plan(self, plan: MigrationPlan, plan_out: str) -> None:
        plan_path = Path(plan_out).resolve()
        with open(plan_path, "w") as f:
            yaml.safe_dump(plan.model_dump(exclude_none=True), f, sort_keys=False)

    def _sample_keys(
        self, *, client: Any, prefixes: List[str], key_separator: str
    ) -> List[str]:
        key_sample: List[str] = []
        if client is None or self.key_sample_limit <= 0:
            return key_sample

        for prefix in prefixes:
            if len(key_sample) >= self.key_sample_limit:
                break
            if prefix == "":
                match_pattern = "*"
            else:
                # Use literal prefix + glob, matching Redis Search PREFIX
                # semantics (pure string-prefix match).  Do NOT insert the
                # key_separator — a PREFIX of "doc" must match "doc:1",
                # "doca:1", etc., exactly like FT.CREATE does.
                match_pattern = f"{prefix}*"
            cursor = 0
            while True:
                cursor, keys = client.scan(
                    cursor=cursor,
                    match=match_pattern,
                    count=max(self.key_sample_limit, 1000),
                )
                for key in keys:
                    decoded_key = key.decode() if isinstance(key, bytes) else str(key)
                    if decoded_key not in key_sample:
                        key_sample.append(decoded_key)
                    if len(key_sample) >= self.key_sample_limit:
                        return key_sample
                if cursor == 0:
                    break
        return key_sample

    def _detect_possible_field_renames(
        self,
        source_fields: Dict[str, Dict[str, Any]],
        target_fields: Dict[str, Dict[str, Any]],
    ) -> List[str]:
        blocked_reasons: List[str] = []
        added_fields = [
            field for name, field in target_fields.items() if name not in source_fields
        ]
        removed_fields = [
            field for name, field in source_fields.items() if name not in target_fields
        ]

        for removed_field in removed_fields:
            for added_field in added_fields:
                if self._fields_match_except_name(removed_field, added_field):
                    blocked_reasons.append(
                        f"Possible field rename from '{removed_field['name']}' to '{added_field['name']}' is not supported by drop_recreate."
                    )
        return blocked_reasons

    @staticmethod
    def _classify_vector_field_change(
        source_field: Dict[str, Any], target_field: Dict[str, Any]
    ) -> List[str]:
        """Classify vector field changes as supported or blocked for drop_recreate.

        Index-only changes (allowed with drop_recreate):
            - algorithm (FLAT -> HNSW -> SVS-VAMANA)
            - distance_metric (COSINE, L2, IP)
            - initial_cap
            - Algorithm tuning: m, ef_construction, ef_runtime, epsilon, block_size,
              graph_max_degree, construction_window_size, search_window_size, etc.

        Quantization changes (allowed with drop_recreate, requires vector re-encoding):
            - datatype (float32 -> float16, etc.) - executor will re-encode vectors

        Document-dependent changes (blocked, not yet supported):
            - dims (vectors stored with wrong number of dimensions)
        """
        blocked_reasons: List[str] = []
        field_name = source_field.get("name", "unknown")
        source_attrs = source_field.get("attrs", {})
        target_attrs = target_field.get("attrs", {})

        # Document-dependent properties (not yet supported)
        if source_attrs.get("dims") != target_attrs.get("dims"):
            blocked_reasons.append(
                f"Changing vector field '{field_name}' dims from {source_attrs.get('dims')} "
                f"to {target_attrs.get('dims')} requires document migration (not yet supported). "
                "Vectors are stored with incompatible dimensions."
            )

        # Datatype changes are now ALLOWED - executor will re-encode vectors
        # before recreating the index

        # All other vector changes are index-only and allowed
        return blocked_reasons

    @staticmethod
    def get_vector_datatype_changes(
        source_schema: Dict[str, Any],
        target_schema: Dict[str, Any],
        rename_operations: Optional[Any] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """Identify vector fields that need datatype conversion (quantization).

        Handles renamed vector fields by using rename_operations to map
        source field names to their target counterparts.

        Returns:
            Dict mapping source_field_name -> {
                "source": source_dtype,
                "target": target_dtype,
                "dims": int  # vector dimensions for idempotent detection
            }
        """
        changes: Dict[str, Dict[str, Any]] = {}
        source_fields = {f["name"]: f for f in source_schema.get("fields", [])}
        target_fields = {f["name"]: f for f in target_schema.get("fields", [])}

        # Build rename map: source_name -> target_name
        field_rename_map: Dict[str, str] = {}
        if rename_operations and hasattr(rename_operations, "rename_fields"):
            for fr in rename_operations.rename_fields:
                field_rename_map[fr.old_name] = fr.new_name

        for name, source_field in source_fields.items():
            if source_field.get("type") != "vector":
                continue
            # Look up target by renamed name if applicable
            target_name = field_rename_map.get(name, name)
            target_field = target_fields.get(target_name)
            if not target_field or target_field.get("type") != "vector":
                continue

            source_dtype = source_field.get("attrs", {}).get("datatype", "float32")
            target_dtype = target_field.get("attrs", {}).get("datatype", "float32")
            dims = source_field.get("attrs", {}).get("dims", 0)

            if source_dtype != target_dtype:
                changes[name] = {
                    "source": source_dtype,
                    "target": target_dtype,
                    "dims": dims,
                }

        return changes

    @staticmethod
    def _fields_match_except_name(
        source_field: Dict[str, Any], target_field: Dict[str, Any]
    ) -> bool:
        comparable_source = {k: v for k, v in source_field.items() if k != "name"}
        comparable_target = {k: v for k, v in target_field.items() if k != "name"}
        return comparable_source == comparable_target

    @staticmethod
    def _dedupe(values: List[str]) -> List[str]:
        deduped: List[str] = []
        for value in values:
            if value not in deduped:
                deduped.append(value)
        return deduped
