"""
Comprehensive integration tests for all 38 supported migration operations.

This test suite validates migrations against real Redis with a tiered validation approach:
- L1: Execution (plan.supported == True)
- L2: Data Integrity (doc_count_match == True)
- L3: Key Existence (key_sample_exists == True)
- L4: Schema Match (schema_match == True)

Test Categories:
1. Index-Level (2): rename index, change prefix
2. Field Add (4): text, tag, numeric, geo
3. Field Remove (5): text, tag, numeric, geo, vector
4. Field Rename (5): text, tag, numeric, geo, vector
5. Base Attrs (3): sortable, no_index, index_missing
6. Text Attrs (5): weight, no_stem, phonetic_matcher, index_empty, unf
7. Tag Attrs (3): separator, case_sensitive, index_empty
8. Numeric Attrs (1): unf
9. Vector Attrs (8): algorithm, distance_metric, initial_cap, m, ef_construction,
                      ef_runtime, epsilon, datatype
10. JSON Storage (2): add field, rename field

Some tests use L2-only validation due to Redis FT.INFO limitations:
- prefix change (keys renamed), HNSW params, initial_cap, phonetic_matcher, numeric unf

Run: pytest tests/integration/test_migration_comprehensive.py -v
Spec: local_docs/index_migrator/32_integration_test_spec.md
"""

import glob
import os
import time
import uuid
from typing import Any, Dict, List

import pytest
import yaml

from redisvl.index import SearchIndex
from redisvl.migration import MigrationExecutor, MigrationPlanner
from redisvl.migration.utils import load_migration_plan
from redisvl.redis.utils import array_to_buffer

# ==============================================================================
# Fixtures
# ==============================================================================


@pytest.fixture
def unique_ids(worker_id):
    """Generate unique identifiers for test isolation."""
    uid = str(uuid.uuid4())[:8]
    return {
        "name": f"mig_test_{worker_id}_{uid}",
        "prefix": f"mig_test:{worker_id}:{uid}",
    }


@pytest.fixture
def base_schema(unique_ids):
    """Base schema with all field types for testing."""
    return {
        "index": {
            "name": unique_ids["name"],
            "prefix": unique_ids["prefix"],
            "storage_type": "hash",
        },
        "fields": [
            {"name": "doc_id", "type": "tag"},
            {"name": "title", "type": "text"},
            {"name": "description", "type": "text"},
            {"name": "category", "type": "tag"},
            {"name": "price", "type": "numeric"},
            {"name": "location", "type": "geo"},
            {
                "name": "embedding",
                "type": "vector",
                "attrs": {
                    "algorithm": "hnsw",
                    "dims": 4,
                    "distance_metric": "cosine",
                    "datatype": "float32",
                },
            },
        ],
    }


@pytest.fixture
def sample_docs():
    """Sample documents with all field types."""
    return [
        {
            "doc_id": "1",
            "title": "Alpha Product",
            "description": "First product description",
            "category": "electronics",
            "price": 99.99,
            "location": "-122.4194,37.7749",  # SF coordinates (lon,lat)
            "embedding": array_to_buffer([0.1, 0.2, 0.3, 0.4], "float32"),
        },
        {
            "doc_id": "2",
            "title": "Beta Service",
            "description": "Second service description",
            "category": "software",
            "price": 149.99,
            "location": "-73.9857,40.7484",  # NYC coordinates (lon,lat)
            "embedding": array_to_buffer([0.2, 0.3, 0.4, 0.5], "float32"),
        },
        {
            "doc_id": "3",
            "title": "Gamma Item",
            "description": "",  # Empty for index_empty tests
            "category": "",  # Empty for index_empty tests
            "price": 0,
            "location": "-118.2437,34.0522",  # LA coordinates (lon,lat)
            "embedding": array_to_buffer([0.3, 0.4, 0.5, 0.6], "float32"),
        },
    ]


def run_migration(
    redis_url: str,
    tmp_path,
    index_name: str,
    patch: Dict[str, Any],
) -> Dict[str, Any]:
    """Helper to run a migration and return results."""
    patch_path = tmp_path / "patch.yaml"
    patch_path.write_text(yaml.safe_dump(patch, sort_keys=False))

    plan_path = tmp_path / "plan.yaml"
    planner = MigrationPlanner()
    plan = planner.create_plan(
        index_name,
        redis_url=redis_url,
        schema_patch_path=str(patch_path),
    )
    planner.write_plan(plan, str(plan_path))

    executor = MigrationExecutor()
    backup_dir = tmp_path / "migration_backups"
    report = executor.apply(
        load_migration_plan(str(plan_path)),
        redis_url=redis_url,
        backup_dir=str(backup_dir),
    )

    return {
        "plan": plan,
        "report": report,
        "supported": plan.diff_classification.supported,
        "succeeded": report.result == "succeeded",
        # Additional validation fields for granular checks
        "doc_count_match": report.validation.doc_count_match,
        "schema_match": report.validation.schema_match,
        "key_sample_exists": report.validation.key_sample_exists,
        "validation_errors": report.validation.errors,
    }


def setup_index(redis_url: str, schema: Dict, docs: List[Dict]) -> SearchIndex:
    """Create index and load documents."""
    index = SearchIndex.from_dict(schema, redis_url=redis_url)
    index.create(overwrite=True)
    index.load(docs, id_field="doc_id")
    return index


def cleanup_index(index: SearchIndex):
    """Clean up index after test."""
    try:
        index.delete(drop=True)
    except Exception:
        pass


def wait_for_indexing_state(
    index: SearchIndex,
    expected_docs: int,
    min_failures: int = 0,
    timeout_seconds: float = 5.0,
) -> tuple[int, int]:
    """Wait until RediSearch reports the expected docs and failure floor."""
    deadline = time.monotonic() + timeout_seconds
    num_docs = 0
    failures = 0
    while time.monotonic() < deadline:
        info = index.info()
        num_docs = int(info.get("num_docs", 0))
        failures = int(info.get("hash_indexing_failures", 0))
        if num_docs == expected_docs and failures >= min_failures:
            return num_docs, failures
        time.sleep(0.1)
    return num_docs, failures


# ==============================================================================
# 1. Index-Level Changes
# ==============================================================================


class TestIndexLevelChanges:
    """Tests for index-level migration operations."""

    def test_rename_index(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test renaming an index."""
        index = setup_index(redis_url, base_schema, sample_docs)
        old_name = base_schema["index"]["name"]
        new_name = f"{old_name}_renamed"

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                old_name,
                {"version": 1, "changes": {"index": {"name": new_name}}},
            )

            assert result["supported"], "Rename index should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"

            # Verify new index exists
            live_index = SearchIndex.from_existing(new_name, redis_url=redis_url)
            assert live_index.schema.index.name == new_name
            cleanup_index(live_index)
        except Exception:
            cleanup_index(index)
            raise

    def test_change_prefix(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test changing the key prefix (requires key renames)."""
        index = setup_index(redis_url, base_schema, sample_docs)
        old_prefix = base_schema["index"]["prefix"]
        new_prefix = f"{old_prefix}_newprefix"

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {"version": 1, "changes": {"index": {"prefix": new_prefix}}},
            )

            assert result["supported"], "Change prefix should be supported"
            # Validation now handles prefix change by transforming key_sample to new prefix
            assert result["succeeded"], f"Migration failed: {result['report']}"

            # Verify keys were renamed
            live_index = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            assert live_index.schema.index.prefix == new_prefix
            cleanup_index(live_index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 2. Field Operations - Add Fields
# ==============================================================================


class TestAddFields:
    """Tests for adding fields of different types."""

    def test_add_text_field(self, redis_url, tmp_path, unique_ids, sample_docs):
        """Test adding a text field."""
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [{"name": "doc_id", "type": "tag"}],
        }
        index = setup_index(redis_url, schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "add_fields": [{"name": "title", "type": "text"}],
                    },
                },
            )

            assert result["supported"], "Add text field should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 2. Field Operations - Remove Fields
# ==============================================================================


class TestRemoveFields:
    """Tests for removing fields of different types."""

    def test_remove_text_field(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test removing a text field."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {"version": 1, "changes": {"remove_fields": ["description"]}},
            )

            assert result["supported"], "Remove text field should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_remove_vector_field(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test removing a vector field (allowed but warned)."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {"version": 1, "changes": {"remove_fields": ["embedding"]}},
            )

            assert result["supported"], "Remove vector field should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 2. Field Operations - Rename Fields
# ==============================================================================


class TestRenameFields:
    """Tests for renaming fields of different types."""

    def test_rename_text_field(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test renaming a text field."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "rename_fields": [
                            {"old_name": "title", "new_name": "headline"}
                        ],
                    },
                },
            )

            assert result["supported"], "Rename text field should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_rename_vector_field(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test renaming a vector field."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "rename_fields": [
                            {"old_name": "embedding", "new_name": "vector"}
                        ],
                    },
                },
            )

            assert result["supported"], "Rename vector field should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 3. Base Attributes (All Non-Vector Types)
# ==============================================================================


class TestBaseAttributes:
    """Tests for base attributes: sortable, no_index, index_missing."""

    def test_add_sortable(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test adding sortable attribute to a field."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "title", "attrs": {"sortable": True}}
                        ],
                    },
                },
            )

            assert result["supported"], "Add sortable should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_add_no_index(self, redis_url, tmp_path, unique_ids, sample_docs):
        """Test adding no_index attribute (store only, no searching)."""
        # Need a sortable field first
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [
                {"name": "doc_id", "type": "tag"},
                {"name": "title", "type": "text", "attrs": {"sortable": True}},
            ],
        }
        index = setup_index(redis_url, schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "title", "attrs": {"no_index": True}}
                        ],
                    },
                },
            )

            assert result["supported"], "Add no_index should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_add_index_missing(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test adding index_missing attribute."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "title", "attrs": {"index_missing": True}}
                        ],
                    },
                },
            )

            assert result["supported"], "Add index_missing should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 4. Text Field Attributes
# ==============================================================================


class TestTextAttributes:
    """Tests for text field attributes: weight, no_stem, phonetic_matcher, etc."""

    def test_add_index_empty_text(self, redis_url, tmp_path, base_schema, sample_docs):
        """Test adding index_empty to text field."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "title", "attrs": {"index_empty": True}}
                        ],
                    },
                },
            )

            assert result["supported"], "Add index_empty should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_add_unf_text(self, redis_url, tmp_path, unique_ids, sample_docs):
        """Test adding unf (un-normalized form) to text field."""
        # UNF requires sortable
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [
                {"name": "doc_id", "type": "tag"},
                {"name": "title", "type": "text", "attrs": {"sortable": True}},
            ],
        }
        index = setup_index(redis_url, schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [{"name": "title", "attrs": {"unf": True}}],
                    },
                },
            )

            assert result["supported"], "Add UNF should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 5. Tag Field Attributes
# ==============================================================================


class TestNumericAttributes:
    """Tests for numeric field attributes: unf."""

    def test_add_unf_numeric(self, redis_url, tmp_path, unique_ids, sample_docs):
        """Test adding unf (un-normalized form) to numeric field."""
        # UNF requires sortable
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [
                {"name": "doc_id", "type": "tag"},
                {"name": "price", "type": "numeric", "attrs": {"sortable": True}},
            ],
        }
        index = setup_index(redis_url, schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [{"name": "price", "attrs": {"unf": True}}],
                    },
                },
            )

            assert result["supported"], "Add UNF to numeric should be supported"
            # Redis auto-applies UNF with SORTABLE on numeric fields, so both should match
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 7. Vector Field Attributes (Index-Only Changes)
# ==============================================================================


class TestVectorAttributes:
    """Tests for vector field attributes: algorithm, distance_metric, HNSW params, etc."""

    def test_change_algorithm_hnsw_to_flat(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """Test changing vector algorithm from HNSW to FLAT."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "embedding", "attrs": {"algorithm": "flat"}}
                        ],
                    },
                },
            )

            assert result["supported"], "Change algorithm should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_change_distance_metric(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """Test changing distance metric."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "embedding", "attrs": {"distance_metric": "l2"}}
                        ],
                    },
                },
            )

            assert result["supported"], "Change distance_metric should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_change_datatype_quantization(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """Test changing vector datatype (quantization)."""
        index = setup_index(redis_url, base_schema, sample_docs)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                base_schema["index"]["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "embedding", "attrs": {"datatype": "float16"}}
                        ],
                    },
                },
            )

            assert result["supported"], "Change datatype should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 8. JSON Storage Type Tests
# ==============================================================================


class TestJsonStorageType:
    """Tests for migrations with JSON storage type."""

    @pytest.fixture
    def json_schema(self, unique_ids):
        """Schema using JSON storage type."""
        return {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "json",
            },
            "fields": [
                {"name": "doc_id", "type": "tag", "path": "$.doc_id"},
                {"name": "title", "type": "text", "path": "$.title"},
                {"name": "category", "type": "tag", "path": "$.category"},
                {"name": "price", "type": "numeric", "path": "$.price"},
                {
                    "name": "embedding",
                    "type": "vector",
                    "path": "$.embedding",
                    "attrs": {
                        "algorithm": "hnsw",
                        "dims": 4,
                        "distance_metric": "cosine",
                        "datatype": "float32",
                    },
                },
            ],
        }

    @pytest.fixture
    def json_sample_docs(self):
        """Sample JSON documents (as dicts for RedisJSON)."""
        return [
            {
                "doc_id": "1",
                "title": "Alpha Product",
                "category": "electronics",
                "price": 99.99,
                "embedding": [0.1, 0.2, 0.3, 0.4],
            },
            {
                "doc_id": "2",
                "title": "Beta Service",
                "category": "software",
                "price": 149.99,
                "embedding": [0.2, 0.3, 0.4, 0.5],
            },
        ]

    def test_json_add_field(
        self, redis_url, tmp_path, unique_ids, json_schema, json_sample_docs, client
    ):
        """Test adding a field with JSON storage."""
        index = SearchIndex.from_dict(json_schema, redis_url=redis_url)
        index.create(overwrite=True)

        # Load JSON docs directly
        for i, doc in enumerate(json_sample_docs):
            key = f"{unique_ids['prefix']}:{i + 1}"
            client.json().set(key, "$", json_sample_docs[i])

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "add_fields": [
                            {
                                "name": "status",
                                "type": "tag",
                                "path": "$.status",
                            }
                        ],
                    },
                },
            )

            assert result["supported"], "Add field with JSON should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_json_rename_field(
        self, redis_url, tmp_path, unique_ids, json_schema, json_sample_docs, client
    ):
        """Test renaming a field with JSON storage."""
        index = SearchIndex.from_dict(json_schema, redis_url=redis_url)
        index.create(overwrite=True)

        # Load JSON docs
        for i, doc in enumerate(json_sample_docs):
            key = f"{unique_ids['prefix']}:{i + 1}"
            client.json().set(key, "$", doc)

        try:
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "rename_fields": [
                            {"old_name": "title", "new_name": "headline"}
                        ],
                    },
                },
            )

            assert result["supported"], "Rename field with JSON should be supported"
            assert result["succeeded"], f"Migration failed: {result['report']}"
            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 9. Hash Indexing Failures Validation Tests
# ==============================================================================


class TestHashIndexingFailuresValidation:
    """Tests for validation when source index has hash_indexing_failures.

    These tests verify that the migrator correctly handles indexes where some
    documents fail to index (e.g., due to wrong vector dimensions). The
    executor should pass exact enumerated key counts into validation when
    failures exist, so that resolved failures don't trigger false negatives.
    """

    def test_migration_with_indexing_failures_passes_validation(
        self, redis_url, tmp_path, unique_ids, client
    ):
        """Migration should pass validation when source has hash_indexing_failures.

        Scenario: Create index with dims=4, load 3 correct docs + 2 docs with
        wrong-dimension vectors. The 2 bad docs cause hash_indexing_failures.
        Run a simple migration (add a text field). After migration, validation
        should pass because exact source keys are conserved.
        """
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [
                {"name": "title", "type": "text"},
                {
                    "name": "embedding",
                    "type": "vector",
                    "attrs": {
                        "algorithm": "hnsw",
                        "dims": 4,
                        "distance_metric": "cosine",
                        "datatype": "float32",
                    },
                },
            ],
        }

        index = setup_index(
            redis_url,
            schema,
            [
                {
                    "doc_id": "1",
                    "title": "Good doc one",
                    "embedding": array_to_buffer([0.1, 0.2, 0.3, 0.4], "float32"),
                },
                {
                    "doc_id": "2",
                    "title": "Good doc two",
                    "embedding": array_to_buffer([0.2, 0.3, 0.4, 0.5], "float32"),
                },
                {
                    "doc_id": "3",
                    "title": "Good doc three",
                    "embedding": array_to_buffer([0.3, 0.4, 0.5, 0.6], "float32"),
                },
            ],
        )

        try:
            # Manually add 2 keys with wrong-dimension vectors (8-dim instead of 4)
            # These will cause hash_indexing_failures
            bad_vec = array_to_buffer(
                [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8], "float32"
            )
            client.hset(
                f"{unique_ids['prefix']}:bad1",
                mapping={"title": "Bad doc one", "embedding": bad_vec},
            )
            client.hset(
                f"{unique_ids['prefix']}:bad2",
                mapping={"title": "Bad doc two", "embedding": bad_vec},
            )

            # Verify we have indexing failures
            num_docs, failures = wait_for_indexing_state(
                index, expected_docs=3, min_failures=2
            )
            assert num_docs == 3, f"Expected 3 indexed docs, got {num_docs}"
            assert (
                failures >= 2
            ), f"Expected at least 2 indexing failures, got {failures}"

            # Run migration: add a text field (simple, non-destructive)
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "add_fields": [{"name": "category", "type": "tag"}],
                    },
                },
            )

            assert result["supported"], "Add field should be supported"
            assert result[
                "succeeded"
            ], f"Migration failed: {result['validation_errors']}"
            assert result["doc_count_match"], (
                f"Doc count should match (total keys conserved). "
                f"Errors: {result['validation_errors']}"
            )

            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_quantization_resolves_failures_passes_validation(
        self, redis_url, tmp_path, unique_ids, client
    ):
        """Quantization migration that resolves indexing failures should pass.

        Scenario: Create index with dims=4 float32, load 3 docs with float32
        vectors. Then add 2 docs with float16 vectors (same dims but wrong
        byte size for float32). These cause hash_indexing_failures. Migrate to
        float16 — now the previously failed docs become indexable and the
        previously good docs get re-encoded. Total keys are conserved.
        """
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [
                {"name": "title", "type": "text"},
                {
                    "name": "embedding",
                    "type": "vector",
                    "attrs": {
                        "algorithm": "hnsw",
                        "dims": 4,
                        "distance_metric": "cosine",
                        "datatype": "float32",
                    },
                },
            ],
        }

        index = setup_index(
            redis_url,
            schema,
            [
                {
                    "doc_id": "1",
                    "title": "Float32 doc one",
                    "embedding": array_to_buffer([0.1, 0.2, 0.3, 0.4], "float32"),
                },
                {
                    "doc_id": "2",
                    "title": "Float32 doc two",
                    "embedding": array_to_buffer([0.2, 0.3, 0.4, 0.5], "float32"),
                },
                {
                    "doc_id": "3",
                    "title": "Float32 doc three",
                    "embedding": array_to_buffer([0.3, 0.4, 0.5, 0.6], "float32"),
                },
            ],
        )

        try:
            # Add 2 docs with float16 vectors (8 bytes for 4 dims vs 16 bytes)
            # These will fail to index under float32 schema due to wrong byte size
            f16_vec = array_to_buffer([0.4, 0.5, 0.6, 0.7], "float16")
            client.hset(
                f"{unique_ids['prefix']}:f16_1",
                mapping={"title": "Float16 doc one", "embedding": f16_vec},
            )
            client.hset(
                f"{unique_ids['prefix']}:f16_2",
                mapping={"title": "Float16 doc two", "embedding": f16_vec},
            )

            # Verify initial state: 3 indexed docs plus failed vector events.
            num_docs, failures = wait_for_indexing_state(
                index, expected_docs=3, min_failures=2
            )
            assert num_docs == 3, f"Expected 3 indexed docs, got {num_docs}"
            assert (
                failures >= 2
            ), f"Expected at least 2 indexing failures, got {failures}"

            # Run quantization migration: float32 -> float16
            # The executor re-encodes the 3 float32 docs to float16.
            # After re-indexing, the 2 previously-failed float16 docs should now
            # index successfully. Total keys: 5 before and 5 after.
            result = run_migration(
                redis_url,
                tmp_path,
                unique_ids["name"],
                {
                    "version": 1,
                    "changes": {
                        "update_fields": [
                            {"name": "embedding", "attrs": {"datatype": "float16"}}
                        ],
                    },
                },
            )

            assert result["supported"], "Quantization should be supported"
            assert result[
                "succeeded"
            ], f"Migration failed: {result['validation_errors']}"
            assert result["doc_count_match"], (
                f"Doc count should match (total keys conserved). "
                f"Errors: {result['validation_errors']}"
            )

            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise

    def test_planner_warns_about_indexing_failures(
        self, redis_url, tmp_path, unique_ids, client
    ):
        """Planner should emit a warning when source has hash_indexing_failures."""
        schema = {
            "index": {
                "name": unique_ids["name"],
                "prefix": unique_ids["prefix"],
                "storage_type": "hash",
            },
            "fields": [
                {"name": "title", "type": "text"},
                {
                    "name": "embedding",
                    "type": "vector",
                    "attrs": {
                        "algorithm": "flat",
                        "dims": 4,
                        "distance_metric": "cosine",
                        "datatype": "float32",
                    },
                },
            ],
        }

        index = setup_index(
            redis_url,
            schema,
            [
                {
                    "doc_id": "1",
                    "title": "Good doc",
                    "embedding": array_to_buffer([0.1, 0.2, 0.3, 0.4], "float32"),
                },
            ],
        )

        try:
            # Add a doc with wrong-dimension vector
            bad_vec = array_to_buffer([0.1, 0.2], "float32")  # 2-dim instead of 4
            client.hset(
                f"{unique_ids['prefix']}:bad1",
                mapping={"title": "Bad doc", "embedding": bad_vec},
            )

            import time

            time.sleep(0.5)

            # Verify we have failures
            info = index.info()
            failures = int(info.get("hash_indexing_failures", 0))
            assert failures > 0, "Expected at least 1 indexing failure"

            # Create plan and check for warning
            patch_path = tmp_path / "patch.yaml"
            patch_path.write_text(
                yaml.safe_dump(
                    {
                        "version": 1,
                        "changes": {
                            "add_fields": [{"name": "status", "type": "tag"}],
                        },
                    },
                    sort_keys=False,
                )
            )

            planner = MigrationPlanner()
            plan = planner.create_plan(
                unique_ids["name"],
                redis_url=redis_url,
                schema_patch_path=str(patch_path),
            )

            failure_warnings = [
                w for w in plan.warnings if "hash indexing failure" in w
            ]
            assert len(failure_warnings) == 1, (
                f"Expected 1 indexing failure warning, got {len(failure_warnings)}. "
                f"All warnings: {plan.warnings}"
            )

            cleanup_index(index)
        except Exception:
            cleanup_index(index)
            raise


# ==============================================================================
# 11. Backup Directory Creation
# ==============================================================================


def _build_plan(redis_url, tmp_path, index_name, patch):
    """Build and persist a migration plan, returning the loaded plan."""
    patch_path = tmp_path / "patch.yaml"
    patch_path.write_text(yaml.safe_dump(patch, sort_keys=False))
    plan_path = tmp_path / "plan.yaml"
    planner = MigrationPlanner()
    plan = planner.create_plan(
        index_name, redis_url=redis_url, schema_patch_path=str(patch_path)
    )
    planner.write_plan(plan, str(plan_path))
    return load_migration_plan(str(plan_path))


QUANTIZE_PATCH = {
    "version": 1,
    "changes": {
        "update_fields": [{"name": "embedding", "attrs": {"datatype": "float16"}}]
    },
}

ADD_FIELD_PATCH = {
    "version": 1,
    "changes": {"add_fields": [{"name": "new_tag", "type": "tag"}]},
}


class TestBackupDirectoryCreation:
    """The executor must create the backup directory before migrating, for any
    migration mode, and fail fast with a clear error when it cannot."""

    def test_quantization_creates_missing_backup_dir(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """A quantization migration creates a missing (nested) backup dir and
        writes the backup files there."""
        index = setup_index(redis_url, base_schema, sample_docs)
        backup_dir = tmp_path / "nested" / "backups"
        assert not backup_dir.exists()
        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], QUANTIZE_PATCH
            )
            report = MigrationExecutor().apply(
                plan, redis_url=redis_url, backup_dir=str(backup_dir)
            )

            assert report.result == "succeeded", report.validation.errors
            assert report.backup is not None
            assert report.backup.backup_dir == str(backup_dir.resolve())
            assert report.backup.backup_paths
            assert backup_dir.is_dir()
            assert glob.glob(os.path.join(str(backup_dir), "*.header"))
            assert glob.glob(os.path.join(str(backup_dir), "*.data"))
        finally:
            cleanup_index(index)

    def test_stale_completed_backup_restarts_when_live_index_is_source_schema(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """A retained completed backup must not skip a fresh source index.

        This can happen after rollback/recovery: the backup header says the
        previous migration completed, but the live index has been restored to
        the original source schema. Applying the same plan with the same
        backup_dir must restart the migration instead of treating the stale
        backup as a no-op resume.
        """
        index = setup_index(redis_url, base_schema, sample_docs)
        backup_dir = tmp_path / "backups"

        def embedding_dtype() -> str:
            live = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            field = next(
                f for f in live.schema.to_dict()["fields"] if f["name"] == "embedding"
            )
            return field["attrs"]["datatype"]

        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], QUANTIZE_PATCH
            )
            first_report = MigrationExecutor().apply(
                plan, redis_url=redis_url, backup_dir=str(backup_dir)
            )
            assert first_report.result == "succeeded", first_report.validation.errors
            assert embedding_dtype() == "float16"

            # Simulate rollback/recovery while retaining the completed backup.
            migrated = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            migrated.delete(drop=True)
            index = setup_index(redis_url, base_schema, sample_docs)
            assert embedding_dtype() == "float32"
            assert glob.glob(os.path.join(str(backup_dir), "*.header"))

            second_report = MigrationExecutor().apply(
                plan, redis_url=redis_url, backup_dir=str(backup_dir)
            )

            assert second_report.result == "succeeded", second_report.validation.errors
            assert second_report.validation.schema_match is True
            assert embedding_dtype() == "float16"
        finally:
            cleanup_index(index)

    def test_non_quantization_creates_missing_backup_dir(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """A non-quantization migration still creates a missing backup dir when
        one is provided (no backup files are written)."""
        index = setup_index(redis_url, base_schema, sample_docs)
        backup_dir = tmp_path / "nested" / "no_quant"
        assert not backup_dir.exists()
        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], ADD_FIELD_PATCH
            )
            report = MigrationExecutor().apply(
                plan, redis_url=redis_url, backup_dir=str(backup_dir)
            )

            assert report.result == "succeeded", report.validation.errors
            assert report.backup is not None
            assert report.backup.backup_dir == str(backup_dir.resolve())
            assert report.backup.backup_paths == []
            assert backup_dir.is_dir()
            assert not glob.glob(os.path.join(str(backup_dir), "*.header"))
        finally:
            cleanup_index(index)

    def test_non_quantization_without_backup_dir_raises_before_migrating(
        self, redis_url, tmp_path, base_schema, sample_docs, monkeypatch
    ):
        """A non-quantization migration without backup_dir fails before the
        index is touched."""
        index = setup_index(redis_url, base_schema, sample_docs)
        monkeypatch.chdir(tmp_path)
        implied_dir = tmp_path / "migration_backups"
        assert not implied_dir.exists()
        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], ADD_FIELD_PATCH
            )
            with pytest.raises(ValueError, match="backup directory is required"):
                MigrationExecutor().apply(plan, redis_url=redis_url)

            assert not implied_dir.exists()
            live = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            assert live.info()["num_docs"] == len(sample_docs)
        finally:
            cleanup_index(index)

    def test_quantization_without_backup_dir_raises_before_migrating(
        self, redis_url, tmp_path, base_schema, sample_docs, monkeypatch
    ):
        """A quantization migration without backup_dir fails before the index
        is touched."""
        index = setup_index(redis_url, base_schema, sample_docs)
        monkeypatch.chdir(tmp_path)
        implied_dir = tmp_path / "migration_backups"
        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], QUANTIZE_PATCH
            )
            with pytest.raises(ValueError, match="backup directory is required"):
                MigrationExecutor().apply(plan, redis_url=redis_url)

            assert not implied_dir.exists()
            live = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            assert live.info()["num_docs"] == len(sample_docs)
        finally:
            cleanup_index(index)

    def test_quantization_unwritable_backup_dir_raises_clear_error(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """A quantization migration with an un-createable backup dir fails fast
        with a clear ValueError before the index is touched."""
        index = setup_index(redis_url, base_schema, sample_docs)
        blocker = tmp_path / "blocker"
        blocker.write_text("not a directory")
        backup_dir = blocker / "sub"
        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], QUANTIZE_PATCH
            )
            with pytest.raises(ValueError, match="backup directory"):
                MigrationExecutor().apply(
                    plan, redis_url=redis_url, backup_dir=str(backup_dir)
                )

            live = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            assert live.info()["num_docs"] == len(sample_docs)
        finally:
            cleanup_index(index)

    def test_unwritable_backup_dir_raises_clear_error(
        self, redis_url, tmp_path, base_schema, sample_docs
    ):
        """An un-createable backup dir fails fast with a clear ValueError before
        the index is touched."""
        index = setup_index(redis_url, base_schema, sample_docs)
        blocker = tmp_path / "blocker"
        blocker.write_text("not a directory")
        backup_dir = blocker / "sub"
        try:
            plan = _build_plan(
                redis_url, tmp_path, base_schema["index"]["name"], ADD_FIELD_PATCH
            )
            with pytest.raises(ValueError, match="backup directory"):
                MigrationExecutor().apply(
                    plan, redis_url=redis_url, backup_dir=str(backup_dir)
                )

            # Index must be untouched (fail-fast before any mutation).
            live = SearchIndex.from_existing(
                base_schema["index"]["name"], redis_url=redis_url
            )
            assert live.info()["num_docs"] == len(sample_docs)
        finally:
            cleanup_index(index)
