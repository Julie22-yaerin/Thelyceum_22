# Defining your schema
