#[cfg(test)]
mod tests {
    use std::cmp::Ordering;

    use proptest::prelude::*;

    use crate::collector::TopDocs;
    use crate::fastfield::AliveBitSet;
    use crate::index::Index;
    use crate::postings::Postings;
    use crate::query::QueryParser;
    use crate::schema::{
        self, BytesOptions, Facet, FacetOptions, IndexRecordOption, NumericOptions,
        TextFieldIndexing, TextOptions, Value, FAST, STRING,
    };
    use crate::{
        DocAddress, DocSet, IndexSettings, IndexSortByField, IndexWriter, Order, TantivyDocument,
        Term,
    };

    fn create_test_index_posting_list_issue(index_settings: Option<IndexSettings>) -> Index {
        let mut schema_builder = schema::Schema::builder();
        let int_options = NumericOptions::default().set_fast().set_indexed();
        let int_field = schema_builder.add_u64_field("intval", int_options);

        let facet_field = schema_builder.add_facet_field("facet", FacetOptions::default());

        let schema = schema_builder.build();

        let mut index_builder = Index::builder().schema(schema);
        if let Some(settings) = index_settings {
            index_builder = index_builder.settings(settings);
        }
        let index = index_builder.create_in_ram().unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer
                .add_document(doc!(int_field=>3_u64, facet_field=> Facet::from("/crime")))
                .unwrap();
            index_writer
                .add_document(doc!(int_field=>6_u64, facet_field=> Facet::from("/crime")))
                .unwrap();
            index_writer.commit().unwrap();
            index_writer
                .add_document(doc!(int_field=>5_u64, facet_field=> Facet::from("/fanta")))
                .unwrap();
            index_writer.commit().unwrap();
        }

        // Merging the segments
        {
            let segment_ids = index
                .searchable_segment_ids()
                .expect("Searchable segments failed.");
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            assert!(index_writer.merge(&segment_ids).wait().is_ok());
            assert!(index_writer.wait_merging_threads().is_ok());
        }
        index
    }

    // force_disjunct_segment_sort_values forces the field, by which the index is sorted have
    // disjunct ranges between segments, e.g. values in segment [1-3] [10 - 20] [50 - 500]
    fn create_test_index(
        index_settings: Option<IndexSettings>,
        force_disjunct_segment_sort_values: bool,
    ) -> crate::Result<Index> {
        let mut schema_builder = schema::Schema::builder();
        let int_options = NumericOptions::default()
            .set_fast()
            .set_stored()
            .set_indexed();
        let int_field = schema_builder.add_u64_field("intval", int_options);

        let bytes_options = BytesOptions::default().set_fast().set_indexed();
        let bytes_field = schema_builder.add_bytes_field("bytes", bytes_options);
        let facet_field = schema_builder.add_facet_field("facet", FacetOptions::default());

        let multi_numbers =
            schema_builder.add_u64_field("multi_numbers", NumericOptions::default().set_fast());
        let text_field_options = TextOptions::default()
            .set_indexing_options(
                TextFieldIndexing::default()
                    .set_index_option(schema::IndexRecordOption::WithFreqsAndPositions),
            )
            .set_stored();
        let text_field = schema_builder.add_text_field("text_field", text_field_options);
        let schema = schema_builder.build();

        let mut index_builder = Index::builder().schema(schema);
        if let Some(settings) = index_settings {
            index_builder = index_builder.settings(settings);
        }
        let index = index_builder.create_in_ram()?;

        {
            let mut index_writer = index.writer_for_tests()?;

            // segment 1 - range 1-3
            index_writer.add_document(doc!(int_field=>1_u64))?;
            index_writer.add_document(
                doc!(int_field=>3_u64, multi_numbers => 3_u64, multi_numbers => 4_u64, bytes_field => vec![1, 2, 3], text_field => "some text", facet_field=> Facet::from("/book/crime")),
            )?;
            index_writer.add_document(
                doc!(int_field=>1_u64, text_field=> "deleteme",  text_field => "ok text more text"),
            )?;
            index_writer.add_document(
                doc!(int_field=>2_u64, multi_numbers => 2_u64, multi_numbers => 3_u64, text_field => "ok text more text"),
            )?;

            index_writer.commit()?;
            // segment 2 - range 1-20 , with force_disjunct_segment_sort_values 10-20
            index_writer.add_document(doc!(int_field=>20_u64, multi_numbers => 20_u64))?;

            let in_val = if force_disjunct_segment_sort_values {
                10_u64
            } else {
                1
            };
            index_writer.add_document(doc!(int_field=>in_val, text_field=> "deleteme" , text_field => "ok text more text", facet_field=> Facet::from("/book/crime")))?;
            index_writer.commit()?;
            // segment 3 - range 5-1000, with force_disjunct_segment_sort_values 50-1000
            let int_vals = if force_disjunct_segment_sort_values {
                [100_u64, 50]
            } else {
                [10, 5]
            };
            index_writer.add_document( // position of this doc after delete in desc sorting = [2], in disjunct case [1]
                doc!(int_field=>int_vals[0], multi_numbers => 10_u64, multi_numbers => 11_u64, text_field=> "blubber", facet_field=> Facet::from("/book/fantasy")),
            )?;
            index_writer.add_document(doc!(int_field=>int_vals[1], text_field=> "deleteme"))?;
            index_writer.add_document(
                doc!(int_field=>1_000u64, multi_numbers => 1001_u64, multi_numbers => 1002_u64, bytes_field => vec![5, 5],text_field => "the biggest num")
            )?;

            index_writer.delete_term(Term::from_field_text(text_field, "deleteme"));
            index_writer.commit()?;
        }

        // Merging the segments
        {
            let segment_ids = index.searchable_segment_ids()?;
            let mut index_writer: IndexWriter = index.writer_for_tests()?;
            index_writer.merge(&segment_ids).wait()?;
            index_writer.wait_merging_threads()?;
        }
        Ok(index)
    }

    #[test]
    fn test_merge_sorted_postinglist_sort_issue() {
        create_test_index_posting_list_issue(Some(IndexSettings {
            sort_by_field: Some(IndexSortByField {
                field: "intval".to_string(),
                order: Order::Desc,
            }),
            ..Default::default()
        }));
    }

    #[test]
    fn test_merge_sorted_index_desc_not_disjunct() {
        test_merge_sorted_index_desc_(false);
    }

    #[test]
    fn test_merge_sorted_index_desc_disjunct() {
        test_merge_sorted_index_desc_(true);
    }

    fn test_merge_sorted_index_desc_(force_disjunct_segment_sort_values: bool) {
        let index = create_test_index(
            Some(IndexSettings {
                sort_by_field: Some(IndexSortByField {
                    field: "intval".to_string(),
                    order: Order::Desc,
                }),
                ..Default::default()
            }),
            force_disjunct_segment_sort_values,
        )
        .unwrap();

        let int_field = index.schema().get_field("intval").unwrap();
        let reader = index.reader().unwrap();

        let searcher = reader.searcher();
        assert_eq!(searcher.segment_readers().len(), 1);
        let segment_reader = searcher.segment_readers().last().unwrap();

        let fast_fields = segment_reader.fast_fields();
        let fast_field = fast_fields.u64("intval").unwrap();
        assert_eq!(fast_field.first(5), Some(1u64));
        assert_eq!(fast_field.first(4), Some(2u64));
        assert_eq!(fast_field.first(3), Some(3u64));
        if force_disjunct_segment_sort_values {
            assert_eq!(fast_field.first(2), Some(20u64));
            assert_eq!(fast_field.first(1), Some(100u64));
        } else {
            assert_eq!(fast_field.first(2), Some(10u64));
            assert_eq!(fast_field.first(1), Some(20u64));
        }
        assert_eq!(fast_field.first(0), Some(1_000u64));

        // test new field norm mapping
        {
            let my_text_field = index.schema().get_field("text_field").unwrap();
            let fieldnorm_reader = segment_reader.get_fieldnorms_reader(my_text_field).unwrap();
            assert_eq!(fieldnorm_reader.fieldnorm(0), 3); // the biggest num
            if force_disjunct_segment_sort_values {
                assert_eq!(fieldnorm_reader.fieldnorm(1), 1); // blubber
                assert_eq!(fieldnorm_reader.fieldnorm(2), 0);
            } else {
                assert_eq!(fieldnorm_reader.fieldnorm(1), 0);
                assert_eq!(fieldnorm_reader.fieldnorm(2), 1); // blubber
            }
            assert_eq!(fieldnorm_reader.fieldnorm(3), 2); // some text
            assert_eq!(fieldnorm_reader.fieldnorm(5), 0);
        }

        let my_text_field = index.schema().get_field("text_field").unwrap();
        let searcher = index.reader().unwrap().searcher();
        {
            let my_text_field = index.schema().get_field("text_field").unwrap();

            let do_search = |term: &str| {
                let query = QueryParser::for_index(&index, vec![my_text_field])
                    .parse_query(term)
                    .unwrap();
                let top_docs: Vec<(f32, DocAddress)> = searcher
                    .search(&query, &TopDocs::with_limit(3).order_by_score())
                    .unwrap();

                top_docs.iter().map(|el| el.1.doc_id).collect::<Vec<_>>()
            };

            assert_eq!(do_search("some"), vec![3]);
            if force_disjunct_segment_sort_values {
                assert_eq!(do_search("blubber"), vec![1]);
            } else {
                assert_eq!(do_search("blubber"), vec![2]);
            }
            assert_eq!(do_search("biggest"), vec![0]);
        }

        // postings file
        {
            let my_text_field = index.schema().get_field("text_field").unwrap();
            let term_a = Term::from_field_text(my_text_field, "text");
            let inverted_index = segment_reader.inverted_index(my_text_field).unwrap();
            let mut postings = inverted_index
                .read_postings(&term_a, IndexRecordOption::WithFreqsAndPositions)
                .unwrap()
                .unwrap();

            assert_eq!(postings.doc_freq(), 2);
            let fallback_bitset = AliveBitSet::for_test_from_deleted_docs(&[0], 100);
            assert_eq!(
                postings.doc_freq_given_deletes(
                    segment_reader.alive_bitset().unwrap_or(&fallback_bitset)
                ),
                2
            );

            assert_eq!(postings.term_freq(), 1);
            let mut output = vec![];
            postings.positions(&mut output);
            assert_eq!(output, vec![1]);
            postings.advance();

            assert_eq!(postings.term_freq(), 2);
            postings.positions(&mut output);
            assert_eq!(output, vec![1, 3]);
        }

        // access doc store
        {
            let blubber_pos = if force_disjunct_segment_sort_values {
                1
            } else {
                2
            };
            let doc = searcher
                .doc::<TantivyDocument>(DocAddress::new(0, blubber_pos))
                .unwrap();
            assert_eq!(
                doc.get_first(my_text_field).unwrap().as_value().as_str(),
                Some("blubber")
            );
            let doc = searcher
                .doc::<TantivyDocument>(DocAddress::new(0, 0))
                .unwrap();
            assert_eq!(
                doc.get_first(int_field).unwrap().as_value().as_u64(),
                Some(1000)
            );
        }
    }

    #[test]
    fn test_merge_unsorted_index() {
        let index = create_test_index(
            Some(IndexSettings {
                ..Default::default()
            }),
            false,
        )
        .unwrap();

        let reader = index.reader().unwrap();
        let searcher = reader.searcher();
        assert_eq!(searcher.segment_readers().len(), 1);
        let segment_reader = searcher.segment_readers().last().unwrap();

        let searcher = index.reader().unwrap().searcher();
        {
            let my_text_field = index.schema().get_field("text_field").unwrap();

            let do_search = |term: &str| {
                let query = QueryParser::for_index(&index, vec![my_text_field])
                    .parse_query(term)
                    .unwrap();
                let top_docs: Vec<(f32, DocAddress)> = searcher
                    .search(&query, &TopDocs::with_limit(3).order_by_score())
                    .unwrap();

                top_docs.iter().map(|el| el.1.doc_id).collect::<Vec<_>>()
            };

            assert_eq!(do_search("some"), vec![1]);
            assert_eq!(do_search("blubber"), vec![3]);
            assert_eq!(do_search("biggest"), vec![4]);
        }

        // postings file
        {
            let my_text_field = index.schema().get_field("text_field").unwrap();
            let term_a = Term::from_field_text(my_text_field, "text");
            let inverted_index = segment_reader.inverted_index(my_text_field).unwrap();
            let mut postings = inverted_index
                .read_postings(&term_a, IndexRecordOption::WithFreqsAndPositions)
                .unwrap()
                .unwrap();
            assert_eq!(postings.doc_freq(), 2);
            let fallback_bitset = AliveBitSet::for_test_from_deleted_docs(&[0], 100);
            assert_eq!(
                postings.doc_freq_given_deletes(
                    segment_reader.alive_bitset().unwrap_or(&fallback_bitset)
                ),
                2
            );

            assert_eq!(postings.term_freq(), 1);
            let mut output = vec![];
            postings.positions(&mut output);
            assert_eq!(output, vec![1]);
            postings.advance();

            assert_eq!(postings.term_freq(), 2);
            postings.positions(&mut output);
            assert_eq!(output, vec![1, 3]);
        }
    }

    // ---- Str/Bytes sort_by helpers ----

    fn build_str_sorted_index(order: Order, segments: Vec<Vec<Option<&str>>>) -> Index {
        let segments = segments
            .into_iter()
            .map(|segment| {
                segment
                    .into_iter()
                    .map(|value| value.map(str::to_owned))
                    .collect()
            })
            .collect();
        build_str_sorted_index_owned(order, segments)
    }

    fn build_str_sorted_index_owned(order: Order, segments: Vec<Vec<Option<String>>>) -> Index {
        let mut schema_builder = schema::Schema::builder();
        let str_field = schema_builder.add_text_field("str", STRING | FAST);
        let schema = schema_builder.build();

        let index_builder = Index::builder().schema(schema).settings(IndexSettings {
            sort_by_field: Some(IndexSortByField {
                field: "str".to_string(),
                order,
            }),
            ..Default::default()
        });
        let index = index_builder.create_in_ram().unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            for segment in segments {
                for value in segment {
                    let mut doc = TantivyDocument::new();
                    if let Some(val) = value {
                        doc.add_text(str_field, val);
                    }
                    index_writer.add_document(doc).unwrap();
                }
                index_writer.commit().unwrap();
            }
        }

        {
            let segment_ids = index.searchable_segment_ids().unwrap();
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer.merge(&segment_ids).wait().unwrap();
            index_writer.wait_merging_threads().unwrap();
        }
        index
    }

    fn build_bytes_sorted_index(order: Order, segments: Vec<Vec<Option<&[u8]>>>) -> Index {
        let segments = segments
            .into_iter()
            .map(|segment| {
                segment
                    .into_iter()
                    .map(|value| value.map(<[u8]>::to_vec))
                    .collect()
            })
            .collect();
        build_bytes_sorted_index_owned(order, segments)
    }

    fn build_bytes_sorted_index_owned(order: Order, segments: Vec<Vec<Option<Vec<u8>>>>) -> Index {
        let mut schema_builder = schema::Schema::builder();
        let bytes_field = schema_builder
            .add_bytes_field("bytes", BytesOptions::default().set_fast().set_indexed());
        let schema = schema_builder.build();

        let index_builder = Index::builder().schema(schema).settings(IndexSettings {
            sort_by_field: Some(IndexSortByField {
                field: "bytes".to_string(),
                order,
            }),
            ..Default::default()
        });
        let index = index_builder.create_in_ram().unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            for segment in segments {
                for value in segment {
                    let mut doc = TantivyDocument::new();
                    if let Some(val) = value {
                        doc.add_bytes(bytes_field, &val);
                    }
                    index_writer.add_document(doc).unwrap();
                }
                index_writer.commit().unwrap();
            }
        }

        {
            let segment_ids = index.searchable_segment_ids().unwrap();
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer.merge(&segment_ids).wait().unwrap();
            index_writer.wait_merging_threads().unwrap();
        }
        index
    }

    fn collect_str_values(index: &Index) -> Vec<Option<String>> {
        let reader = index.reader().unwrap();
        let searcher = reader.searcher();
        assert_eq!(searcher.segment_readers().len(), 1);
        let segment_reader = searcher.segment_readers().last().unwrap();
        let str_col = segment_reader.fast_fields().str("str").unwrap().unwrap();
        let mut values = Vec::new();
        for doc in 0..segment_reader.max_doc() {
            if let Some(ord) = str_col.ords().first(doc) {
                let mut s = String::new();
                str_col.ord_to_str(ord, &mut s).unwrap();
                values.push(Some(s));
            } else {
                values.push(None);
            }
        }
        values
    }

    fn collect_bytes_values(index: &Index) -> Vec<Option<Vec<u8>>> {
        let reader = index.reader().unwrap();
        let searcher = reader.searcher();
        assert_eq!(searcher.segment_readers().len(), 1);
        let segment_reader = searcher.segment_readers().last().unwrap();
        let bytes_col = segment_reader
            .fast_fields()
            .bytes("bytes")
            .unwrap()
            .unwrap();
        let mut values = Vec::new();
        for doc in 0..segment_reader.max_doc() {
            if let Some(ord) = bytes_col.ords().first(doc) {
                let mut buf = Vec::new();
                bytes_col.ord_to_bytes(ord, &mut buf).unwrap();
                values.push(Some(buf));
            } else {
                values.push(None);
            }
        }
        values
    }

    fn compare_option_values<T: Ord>(
        left: &Option<T>,
        right: &Option<T>,
        order: Order,
    ) -> Ordering {
        match (left, right) {
            (None, None) => Ordering::Equal,
            (None, Some(_)) => {
                if order.is_asc() {
                    Ordering::Less
                } else {
                    Ordering::Greater
                }
            }
            (Some(_), None) => {
                if order.is_asc() {
                    Ordering::Greater
                } else {
                    Ordering::Less
                }
            }
            (Some(left), Some(right)) => {
                if order.is_asc() {
                    left.cmp(right)
                } else {
                    right.cmp(left)
                }
            }
        }
    }

    // ---- Single-segment sort ----

    #[test]
    fn test_single_segment_str_sorted() {
        // Insert out of order into a single segment.
        // Read back and verify the segment itself is sorted — no merge involved.
        let mut schema_builder = schema::Schema::builder();
        let str_field = schema_builder.add_text_field("str", STRING | FAST);
        let schema = schema_builder.build();

        let index = Index::builder()
            .schema(schema)
            .settings(IndexSettings {
                sort_by_field: Some(IndexSortByField {
                    field: "str".to_string(),
                    order: Order::Asc,
                }),
                ..Default::default()
            })
            .create_in_ram()
            .unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer.add_document(doc!(str_field => "z")).unwrap();
            index_writer.add_document(doc!(str_field => "a")).unwrap();
            index_writer.add_document(doc!(str_field => "m")).unwrap();
            index_writer.commit().unwrap();
        }

        // No merge — read the single segment directly.
        let values = collect_str_values(&index);
        assert_eq!(
            values,
            vec![
                Some("a".to_string()),
                Some("m".to_string()),
                Some("z".to_string())
            ]
        );
    }

    // ---- Cross-segment merge: Str ----

    #[test]
    fn test_merge_sorted_index_str_asc() {
        // Segment A: ["z", "a"] (out of order — proves per-segment sorting).
        // Segment B: ["m", "b"] (also out of order).
        // If per-segment sorting failed, kmerge would see unsorted streams.
        // If the disjunct shortcut fired, it would stack segments without re-sorting.
        // Correct merged order is ["a","b","m","z"].
        let index = build_str_sorted_index(
            Order::Asc,
            vec![vec![Some("z"), Some("a")], vec![Some("m"), Some("b")]],
        );
        let values = collect_str_values(&index);
        assert_eq!(
            values,
            vec![
                Some("a".to_string()),
                Some("b".to_string()),
                Some("m".to_string()),
                Some("z".to_string())
            ]
        );
    }

    #[test]
    fn test_merge_sorted_index_str_desc() {
        let index = build_str_sorted_index(
            Order::Desc,
            vec![vec![Some("z"), None], vec![Some("m"), Some("a")]],
        );
        let values = collect_str_values(&index);
        assert_eq!(
            values,
            vec![
                Some("z".to_string()),
                Some("m".to_string()),
                Some("a".to_string()),
                None
            ]
        );
    }

    #[test]
    fn test_merge_sorted_index_str_missing_values() {
        // Second segment has no values for the sort field.
        let index = build_str_sorted_index(
            Order::Asc,
            vec![vec![Some("b"), Some("c")], vec![None, None]],
        );
        let values = collect_str_values(&index);
        assert_eq!(
            values,
            vec![None, None, Some("b".to_string()), Some("c".to_string())]
        );
    }

    #[test]
    fn test_merge_sorted_index_str_with_deletes() {
        let mut schema_builder = schema::Schema::builder();
        let str_field = schema_builder.add_text_field("str", STRING | FAST);
        let schema = schema_builder.build();

        let index_builder = Index::builder().schema(schema).settings(IndexSettings {
            sort_by_field: Some(IndexSortByField {
                field: "str".to_string(),
                order: Order::Asc,
            }),
            ..Default::default()
        });
        let index = index_builder.create_in_ram().unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            // Segment 1 (with a delete)
            index_writer.add_document(doc!(str_field => "z")).unwrap();
            index_writer
                .add_document(doc!(str_field => "deleteme"))
                .unwrap();
            index_writer.delete_term(Term::from_field_text(str_field, "deleteme"));
            index_writer.commit().unwrap();

            index_writer.add_document(doc!(str_field => "a")).unwrap();
            index_writer.add_document(doc!(str_field => "m")).unwrap();
            index_writer.commit().unwrap();
        }

        {
            let segment_ids = index.searchable_segment_ids().unwrap();
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer.merge(&segment_ids).wait().unwrap();
            index_writer.wait_merging_threads().unwrap();
        }

        let values = collect_str_values(&index);
        assert_eq!(
            values,
            vec![
                Some("a".to_string()),
                Some("m".to_string()),
                Some("z".to_string())
            ]
        );
    }

    // ---- Cross-segment merge: Bytes ----

    #[test]
    fn test_merge_sorted_index_bytes_asc() {
        let index = build_bytes_sorted_index(
            Order::Asc,
            vec![
                vec![Some(&[0x02][..]), Some(&[0x01][..])],
                vec![Some(&[0x00][..])],
            ],
        );
        let values = collect_bytes_values(&index);
        assert_eq!(
            values,
            vec![Some(vec![0x00]), Some(vec![0x01]), Some(vec![0x02])]
        );
    }

    #[test]
    fn test_merge_sorted_index_bytes_desc() {
        let index = build_bytes_sorted_index(
            Order::Desc,
            vec![
                vec![Some(&[0x02][..]), None],
                vec![Some(&[0x01][..]), Some(&[0x00][..])],
            ],
        );
        let values = collect_bytes_values(&index);
        assert_eq!(
            values,
            vec![Some(vec![0x02]), Some(vec![0x01]), Some(vec![0x00]), None]
        );
    }

    #[test]
    fn test_merge_sorted_index_bytes_missing_values() {
        // Second segment has no values for the sort field.
        let index = build_bytes_sorted_index(
            Order::Asc,
            vec![vec![Some(&[0x01][..]), Some(&[0x02][..])], vec![None, None]],
        );
        let values = collect_bytes_values(&index);
        assert_eq!(values, vec![None, None, Some(vec![0x01]), Some(vec![0x02])]);
    }

    #[test]
    fn test_merge_sorted_index_bytes_with_deletes() {
        let mut schema_builder = schema::Schema::builder();
        let bytes_field = schema_builder
            .add_bytes_field("bytes", BytesOptions::default().set_fast().set_indexed());
        let schema = schema_builder.build();

        let index_builder = Index::builder().schema(schema).settings(IndexSettings {
            sort_by_field: Some(IndexSortByField {
                field: "bytes".to_string(),
                order: Order::Asc,
            }),
            ..Default::default()
        });
        let index = index_builder.create_in_ram().unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            // Segment 1 (with a delete)
            index_writer
                .add_document(doc!(bytes_field => vec![0x02]))
                .unwrap();
            index_writer
                .add_document(doc!(bytes_field => vec![0x01]))
                .unwrap();
            index_writer.delete_term(Term::from_field_bytes(bytes_field, &[0x01]));
            index_writer.commit().unwrap();

            index_writer
                .add_document(doc!(bytes_field => vec![0x00]))
                .unwrap();
            index_writer.commit().unwrap();
        }

        {
            let segment_ids = index.searchable_segment_ids().unwrap();
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer.merge(&segment_ids).wait().unwrap();
            index_writer.wait_merging_threads().unwrap();
        }

        let values = collect_bytes_values(&index);
        assert_eq!(values, vec![Some(vec![0x00]), Some(vec![0x02])]);
    }

    proptest! {
        #[test]
        fn test_merge_sorted_index_str_matches_sorted_input(
            order in prop_oneof![Just(Order::Asc), Just(Order::Desc)],
            segments in proptest::collection::vec(
                proptest::collection::vec(proptest::option::of("[a-z]{0,8}"), 1..8),
                1..6,
            )
        ) {
            let index = build_str_sorted_index_owned(order, segments.clone());
            let values = collect_str_values(&index);
            let mut expected: Vec<Option<String>> = segments.into_iter().flatten().collect();
            expected.sort_by(|left, right| compare_option_values(left, right, order));
            prop_assert_eq!(values, expected);
        }

        #[test]
        fn test_merge_sorted_index_bytes_matches_sorted_input(
            order in prop_oneof![Just(Order::Asc), Just(Order::Desc)],
            segments in proptest::collection::vec(
                proptest::collection::vec(
                    proptest::option::of(proptest::collection::vec(any::<u8>(), 0..8)),
                    1..8,
                ),
                1..6,
            )
        ) {
            let index = build_bytes_sorted_index_owned(order, segments.clone());
            let values = collect_bytes_values(&index);
            let mut expected: Vec<Option<Vec<u8>>> = segments.into_iter().flatten().collect();
            expected.sort_by(|left, right| compare_option_values(left, right, order));
            prop_assert_eq!(values, expected);
        }
    }

    // ---- Cross-segment merge: numeric u64 with NULLs ----

    fn build_u64_sorted_index(order: Order, segments: Vec<Vec<Option<u64>>>) -> Index {
        let mut schema_builder = schema::Schema::builder();
        let int_field = schema_builder
            .add_u64_field("intval", NumericOptions::default().set_fast().set_indexed());
        let schema = schema_builder.build();

        let index = Index::builder()
            .schema(schema)
            .settings(IndexSettings {
                sort_by_field: Some(IndexSortByField {
                    field: "intval".to_string(),
                    order,
                }),
                ..Default::default()
            })
            .create_in_ram()
            .unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            for segment in segments {
                for value in segment {
                    let mut doc = TantivyDocument::new();
                    if let Some(v) = value {
                        doc.add_u64(int_field, v);
                    }
                    index_writer.add_document(doc).unwrap();
                }
                index_writer.commit().unwrap();
            }
        }

        {
            let segment_ids = index.searchable_segment_ids().unwrap();
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            index_writer.merge(&segment_ids).wait().unwrap();
            index_writer.wait_merging_threads().unwrap();
        }
        index
    }

    fn collect_u64_values(index: &Index) -> Vec<Option<u64>> {
        let reader = index.reader().unwrap();
        let searcher = reader.searcher();
        assert_eq!(searcher.segment_readers().len(), 1);
        let segment_reader = searcher.segment_readers().last().unwrap();
        let u64_col = segment_reader.fast_fields().u64("intval").unwrap();
        let mut values = Vec::new();
        for doc in 0..segment_reader.max_doc() {
            values.push(u64_col.first(doc));
        }
        values
    }

    #[test]
    fn test_merge_sorted_index_u64_asc_null_before_zero() {
        let index =
            build_u64_sorted_index(Order::Asc, vec![vec![None, Some(0)], vec![None, Some(0)]]);
        let values = collect_u64_values(&index);
        assert_eq!(values, vec![None, None, Some(0), Some(0)]);
    }

    #[test]
    fn test_merge_sorted_index_u64_desc_null_after_zero() {
        let index =
            build_u64_sorted_index(Order::Desc, vec![vec![Some(0), None], vec![Some(0), None]]);
        let values = collect_u64_values(&index);
        assert_eq!(values, vec![Some(0), Some(0), None, None]);
    }

    #[test]
    fn test_merge_sorted_index_u64_asc_nulls_only_in_first_segment() {
        let index = build_u64_sorted_index(
            Order::Asc,
            vec![vec![None, Some(1), Some(2)], vec![Some(3), Some(4)]],
        );
        let values = collect_u64_values(&index);
        assert_eq!(values, vec![None, Some(1), Some(2), Some(3), Some(4)]);
    }

    #[test]
    fn test_merge_sorted_index_u64_desc_nulls_only_in_last_segment() {
        let index = build_u64_sorted_index(
            Order::Desc,
            vec![vec![Some(4), Some(3)], vec![Some(2), Some(1), None]],
        );
        let values = collect_u64_values(&index);
        assert_eq!(values, vec![Some(4), Some(3), Some(2), Some(1), None]);
    }

    proptest! {
        #[test]
        fn test_merge_sorted_index_u64_matches_sorted_input(
            order in prop_oneof![Just(Order::Asc), Just(Order::Desc)],
            segments in proptest::collection::vec(
                proptest::collection::vec(proptest::option::of(0u64..100), 1..8),
                1..6,
            )
        ) {
            let index = build_u64_sorted_index(order, segments.clone());
            let values = collect_u64_values(&index);
            let mut expected: Vec<Option<u64>> = segments.into_iter().flatten().collect();
            expected.sort_by(|left, right| compare_option_values(left, right, order));
            prop_assert_eq!(values, expected);
        }
    }

    // #[test]
    // fn test_merge_sorted_index_asc() {
    //     let index = create_test_index(
    //         Some(IndexSettings {
    //             sort_by_field: Some(IndexSortByField {
    //                 field: "intval".to_string(),
    //                 order: Order::Asc,
    //             }),
    //             ..Default::default()
    //         }),
    //         false,
    //     )
    //     .unwrap();

    //     let int_field = index.schema().get_field("intval").unwrap();
    //     let multi_numbers = index.schema().get_field("multi_numbers").unwrap();
    //     let bytes_field = index.schema().get_field("bytes").unwrap();
    //     let reader = index.reader().unwrap();
    //     let searcher = reader.searcher();
    //     assert_eq!(searcher.segment_readers().len(), 1);
    //     let segment_reader = searcher.segment_readers().last().unwrap();

    //     let fast_fields = segment_reader.fast_fields();
    //     let fast_field = fast_fields.u64(int_field).unwrap();
    //     assert_eq!(fast_field.get_val(0), 1u64);
    //     assert_eq!(fast_field.get_val(1), 2u64);
    //     assert_eq!(fast_field.get_val(2), 3u64);
    //     assert_eq!(fast_field.get_val(3), 10u64);
    //     assert_eq!(fast_field.get_val(4), 20u64);
    //     assert_eq!(fast_field.get_val(5), 1_000u64);

    //     let get_vals = |fast_field: &MultiValuedFastFieldReader<u64>, doc_id: u32| -> Vec<u64> {
    //         let mut vals = vec![];
    //         fast_field.get_vals(doc_id, &mut vals);
    //         vals
    //     };
    //     let fast_fields = segment_reader.fast_fields();
    //     let fast_field = fast_fields.u64s(multi_numbers).unwrap();
    //     assert_eq!(&get_vals(&fast_field, 0), &[] as &[u64]);
    //     assert_eq!(&get_vals(&fast_field, 1), &[2, 3]);
    //     assert_eq!(&get_vals(&fast_field, 2), &[3, 4]);
    //     assert_eq!(&get_vals(&fast_field, 3), &[10, 11]);
    //     assert_eq!(&get_vals(&fast_field, 4), &[20]);
    //     assert_eq!(&get_vals(&fast_field, 5), &[1001, 1002]);

    //     let fast_field = fast_fields.bytes(bytes_field).unwrap();
    //     assert_eq!(fast_field.get_bytes(0), &[] as &[u8]);
    //     assert_eq!(fast_field.get_bytes(2), &[1, 2, 3]);
    //     assert_eq!(fast_field.get_bytes(5), &[5, 5]);

    //     // test new field norm mapping
    //     {
    //         let my_text_field = index.schema().get_field("text_field").unwrap();
    //         let fieldnorm_reader = segment_reader.get_fieldnorms_reader(my_text_field).unwrap();
    //         assert_eq!(fieldnorm_reader.fieldnorm(0), 0);
    //         assert_eq!(fieldnorm_reader.fieldnorm(1), 4);
    //         assert_eq!(fieldnorm_reader.fieldnorm(2), 2); // some text
    //         assert_eq!(fieldnorm_reader.fieldnorm(3), 1);
    //         assert_eq!(fieldnorm_reader.fieldnorm(5), 3); // the biggest num
    //     }

    //     let searcher = index.reader().unwrap().searcher();
    //     {
    //         let my_text_field = index.schema().get_field("text_field").unwrap();

    //         let do_search = |term: &str| {
    //             let query = QueryParser::for_index(&index, vec![my_text_field])
    //                 .parse_query(term)
    //                 .unwrap();
    //             let top_docs: Vec<(f32, DocAddress)> =
    //                 searcher.search(&query, &TopDocs::with_limit(3).order_by_score()).unwrap();

    //             top_docs.iter().map(|el| el.1.doc_id).collect::<Vec<_>>()
    //         };

    //         assert_eq!(do_search("some"), vec![2]);
    //         assert_eq!(do_search("blubber"), vec![3]);
    //         assert_eq!(do_search("biggest"), vec![5]);
    //     }

    //     // postings file
    //     {
    //         let my_text_field = index.schema().get_field("text_field").unwrap();
    //         let term_a = Term::from_field_text(my_text_field, "text");
    //         let inverted_index = segment_reader.inverted_index(my_text_field).unwrap();
    //         let mut postings = inverted_index
    //             .read_postings(&term_a, IndexRecordOption::WithFreqsAndPositions)
    //             .unwrap()
    //             .unwrap();

    //         assert_eq!(postings.doc_freq(), 2);
    //         let fallback_bitset = AliveBitSet::for_test_from_deleted_docs(&[0], 100);
    //         assert_eq!(
    //             postings.doc_freq_given_deletes(
    //                 segment_reader.alive_bitset().unwrap_or(&fallback_bitset)
    //             ),
    //             2
    //         );

    //         let mut output = vec![];
    //         postings.positions(&mut output);
    //         assert_eq!(output, vec![1, 3]);
    //         postings.advance();

    //         postings.positions(&mut output);
    //         assert_eq!(output, vec![1]);
    //     }

    //     // access doc store
    //     {
    //         let doc = searcher.doc(DocAddress::new(0, 0)).unwrap();
    //         assert_eq!(doc.get_first(int_field).unwrap().as_u64(), Some(1));
    //         let doc = searcher.doc(DocAddress::new(0, 1)).unwrap();
    //         assert_eq!(doc.get_first(int_field).unwrap().as_u64(), Some(2));
    //         let doc = searcher.doc(DocAddress::new(0, 2)).unwrap();
    //         assert_eq!(doc.get_first(int_field).unwrap().as_u64(), Some(3));
    //         let doc = searcher.doc(DocAddress::new(0, 3)).unwrap();
    //         assert_eq!(doc.get_first(int_field).unwrap().as_u64(), Some(10));
    //         let doc = searcher.doc(DocAddress::new(0, 4)).unwrap();
    //         assert_eq!(doc.get_first(int_field).unwrap().as_u64(), Some(20));
    //         let doc = searcher.doc(DocAddress::new(0, 5)).unwrap();
    //         assert_eq!(doc.get_first(int_field).unwrap().as_u64(), Some(1_000));
    //     }
    // }
}

#[cfg(all(test, feature = "unstable"))]
mod bench_sorted_index_merge {

    use test::{self, Bencher};

    use crate::index::Index;
    use crate::indexer::merger::IndexMerger;
    use crate::schema::{NumericOptions, Schema};
    use crate::{IndexSettings, IndexSortByField, IndexWriter, Order};
    fn create_index(sort_by_field: Option<IndexSortByField>) -> Index {
        let mut schema_builder = Schema::builder();
        let int_options = NumericOptions::default().set_fast().set_indexed();
        let int_field = schema_builder.add_u64_field("intval", int_options);
        let schema = schema_builder.build();

        let index_builder = Index::builder().schema(schema).settings(IndexSettings {
            sort_by_field,
            ..Default::default()
        });
        let index = index_builder.create_in_ram().unwrap();

        {
            let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
            let index_doc = |index_writer: &mut IndexWriter, val: u64| {
                index_writer.add_document(doc!(int_field=>val)).unwrap();
            };
            // 3 segments with 10_000 values in the fast fields
            for _ in 0..3 {
                index_doc(&mut index_writer, 5000); // fix to make it unordered
                for i in 0..10_000 {
                    index_doc(&mut index_writer, i);
                }
                index_writer.commit().unwrap();
            }
        }
        index
    }

    //#[bench]
    // fn create_sorted_index_walk_overkmerge_on_merge_fastfield(
    // b: &mut Bencher,
    //) -> crate::Result<()> {
    // let sort_by_field = IndexSortByField {
    // field: "intval".to_string(),
    // order: Order::Desc,
    //};
    // let index = create_index(Some(sort_by_field.clone()));
    // let segments = index.searchable_segments().unwrap();
    // let merger: IndexMerger =
    // IndexMerger::open(index.schema(), index.settings().clone(), &segments[..])?;
    // let doc_id_mapping = merger.generate_doc_id_mapping(&sort_by_field).unwrap();
    // b.iter(|| {
    // let sorted_doc_ids = doc_id_mapping.iter_old_doc_addrs().map(|doc_addr| {
    // let reader = &merger.readers[doc_addr.segment_ord as usize];
    // let u64_reader: Arc<dyn Column<u64>> = reader
    //.fast_fields()
    //.typed_fast_field_reader("intval")
    //.expect(
    //"Failed to find a reader for single fast field. This is a tantivy bug and \
    // it should never happen.",
    //);
    //(doc_addr.doc_id, reader, u64_reader)
    //});
    /// add values in order of the new doc_ids
    // let mut val = 0;
    // for (doc_id, _reader, field_reader) in sorted_doc_ids {
    // val = field_reader.get_val(doc_id);
    //}

    // val
    //});

    // Ok(())
    //}

    #[bench]
    fn create_sorted_index_create_doc_id_mapping(b: &mut Bencher) -> crate::Result<()> {
        let sort_by_field = IndexSortByField {
            field: "intval".to_string(),
            order: Order::Desc,
        };
        let index = create_index(Some(sort_by_field.clone()));
        // let field = index.schema().get_field("intval").unwrap();
        let segments = index.searchable_segments().unwrap();
        let merger: IndexMerger =
            IndexMerger::open(index.schema(), index.settings().clone(), &segments[..])?;
        b.iter(|| {
            merger
                .generate_doc_id_mapping_with_sort_by_field(&sort_by_field)
                .unwrap();
        });

        Ok(())
    }
}
